

const { decryptMedia } = require('@open-wa/wa-decrypt')
const {
  create,
 
} = require('@open-wa/wa-automate')
const fs = require('fs-extra')
const axios = require('axios')
const math = require('mathjs')
const mime = require('mime-types');

const ffmpeg = require('fluent-ffmpeg')
const process = require('process');
const request = require('request')

const { Readable, Writable } = require('stream')

const { Aki } = require('aki-api')
const sendSticker = require('./sendSticker')
const get = require('got')
const ImagesToPDF = require('images-pdf');
const sharp = require('sharp')
const moment = require('moment-timezone')
moment.tz.setDefault('America/Sao_Paulo').locale('pt_BR')
const nhentai = require('nhentai-js')
const { API } = require('nhentai-api')
//Common-Js
const { existsSync, writeFileSync, readdirSync, readFileSync, writeFile, unlinkSync } = fs

const { tz } = moment
 
const isPorn = require('is-porn')
const { getLevel, getMsg, getXp, addLevel, addXp, getRank, isWin, wait, addLimit, addMsg, getLimit } = require('./lib/gaming')
const google = require('google-it')

const config = require('./lib/lang/config.json')
const msgcount = JSON.parse(fs.readFileSync('./lib/msgcount.json'))
const { uploadImages } = require('./lib/fetc')

const irisMsgs = fs.readFileSync('./lib/reply.txt').toString().split('\n')
const chatBotR = irisMsgs[Math.floor(Math.random() * irisMsgs.length)].replace('%name$')
const xp = JSON.parse(fs.readFileSync('./lib/xp.json'))
const nivel = JSON.parse(fs.readFileSync('./lib/level.json'))
const { RemoveBgResult, removeBackgroundFromImageBase64, removeBackgroundFromImageFile } = require('remove.bg') 
const color = require('./lib/color')
const { liriklagu, quotemaker, wall, ss } = require('./lib/functions')
const { help, info, } = require('./lib/help')
const { help2 } = require('./lib/help2')

const akaneko = require('akaneko');
const { exec, execFile, spawn} = require('child_process')
const fetch = require('node-fetch');
const ruleArr = JSON.parse(fs.readFileSync('./lib/rule.json'))
const bent = require('bent')
const waifulist = require("public-waifulist")
const waifuclient = new waifulist()
const pokefunc = require('./lib/poke.js')
const pkarrs = JSON.parse(fs.readFileSync('./lib/pokedata/pkmnz.json'))
const nsfw_ = JSON.parse(fs.readFileSync('./lib/adulto.json'))
 const stauto = JSON.parse(fs.readFileSync('./lib/stauto.json'))
const wel = JSON.parse(fs.readFileSync('./lib/welcome.json')) 
const nsfwgrp = JSON.parse(fs.readFileSync('./lib/nsfw.json')) 
const ban = JSON.parse(fs.readFileSync('./lib/banned.json'))
const errorurl = 'https://steamuserimages-a.akamaihd.net/ugc/954087817129084207/5B7E46EE484181A676C02DFCAD48ECB1C74BC423/?imw=512&&ima=fit&impolicy=Letterbox&imcolor=%23000000&letterbox=false'
const errorurl2 = 'https://steamuserimages-a.akamaihd.net/ugc/954087817129084207/5B7E46EE484181A676C02DFCAD48ECB1C74BC423/?imw=512&&ima=fit&impolicy=Letterbox&imcolor=%23000000&letterbox=false'
const { profile } = require('./lib/profile.js')
const sticker = require('./lib/sticker.js')
const stickerArr = ['XM1N7CiW1xxkL8Oi6sCD2+xECehai2DI4bE37I7PIhw=', 'toFAeTndmqlzGRdBUY4K2EAnLdwCqgGF7nmMiaAX2Y0=', 'UWK/E5Jf/OLg+zFgICX3bwXc0iXfPEZ+PDDf0C+3Qvw=', 'BfppV7tESHi/QmrxuJG4WdXKYsO3lNTiXf0aBfasJ4E=', 'mHbEuCjA+RVWftr2AFuLieAJcyHYZnibd7waZPqvDNQ=']
/* #region LowDb */


const { msg } = require('./nonPrefix.js')
function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}
function tmpr(ms) {
  return new Promise(resolve => setImmediate(resolve, ms));
}


module.exports = msgHandler = async (client, message) => {
    try {
        const { type, id, from, t, sender, isGroupMsg,  chat, chatId, caption, isMedia, mimetype, quotedMsg, mentionedJidList, author, quotedMsgObj } = message
        let { body } = message
        const { name } = chat
        let { pushname, verifiedName } = sender
        body = (type === 'chat' && body.startsWith(prefix)) ? body : ((type === 'image' && caption || type === 'video' && caption) && caption.startsWith(prefix)) ? caption : ''
           const double = Math.floor(Math.random() * 2) + 1
        const four = Math.floor(Math.random() * 4) + 1
        const triple = Math.floor(Math.random() * 3) + 1
        const cinco = Math.floor(Math.random() * 5) + 1
        const six = Math.floor(Math.random() * 6) + 1
        const seven = Math.floor(Math.random() * 7) + 1
            const octo = Math.floor(Math.random() * 8) + 1
		
		  const user = sender.id
		 const isQuotedImage = quotedMsg && quotedMsg.type === 'image'
		const isQuotedAudio = quotedMsg && quotedMsg.type === 'audio'
		const isQuotedSticker = quotedMsg && quotedMsg.type === 'sticker'
        const command = body.slice(prefix.length).trim().split(/ +/).shift().toLowerCase()
        const args = body.slice(prefix.length).trim().split(/ +/).slice(1)
        const isCmd = body.startsWith(prefix)
	    const isRule = ruleArr.includes(chat.id)
	    const lvpc = Math.floor(Math.random() * 101) + 1
        const time = moment(t * 1000).format('DD/MM HH:mm:ss')
        
const { mylang } = require('./lib/lang')
      
      
      
      
      
        // ATIVADORES & CONFIGS
const region = config.lang




const blockNumber = await client.getBlockedIds()
const isBlocked = blockNumber.includes(user)
const cd = 0.18e+7
const mess = mylang()
moment.tz.setDefault('America/Sao_Paulo').locale('pt_BR')

var jogadas = 0
        
        const isQuotedPtt = quotedMsg && quotedMsg.type === 'ptt'
	
	const botNumber = await client.getHostNumber()
	const groupId = isGroupMsg ? chat.groupMetadata.id : ''
	const groupAdmins = isGroupMsg ? await client.getGroupAdmins(groupId) : ''
	 const isxp = isGroupMsg ? xp.includes(groupId) : false
	const isGroupAdmins = isGroupMsg ? groupAdmins.includes(sender.id) : false
	const isNsfw = isGroupMsg ? nsfw_.includes(groupId) : false
	const isSta = isGroupMsg ? stauto.includes(groupId) : false
	
	const arks = args.join(' ')
        const isBotGroupAdmins = isGroupMsg ? groupAdmins.includes(botNumber + '@c.us') : false
	if (isCmd && ban.includes(sender.id)) return client.reply(from, 'You\'re banned!', id)
	if ((message.type == 'sticker') && (stickerArr.includes(message.filehash))) return await sticker.stickerHandler(message, client, isGroupAdmins, isBotGroupAdmins, groupAdmins, color, time)
	 if (isGroupMsg) { getMsg(user, msgcount); addMsg(user, 1, msgcount) }
	if (isGroupMsg && isRule && (type === 'chat' && message.body.includes('chat.whatsapp.com') && isBotGroupAdmins) && !isGroupAdmins) return await client.removeParticipant(chat.id, author)
       
        if (!isCmd && !isGroupMsg) return msg(message, color, true, time)
        if (!isCmd && isGroupMsg) return msg(message, color, false, time)
        if (isCmd && !isGroupMsg) console.log(color('[EXEC]'), color(time, 'yellow'), color(`${command} [${args.length}]`), 'from', color(pushname))
        if (isCmd && isGroupMsg) console.log(color('[EXEC]'), color(time, 'yellow'), color(`${command} [${args.length}]`), 'from', color(pushname), 'in', color(name))
        // eg [9190xxxxxxxx, 49xxxxxxxx] replace my number also 
        const isowner = botadmins.includes(sender.id) 

      

// Sobe patente por nivel, mude pro que quiser dentro das aspas, não esqueca do case ranking
        const check = getLevel(user, nivel)

                          




        // Sistema do XP - Baseado no de Bocchi - Slavyan
        if (isGroupMsg && isxp && !isWin(user) && !isBlocked) {
            try {
                wait(user)
                const levelAtual = getLevel(user, nivel)
                const xpAtual = Math.floor(Math.random() * 30) + 11 // XP de 10 a 40
                const neededXp = 5 * Math.pow(levelAtual, 2) + 50 * levelAtual + 100
                addXp(user, xpAtual, nivel)
                if (neededXp <= getXp(user, nivel)) {
                    addLevel(user, 1, nivel)
                    const userLevel = getLevel(user, nivel)
                    const takeXp = 5 * Math.pow(userLevel, 2) + 50 * userLevel + 100
                    await client.reply(from, `*「 +1 NIVEL 」*\n\n➸ *Nome*: ${pushname}\n➸ *XP*: ${getXp(user, nivel)} / ${takeXp}\n➸ *Level*: ${levelAtual} -> ${getLevel(user, nivel)} 🆙 \n➸ *Patente*: *${patente}* 🎉`, id)
                }
            } catch (err) { console.log(color('[XP]', 'crimson'), err) }
        }
		
        const uaOverride = 'WhatsApp/2.2108.8 Mozilla/5.0 (Macintosh; Intel Mac OS X 11_2_2) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/89.0.4389.90 Safari/537.36'
        const isUrl = new RegExp(/https?:\/\/(www\.)?[-a-zA-Z0-9@:%._+~#=]{1,256}\.[a-zA-Z0-9()]{1,6}\b([-a-zA-Z0-9()@:%_+.~#?&/=]*)/gi)
           
            
            
            
            
            
            switch (command) {
 
 
    case 'estado':
                       case 'log':
                        const timeda = moment(t * 1000).format('DD/MM/YY HH:mm:ss')
			await client.reply(from, '*Lalatina BOT LOG* \n"' + timeda + '"', id)
            const loadedMsg = await client.getAmountOfLoadedMessages()
            const chatIds = await client.getAllChatIds()
            const groups = await client.getAllGroups()
          await client.sendText(from, `- *${loadedMsg}* Mensagens recebidas após ligar\n- *${groups.length}* Conversas em grupo\n- *${chatIds.length - groups.length}* Conversas no PV\n- *${chatIds.length}* Total de conversas`)
          teks = `*Notas de atualização:*
          _20210923174903 - Add novo comando !gótica, comando !bot alterado link api_
          `
            await client.sendText(from, teks)
          
          
           
          
            break
			
 
 
 
 
 
 
 
 
 case 'act':
             arg = body.trim().split(' ')
             if (!isGroupAdmins) return client.reply(from, 'Only Admins can use this command, Baka >.<', id)
             		if (arg[1].toLowerCase() == 'welcome') {
	     			if (wel.includes(chat.id)) {
	       				client.reply(from, `Welcome is already registered on *${name}*`, message.id)
	     			} else {
               				wel.push(chat.id)
                			fs.writeFileSync('./lib/welcome.json', JSON.stringify(wel))
                			client.reply(from, `Welcome is now registered on *${name}*`, message.id)
	     			}
             		} else if (arg[1].toLowerCase() == 'nsfw') {
	       			if (nsfwgrp.includes(chat.id)) {
				client.reply(from, `NSFW is already registered on *${name}*`, message.id)
	     			} else {
                		nsfwgrp.push(chat.id)
                		fs.writeFileSync('./lib/nsfw.json', JSON.stringify(nsfwgrp))
                		client.reply(from, `NSFW is now registered on *${name}*`, message.id)
				}
			} else if (arg[1].toLowerCase() == 'rule') {
				if (!isBotGroupAdmins) return client.reply(from, 'You need to make me admin to use this CMD', message.id)
				if (ruleArr.includes(chat.id)) {
					 client.reply(from, `Rule is already registered on *${name}*`, message.id)
				} else {
                			ruleArr.push(chat.id)
                			fs.writeFileSync('./lib/rule.json', JSON.stringify(ruleArr))
                			client.reply(from, `Rule is now registered on *${name}*`, message.id)
             			}
			}
             break
             
             
 break

        case 'deact':
             arg = body.trim().split(' ')
             if (!isGroupAdmins) return client.reply(from, 'Only Admins can use this command, Baka >.<', id)
             if (arg[1].toLowerCase() == 'welcome') {
                let inx = ban.indexOf(from)
                wel.splice(inx, 1)
                fs.writeFileSync('./lib/welcome.json', JSON.stringify(wel))
                client.reply(from, `Welcome is now unregistered on *${name}*`, message.id)
             } else if (arg[1].toLowerCase() == 'nsfw') {
                let inx = ban.indexOf(from)
                nsfwgrp.splice(inx, 1)
                fs.writeFileSync('./lib/nsfw.json', JSON.stringify(nsfwgrp))
                client.reply(from, `NSFW is now unregistered on *${name}*`, message.id)
             } else if (arg[1].toLowerCase() == 'pokegame') {
                let inx = pokarr.indexOf(from)
                pokarr.splice(inx, 1)
                fs.writeFileSync('./lib/poke.json', JSON.stringify(pokarr))
                client.reply(from, `PokeGame is now unregistered on *${name}*`, message.id)
             } else if (arg[1].toLowerCase() == 'rule') {
                let inx = ruleArr.indexOf(from)
                ruleArr.splice(inx, 1)
                fs.writeFileSync('./lib/rule.json', JSON.stringify(ruleArr))
                client.reply(from, `Rule is now unregistered on *${name}*`, message.id)
             }      
             break
                     case 'adult1':
            if (args.length !== 1) return await client.reply(from, '---', id)
			if (isGroupMsg && isGroupAdmins) {
				if (args[0] == 'ligar') {
					if (nsfw_.includes(groupId)) return await client.reply(from, 'Comandos adultos ligados', id)
					nsfw_.push(groupId)
					await fs.writeFileSync('./lib/adulto.json', JSON.stringify(nsfw_))
					await client.reply(from,'Comandos adultos ligados', id)
				} else if (args[0] == 'desligar') {
					if (!nsfw_.includes(groupId)) return await client.reply(from, 'Comandos adultos desligados', id)
					nsfw_.splice(groupId, 1)
					await fs.writeFileSync('./lib/adulto.json', JSON.stringify(nsfw_))
					await client.reply(from, 'Comandos adultos desligados', id)
				} else return await client.reply(from, mess.kldica1(), id)
			} else if (isGroupMsg) {
				await client.reply(from, 'Somente ADMS.', id)
			} else return await client.reply(from, 'Somente ADMS', id)
            break    
                
                    
                   
           case 'sr':
             arg = body.trim().split(' ')
             const sr = arg[1]
             try {
             const response1 = await axios.get('https://meme-api.herokuapp.com/gimme/' + sr + '/');
             const {
                    postLink,
                    title,
                    subreddit,
                    url,
                    nsfw,
                    spoiler
                } = response1.data

                const isnsfw = nsfwgrp.includes(from)
                if (nsfw == true) {
                      if ((isGroupMsg) && (isnsfw)) {
                                await client.sendFileFromUrl(from, `${url}`, '', `${postLink}` + '\n\n' + `🌎Alliαηce Oтαkus🇯🇵⃟ ᴬᵗᵏ`, id)
                      } else if ((isGroupMsg) && (!isnsfw)) {
                                await client.reply(from, `NSFW is not registered on *${name}*`, id)
                      }
                } else { 
                      await client.sendFileFromUrl(from, `${url}`, '',  `${postLink}` + '\n\n' + `🌎Alliαηce Oтαkus🇯🇵⃟ ᴬᵗᵏ`, id)
                }
                } catch(err) {
                    console.log(err)
                    await client.reply(from, 'Tag do Reddit nao encontrada, tenta usar uma tag do reddit, ex.: !sr animewallpaper', id) 
                }
                break
         
               
               //----sticker1 usando ffmpeg------//
            
       case 's': 
      case '.':
        case 'st':
        
const convertSticker = function(shape, author, pack, mediaData, type) {
  return new Promise((resolve, reject) => {
    var upfile = "sticker." + type;
    var metadata = {
      "pack": pack,
      "author": author,
      "shape": shape,
      "api_key": "JDJiJDEwJG9pQmtzT2JlUHFvYlB6cUsycUpzci5qekI2R0FBNmtLT0ZoOXpqQ0VpZkE5cVdoSi9KNWVH",
    };
    var url = "https://stickerman.org/api/convert";
    var boundary = "sticker";
    let data = "";
    for (var i in metadata) {
      if ({}.hasOwnProperty.call(metadata, i)) {
        data += "--" + boundary + "\r\n";
        data += "Content-Disposition: form-data; name=" + i + "; \r\n\r\n" + metadata[i] + "\r\n";
      }
    };
    data += "--" + boundary + "\r\n";
    data += "Content-Disposition: form-data; name=sticker; filename=" + upfile + "\r\n";
    data += "Content-Type:application/octet-stream\r\n\r\n";
    var payload = Buffer.concat([
      Buffer.from(data, "utf8"),
      new Buffer(mediaData, 'binary'),
      Buffer.from("\r\n--" + boundary + "--\r\n", "utf8"),
    ]);
    var options = {
      method: 'post',
      url: url,
      headers: {
        "Content-Type": "multipart/form-data; boundary=" + boundary
      },
      body: payload,
      encoding: null
    };
    request(options, function(error, response, body) {
      if (error) {
        reject(error)
      } else {
        resolve(body)
      }
    });
  });
};

const stickerPackID = "com.snowcorp.stickerly.android.stickercontentprovider b5e7275f-f1de-4137-961f-57becfad34f2";
const googleLink = "https://play.google.com/store/apps/details?id=cutewallpapersstudio.auto.background.eraser&hl=pt_BR&gl=US";
const appleLink = "https://apps.apple.com/br/app/owo-smilies-simulator/id1562664890";



async function createExif(packname, author) {
  const json = {
    "sticker-pack-id": stickerPackID,
    "sticker-pack-name": packname,
    "sticker-pack-publisher": author,
   "publisher-website": googleLink,
    "ios-app-store-link": appleLink
  };

  let length = JSON.stringify(json).length;
  const f = Buffer.from([0x49, 0x49, 0x2A, 0x00, 0x08, 0x00, 0x00, 0x00, 0x01, 0x00, 0x41, 0x57, 0x07, 0x00]);
  const code = [
    0x00,
    0x00,
    0x16,
    0x00,
    0x00,
    0x00
  ];
  if (length > 256) {
    length = length - 256;
    code.unshift(0x01);
  } else {
    code.unshift(0x00);
  }
  const fff = Buffer.from(code);
  const ffff = Buffer.from(JSON.stringify(json));

  if (length < 16) {
    length = length.toString(16);
    length = "0" + length;
  } else {
    length = length.toString(16);
  }

  const ff = Buffer.from(length, "hex");
  const buffer = Buffer.concat([f, ff, fff, ffff]);
  await fs.writeFileSync('./image/p.exif', buffer, function(err) {
    if (err) return console.error(err);
  });
}

function modifExif(buffer, id, callback) {
  fs.writeFileSync('./image/' + id + '.webp', buffer)
  const {
    spawn
  } = require('child_process')
  spawn('webpmux', ['-set', 'exif', './image/p.exif', './image/' + id + '.webp', '-o', './image/' + id + '.webp'])
    .on('exit', () => {
      callback(fs.readFileSync('./image/' + id + '.webp', {
        encoding: 'base64'
      }))
      fs.unlink('./image/' + id + '.webp').then(() => {})
    })
}

function bufferToStream(buffer) {
  const readable = new Readable()
  readable._read = () => {}
  readable.push(buffer)
  readable.push(null)
  return readable
}

const modifWebp = (id, buffers) => new Promise((resolve) => {
  const stream = bufferToStream(buffers)
  const {
    spawn
  } = require('child_process')
  ffmpeg(stream)
  .inputFormat('mp4')
  .addOutputOptions(`-vcodec`,`libwebp`,`-vf`,`scale='min(390,iw)':min'(390,ih)':force_original_aspect_ratio=decrease,fps=10, pad=390:390:-1:-1:color=white@0.0, split [a][b]; [a] palettegen=reserve_transparent=on:transparency_color=ffffff [p]; [b][p] paletteuse`)
  // Verificar doc ffmpeg para alteracao em https://ffmpeg.org/ffmpeg-all.html
  .save(`./image/${id}.webp`)
  .on('end', () => {
    stream.destroy()
    spawn('webpmux', ['-set', 'exif', './image/p.exif', './image/' + id + '.webp', '-o', './image/' + id + '.webp'])
    .on('exit', () => {
      let mediaData = (fs.readFileSync('./image/' + id + '.webp', {
        encoding: 'base64'
      }))
      fs.unlink('./image/' + id + '.webp').then(() => {})
      return resolve(mediaData)
    })
  })
})


//-----------------------processo-----------------------//

const fnBots = (fn = new Client()) => {
  client.onStateChanged(function (state) {
    if (state === "UNLAUNCHED") {
      client.forceRefocus()
    }
    if (state === "UNPAIRED") {}
  });
  client.onMessage(async(message) => {
    try {
      await bot(fn, message)
    } catch (error) {
      console.log(error.message)
    }
    client.getAmountOfLoadedMessages()
      .then((x) => {
        if (x >= 4000) {
          client.sendText('xxx@c.us', `Loaded message reach ${x}, cutting message cache...`)
          client.cutMsgCache()
          client.cutMsgCache()
          client.cutMsgCache()
          client.cutMsgCache()
          client.cutMsgCache()
          client.cutMsgCache()
        }
      })
  });
}

  
 // const arg = body.trim().split(' ')

    const a = " Alliance Otakus\nhttp://bit.ly/AtkSS"
    const b = "Lalatina BOT \n\n Siga no Insta:\n@alliance.otakus\n\n"
    await createExif(a,b)
     await sleep(1000)


         if (isMedia && mimetype == 'image/jpeg') {
          await client.reply(from, '⏳ _Aguarde..._ ⏳\n*▻ !ci* deixa o sticker em circulo (somente imagens no momento) \n*▻ !s* deixa sticker resolução original\n*▻ !r* redimensiona o sticker\n*▻ !c* que corta o sticker\n*▻ !sticker (sua palavra)* faz um sticker com sua descrição, basta mandar imagem com o comando\n*▻ !roubar* para roubar marque um sticker com o comando !roubar (sua palavra), só não roubem figurinhas com descrição 🇯🇵⃟ ᴬᵗᵏ se não leva ban, o resto é liberado. ', message.id)
      decryptMedia(message).then(mediaData => {
        sharp(mediaData).resize({
          width: 812,
          height: 812,
          fit: sharp.fit.contain,
          background: {
            r: 0,
            g: 0,
            b: 0,
            alpha: 0
          }
        }).webp().toBuffer().then(buffer => {
          modifExif(buffer, id, (res) => {
            mediaData = res.toString('base64')
            client.sendRawWebpAsSticker(from, mediaData)
          })
        })
      })
    } else if (quotedMsg && quotedMsgObj.mimetype == 'image/jpeg') {
      await client.reply(from,  '⏳ _Aguarde..._ ⏳\n*▻ !ci* deixa o sticker em circulo (somente imagens no momento) \n*▻ !s* deixa sticker resolução original\n*▻ !r* redimensiona o sticker\n*▻ !c* que corta o sticker\n*▻ !sticker (sua palavra)* faz um sticker com sua descrição, basta mandar imagem com o comando\n*▻ !roubar* para roubar marque um sticker com o comando !roubar (sua palavra), só não roubem figurinhas com descrição 🇯🇵⃟ ᴬᵗᵏ se não leva ban, o resto é liberado. ', message.id)
      decryptMedia(quotedMsg).then(mediaData => {
        sharp(mediaData).resize({
          width: 812,
          height: 812,
          fit: sharp.fit.contain,
          background: {
            r: 0,
            g: 0,
            b: 0,
            alpha: 0
          }
        }).webp().toBuffer().then(buffer => {
          modifExif(buffer, id, (res) => {
           
            mediaData = res.toString('base64')
            
            client.sendRawWebpAsSticker(from, mediaData)
          })
        })
      })
        } else if (quotedMsg && quotedMsgObj.mimetype == 'image/png') {
    await client.reply(from,  '⏳ _Aguarde..._ ⏳\n*▻ !ci* deixa o sticker em circulo (somente imagens no momento) \n*▻ !s* deixa sticker resolução original\n*▻ !r* redimensiona o sticker\n*▻ !c* que corta o sticker\n*▻ !sticker (sua palavra)* faz um sticker com sua descrição, basta mandar imagem com o comando\n*▻ !roubar* para roubar marque um sticker com o comando !roubar (sua palavra), só não roubem figurinhas com descrição 🇯🇵⃟ ᴬᵗᵏ se não leva ban, o resto é liberado. ', message.id)
      decryptMedia(quotedMsg).then(mediaData => {
        sharp(mediaData).resize({
          width: 812,
          height: 812,
          fit: sharp.fit.contain,
          background: {
            r: 0,
            g: 0,
            b: 0,
            alpha: 0
          }
        }).webp().toBuffer().then(buffer => {
          modifExif(buffer, id, (res) => {
           
            mediaData = res.toString('base64')
            
            client.sendRawWebpAsSticker(from, mediaData)
          })
        })
      })
    } else if (isMedia && mimetype == 'image/gif') {
      const mediaData = await decryptMedia(message)
       await client.reply(from, '⏳ _Aguarde..._ ⏳\n*▻ !ci* deixa o sticker em circulo (somente imagens no momento) \n*▻ !s* deixa sticker resolução original\n*▻ !r* redimensiona o sticker\n*▻ !c* que corta o sticker\n*▻ !sticker (sua palavra)* faz um sticker com sua descrição, basta mandar imagem com o comando\n*▻ !roubar* para roubar marque um sticker com o comando !roubar (sua palavra), só não roubem figurinhas com descrição 🇯🇵⃟ ᴬᵗᵏ se não leva ban, o resto é liberado. ', message.id)
      if (Buffer.byteLength(mediaData) >= 6186598.4) return client.reply(`o tamanho é muito grande, querido :( máx. 1,0 MB`)
      modifWebp(id, mediaData).then(res => {
        client.sendRawWebpAsSticker(from, res.toString('base64'), true).catch(() => client.reply('Desculpe, a qualidade não é compatível com este vídeo'))
      })
    } else if (quotedMsg && quotedMsgObj.mimetype == 'image/gif') {
      const mediaData = await decryptMedia(quotedMsg)
     await client.reply(from, '⏳ _Aguarde..._ ⏳\n*▻ !ci* deixa o sticker em circulo (somente imagens no momento) \n*▻ !s* deixa sticker resolução original\n*▻ !r* redimensiona o sticker\n*▻ !c* que corta o sticker\n*▻ !sticker (sua palavra)* faz um sticker com sua descrição, basta mandar imagem com o comando\n*▻ !roubar* para roubar marque um sticker com o comando !roubar (sua palavra), só não roubem figurinhas com descrição 🇯🇵⃟ ᴬᵗᵏ se não leva ban, o resto é liberado. ', message.id)
      if (Buffer.byteLength(mediaData) >= 6186598.4) return client.reply(`o tamanho é muito grande, querido :( máx. 1,0 MB`)
      modifWebp(id, mediaData).then(res => {
        client.sendRawWebpAsSticker(from, res.toString('base64'), true).catch(() => client.reply('Desculpe, a qualidade não é compatível com este vídeo'))
      })
    } else if (isMedia && mimetype == 'video/mp4') {
      const mediaData = await decryptMedia(message)
         await client.reply(from,  '⏳ _Aguarde..._ ⏳\n*▻ !ci* deixa o sticker em circulo (somente imagens no momento) \n*▻ !s* deixa sticker resolução original\n*▻ !r* redimensiona o sticker\n*▻ !c* que corta o sticker\n*▻ !sticker (sua palavra)* faz um sticker com sua descrição, basta mandar imagem com o comando\n*▻ !roubar* para roubar marque um sticker com o comando !roubar (sua palavra), só não roubem figurinhas com descrição 🇯🇵⃟ ᴬᵗᵏ se não leva ban, o resto é liberado. ', message.id)
      if (Buffer.byteLength(mediaData) >= 6186598.4) return client.reply(`o tamanho é muito grande, querido :( máx. 1,0 MB`)
      modifWebp(id, mediaData).then(res => {
        client.sendRawWebpAsSticker(from, res.toString('base64'), true).catch(() => client.reply('Desculpe, a qualidade não é compatível com este vídeo'))
      })
    } else if (quotedMsg && quotedMsgObj.mimetype == 'video/mp4') {
      const mediaData = await decryptMedia(quotedMsg)
   await client.reply(from, '⏳ _Aguarde..._ ⏳\n*▻ !ci* deixa o sticker em circulo (somente imagens no momento) \n*▻ !s* deixa sticker resolução original\n*▻ !r* redimensiona o sticker\n*▻ !c* que corta o sticker\n*▻ !sticker (sua palavra)* faz um sticker com sua descrição, basta mandar imagem com o comando\n*▻ !roubar* para roubar marque um sticker com o comando !roubar (sua palavra), só não roubem figurinhas com descrição 🇯🇵⃟ ᴬᵗᵏ se não leva ban, o resto é liberado. ', message.id)
      if (Buffer.byteLength(mediaData) >= 6186598.4) return client.reply(`o tamanho é muito grande, querido :( máx. 1,0 MB`)
      modifWebp(id, mediaData).then(res => {
        client.sendRawWebpAsSticker(from, res.toString('base64'), true).catch(() => client.reply('Desculpe, a qualidade não é compatível com este vídeo'))
      })

 }
 
               
               
               
               break
               
                         
               //----sticker2 usando ffmpeg------//
     case 'stickerr':           
       case 'r': 
        case 'str':
         case 'gifr':
const convertSticker1 = function(shape, author, pack, mediaData, type) {
  return new Promise((resolve, reject) => {
    var upfile = "sticker." + type;
    var metadata = {
      "pack": pack,
      "author": author,
      "shape": shape,
      "api_key": "JDJiJDEwJG9pQmtzT2JlUHFvYlB6cUsycUpzci5qekI2R0FBNmtLT0ZoOXpqQ0VpZkE5cVdoSi9KNWVH",
    };
    var url = "https://stickerman.org/api/convert";
    var boundary = "sticker";
    let data = "";
    for (var i in metadata) {
      if ({}.hasOwnProperty.call(metadata, i)) {
        data += "--" + boundary + "\r\n";
        data += "Content-Disposition: form-data; name=" + i + "; \r\n\r\n" + metadata[i] + "\r\n";
      }
    };
    data += "--" + boundary + "\r\n";
    data += "Content-Disposition: form-data; name=sticker; filename=" + upfile + "\r\n";
    data += "Content-Type:application/octet-stream\r\n\r\n";
    var payload = Buffer.concat([
      Buffer.from(data, "utf8"),
      new Buffer(mediaData, 'binary'),
      Buffer.from("\r\n--" + boundary + "--\r\n", "utf8"),
    ]);
    var options = {
      method: 'post',
      url: url,
      headers: {
        "Content-Type": "multipart/form-data; boundary=" + boundary
      },
      body: payload,
      encoding: null
    };
    request(options, function(error, response, body) {
      if (error) {
        reject(error)
      } else {
        resolve(body)
      }
    });
  });
};

const stickerPackID1 = "com.snowcorp.stickerly.android.stickercontentprovider b5e7275f-f1de-4137-961f-57becfad34f2";
const googleLink1 = "https://play.google.com/store/apps/details?id=cutewallpapersstudio.auto.background.eraser&hl=pt_BR&gl=US";
const appleLink1 = "https://apps.apple.com/br/app/owo-smilies-simulator/id1562664890";



async function createExif1(packname, author) {
  const json = {
    "sticker-pack-id": stickerPackID1,
    "sticker-pack-name": packname,
    "sticker-pack-publisher": author,
   "android-app-store-link": googleLink1,
    "ios-app-store-link": appleLink1
  };

  let length = JSON.stringify(json).length;
  const f = Buffer.from([0x49, 0x49, 0x2A, 0x00, 0x08, 0x00, 0x00, 0x00, 0x01, 0x00, 0x41, 0x57, 0x07, 0x00]);
  const code = [
    0x00,
    0x00,
    0x16,
    0x00,
    0x00,
    0x00
  ];
  if (length > 256) {
    length = length - 256;
    code.unshift(0x01);
  } else {
    code.unshift(0x00);
  }
  const fff = Buffer.from(code);
  const ffff = Buffer.from(JSON.stringify(json));

  if (length < 16) {
    length = length.toString(16);
    length = "0" + length;
  } else {
    length = length.toString(16);
  }

  const ff = Buffer.from(length, "hex");
  const buffer = Buffer.concat([f, ff, fff, ffff]);
  await fs.writeFileSync('./image/p.exif', buffer, function(err) {
    if (err) return console.error(err);
  });
}

function modifExif(buffer, id, callback) {
  fs.writeFileSync('./image/' + id + '.webp', buffer)
  const {
    spawn
  } = require('child_process')
  spawn('webpmux', ['-set', 'exif', './image/p.exif', './image/' + id + '.webp', '-o', './image/' + id + '.webp'])
    .on('exit', () => {
      callback(fs.readFileSync('./image/' + id + '.webp', {
        encoding: 'base64'
      }))
      fs.unlink('./image/' + id + '.webp').then(() => {})
    })
}

function bufferToStream(buffer) {
  const readable = new Readable()
  readable._read = () => {}
  readable.push(buffer)
  readable.push(null)
  return readable
}

const modifWebp1 = (id, buffers) => new Promise((resolve) => {
  const stream = bufferToStream(buffers)
  const {
    spawn
  } = require('child_process')
  ffmpeg(stream)
  .inputFormat('mp4')
  .addOutputOptions("-vcodec", "libwebp", "-vf", "scale='min(350,iw)':min'(350,ih)':force_original_aspect_ratio=decrease, fps=10" , '-lossless', '1', "-loop", "1", "-preset", "default", "-an", "-vsync", "0", "-s", "350:350")
  // Verificar doc ffmpeg para alteracao em https://ffmpeg.org/ffmpeg-all.html
  .save(`./image/${id}.webp`)
  .on('end', () => {
    stream.destroy()
    spawn('webpmux', ['-set', 'exif', './image/p.exif', './image/' + id + '.webp', '-o', './image/' + id + '.webp'])
    .on('exit', () => {
      let mediaData = (fs.readFileSync('./image/' + id + '.webp', {
        encoding: 'base64'
      }))
      fs.unlink('./image/' + id + '.webp').then(() => {})
      return resolve(mediaData)
    })
  })
})


//-----------------------processo-----------------------//

const fnBots1 = (fn = new Client()) => {
  client.onStateChanged(function (state) {
    if (state === "UNLAUNCHED") {
      client.forceRefocus()
    }
    if (state === "UNPAIRED") {}
  });
  client.onMessage(async(message) => {
    try {
      await bot(fn, message)
    } catch (error) {
      console.log(error.message)
    }
    client.getAmountOfLoadedMessages()
      .then((x) => {
        if (x >= 4000) {
          client.sendText('xxx@c.us', `Loaded message reach ${x}, cutting message cache...`)
          client.cutMsgCache()
          client.cutMsgCache()
          client.cutMsgCache()
          client.cutMsgCache()
          client.cutMsgCache()
          client.cutMsgCache()
        }
      })
  });
}

  
 // const arg = body.trim().split(' ')

    const a1 = " Alliance Otakus\nhttp://bit.ly/AtkSS"
    const b1 = "Lalatina BOT \n\n Siga no Insta:\n@alliance.otakus\n\n"
    await createExif1(a1,b1)
     await sleep(2000)


         if (isMedia && mimetype == 'image/jpeg') {
         await client.reply(from,  '⏳ _Aguarde..._ ⏳\n*▻ !ci* deixa o sticker em circulo (somente imagens no momento) \n*▻ !s* deixa sticker resolução original\n*▻ !r* redimensiona o sticker\n*▻ !c* que corta o sticker\n*▻ !sticker (sua palavra)* faz um sticker com sua descrição, basta mandar imagem com o comando\n*▻ !roubar* para roubar marque um sticker com o comando !roubar (sua palavra), só não roubem figurinhas com descrição 🇯🇵⃟ ᴬᵗᵏ se não leva ban, o resto é liberado. ', message.id)
      decryptMedia(message).then(mediaData => {
      sharp(mediaData).resize({
        }).webp().toBuffer().then(buffer => {
          modifExif(buffer, id, (res) => {
            mediaData = res.toString('base64')
            client.sendRawWebpAsSticker(from, mediaData)
          })
        })
      })
    } else if (quotedMsg && quotedMsgObj.mimetype == 'image/jpeg') {
      await client.reply(from, '⏳ _Aguarde..._ ⏳\n*▻ !ci* deixa o sticker em circulo (somente imagens no momento) \n*▻ !s* deixa sticker resolução original\n*▻ !r* redimensiona o sticker\n*▻ !c* que corta o sticker\n*▻ !sticker (sua palavra)* faz um sticker com sua descrição, basta mandar imagem com o comando\n*▻ !roubar* para roubar marque um sticker com o comando !roubar (sua palavra), só não roubem figurinhas com descrição 🇯🇵⃟ ᴬᵗᵏ se não leva ban, o resto é liberado. ', message.id)
      decryptMedia(quotedMsg).then(mediaData => {
        sharp(mediaData).resize({
         
          
        }).webp().toBuffer().then(buffer => {
          modifExif(buffer, id, (res) => {
             
            mediaData = res.toString('base64')
            client.sendRawWebpAsSticker(from, mediaData)
          })
        })
      })
    } else if (isMedia && mimetype == 'image/gif') {
      const mediaData = await decryptMedia(message)
    await client.reply(from, '⏳ _Aguarde..._ ⏳\n*▻ !ci* deixa o sticker em circulo (somente imagens no momento) \n*▻ !s* deixa sticker resolução original\n*▻ !r* redimensiona o sticker\n*▻ !c* que corta o sticker\n*▻ !sticker (sua palavra)* faz um sticker com sua descrição, basta mandar imagem com o comando\n*▻ !roubar* para roubar marque um sticker com o comando !roubar (sua palavra), só não roubem figurinhas com descrição 🇯🇵⃟ ᴬᵗᵏ se não leva ban, o resto é liberado. ', message.id)
      if (Buffer.byteLength(mediaData) >= 6186598.4) return client.reply(`o tamanho é muito grande, querido :( máx. 1,0 MB`)
      modifWebp1(id, mediaData).then(res => {
        client.sendRawWebpAsSticker(from, res.toString('base64'), true).catch(() => client.reply('Desculpe, a qualidade não é compatível com este vídeo'))
      })
    } else if (quotedMsg && quotedMsgObj.mimetype == 'image/gif') {
      const mediaData = await decryptMedia(quotedMsg)
     await client.reply(from, '⏳ _Aguarde..._ ⏳\n*▻ !ci* deixa o sticker em circulo (somente imagens no momento) \n*▻ !s* deixa sticker resolução original\n*▻ !r* redimensiona o sticker\n*▻ !c* que corta o sticker\n*▻ !sticker (sua palavra)* faz um sticker com sua descrição, basta mandar imagem com o comando\n*▻ !roubar* para roubar marque um sticker com o comando !roubar (sua palavra), só não roubem figurinhas com descrição 🇯🇵⃟ ᴬᵗᵏ se não leva ban, o resto é liberado. ', message.id)
      if (Buffer.byteLength(mediaData) >= 6186598.4) return client.reply(`o tamanho é muito grande, querido :( máx. 1,0 MB`)
      modifWebp1(id, mediaData).then(res => {
        client.sendRawWebpAsSticker(from, res.toString('base64'), true).catch(() => client.reply('Desculpe, a qualidade não é compatível com este vídeo'))
      })
    } else if (isMedia && mimetype == 'video/mp4') {
      const mediaData = await decryptMedia(message)
           await client.reply(from,  '⏳ _Aguarde..._ ⏳\n*▻ !ci* deixa o sticker em circulo (somente imagens no momento) \n*▻ !s* deixa sticker resolução original\n*▻ !r* redimensiona o sticker\n*▻ !c* que corta o sticker\n*▻ !sticker (sua palavra)* faz um sticker com sua descrição, basta mandar imagem com o comando\n*▻ !roubar* para roubar marque um sticker com o comando !roubar (sua palavra), só não roubem figurinhas com descrição 🇯🇵⃟ ᴬᵗᵏ se não leva ban, o resto é liberado. ', message.id)
      if (Buffer.byteLength(mediaData) >= 6186598.4) return client.reply(`o tamanho é muito grande, querido :( máx. 1,0 MB`)
      modifWebp1(id, mediaData).then(res => {
        client.sendRawWebpAsSticker(from, res.toString('base64'), true).catch(() => client.reply('Desculpe, a qualidade não é compatível com este vídeo'))
      })
    } else if (quotedMsg && quotedMsgObj.mimetype == 'video/mp4') {
      const mediaData = await decryptMedia(quotedMsg)
     await client.reply(from, '⏳ _Aguarde..._ ⏳\n*▻ !ci* deixa o sticker em circulo (somente imagens no momento) \n*▻ !s* deixa sticker resolução original\n*▻ !r* redimensiona o sticker\n*▻ !c* que corta o sticker\n*▻ !sticker (sua palavra)* faz um sticker com sua descrição, basta mandar imagem com o comando\n*▻ !roubar* para roubar marque um sticker com o comando !roubar (sua palavra), só não roubem figurinhas com descrição 🇯🇵⃟ ᴬᵗᵏ se não leva ban, o resto é liberado. ', message.id)
      if (Buffer.byteLength(mediaData) >= 6186598.4) return client.reply(`o tamanho é muito grande, querido :( máx. 1,0 MB`)
      modifWebp1(id, mediaData).then(res => {
        client.sendRawWebpAsSticker(from, res.toString('base64'), true).catch(() => client.reply('Desculpe, a qualidade não é compatível com este vídeo'))
      })

 }
 
               
               break
               
               //-------------------sticker3 sem ffmpeg--------------------------\\
               
               case 'c':
                  case 'stickerc':
               const unhandledRejections = new Map()
process.on('unhandledRejection', (reason, promise) => {
	unhandledRejections.set(promise, reason)
})
process.on('rejectionHandled', (promise) => {
	unhandledRejections.delete(promise)
})
process.on('Something went wrong', function(err) {
	console.log('Caught exception: ', err)
})
process.on('unhandledRejection', (reason, promise) => {
	console.log('Unhandled Rejection at:', promise, 'reason:', reason)
	
	
	})


function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}


//-----------------------processo-----------------------//

const fnBots3 = (fn = new Client()) => {
  fn.onStateChanged(function (state) {
    if (state === "UNLAUNCHED") {
      fn.forceRefocus()
    }
    if (state === "UNPAIRED") {}
  });
  fn.onMessage(async(message) => {
    try {
      await bot(fn, message)
    } catch (error) {
      console.log(error.message)
    }
    fn.getAmountOfLoadedMessages()
      .then((x) => {
        if (x >= 4000) {
          fn.sendText('xxx@c.us', `Loaded message reach ${x}, cutting message cache...`)
          fn.cutMsgCache()
          fn.cutMsgCache()
          fn.cutMsgCache()
          fn.cutMsgCache()
          fn.cutMsgCache()
          fn.cutMsgCache()
        }
      })
  });
}


 {
  
    
   if (isMedia && mimetype == 'image/jpeg')  {
      const mediaData = await decryptMedia(message)
  await client.reply(from,  '⏳ _Aguarde..._ ⏳\n*▻ !ci* deixa o sticker em circulo (somente imagens no momento) \n*▻ !s* deixa sticker resolução original\n*▻ !r* redimensiona o sticker\n*▻ !c* que corta o sticker\n*▻ !sticker (sua palavra)* faz um sticker com sua descrição, basta mandar imagem com o comando\n*▻ !roubar* para roubar marque um sticker com o comando !roubar (sua palavra), só não roubem figurinhas com descrição 🇯🇵⃟ ᴬᵗᵏ se não leva ban, o resto é liberado. ', message.id)
      const imageBase64 = `data:${mimetype};base64,${mediaData.toString('base64')}`
     
      await client.sendImageAsSticker(from, imageBase64, {discord: "568919637366931463", author: 'Lalatina BOT', crop: true, pack: '🌎Alliαηcє Oтαkus🇯🇵⃟ ᴬᵗᵏ\n http://bit.ly/AtkSS'})
  
     
   
    } else
   
   if (isMedia && mimetype == 'image/gif') {
      const mediaData = await decryptMedia(message)
       await client.reply(from,  '⏳ _Aguarde..._ ⏳\n*▻ !ci* deixa o sticker em circulo (somente imagens no momento) \n*▻ !s* deixa sticker resolução original\n*▻ !r* redimensiona o sticker\n*▻ !c* que corta o sticker\n*▻ !sticker (sua palavra)* faz um sticker com sua descrição, basta mandar imagem com o comando\n*▻ !roubar* para roubar marque um sticker com o comando !roubar (sua palavra), só não roubem figurinhas com descrição 🇯🇵⃟ ᴬᵗᵏ se não leva ban, o resto é liberado. ', message.id)
      const videoBase64 = `data:${mimetype};base64,${mediaData.toString('base64')}`
       
      await client.sendMp4AsSticker(from, videoBase64, {fps: 10, startTime: '00:00:00.0', endTime : '00:00:05.0', loop: 0, crop: true}, {discord: "568919637366931469", author: 'Lalatina BOT', crop: true, pack: '🌎Alliαηcє Oтαkus🇯🇵⃟ ᴬᵗᵏ \nhttp://bit.ly/AtkSS'})
    
    } else
    
   if (isMedia && mimetype == 'video/mp4') {
      const mediaData = await decryptMedia(message)
       await client.reply(from,  '⏳ _Aguarde..._ ⏳\n*▻ !ci* deixa o sticker em circulo (somente imagens no momento) \n*▻ !s* deixa sticker resolução original\n*▻ !r* redimensiona o sticker\n*▻ !c* que corta o sticker\n*▻ !sticker (sua palavra)* faz um sticker com sua descrição, basta mandar imagem com o comando\n*▻ !roubar* para roubar marque um sticker com o comando !roubar (sua palavra), só não roubem figurinhas com descrição 🇯🇵⃟ ᴬᵗᵏ se não leva ban, o resto é liberado. ', message.id)
      const videoBase64 = `data:${mimetype};base64,${mediaData.toString('base64')}`
      
      await client.sendMp4AsSticker(from, videoBase64, {fps: 10, startTime: '00:00:00.0', endTime : '00:00:05.0', loop: 0, crop: true}, {discord: "568919637366931469", author: 'Lalatina BOT', pack: '🌎Alliαηcє Oтαkus🇯🇵⃟ ᴬᵗᵏ \nhttp://bit.ly/AtkSS'})
      
   
     } else if (quotedMsg && quotedMsg.type == 'image') {
                const mediaData = await decryptMedia(quotedMsg, uaOverride)
        await client.reply(from, '⏳ _Aguarde..._ ⏳\n*▻ !ci* deixa o sticker em circulo (somente imagens no momento) \n*▻ !s* deixa sticker resolução original\n*▻ !r* redimensiona o sticker\n*▻ !c* que corta o sticker\n*▻ !sticker (sua palavra)* faz um sticker com sua descrição, basta mandar imagem com o comando\n*▻ !roubar* para roubar marque um sticker com o comando !roubar (sua palavra), só não roubem figurinhas com descrição 🇯🇵⃟ ᴬᵗᵏ se não leva ban, o resto é liberado. ', message.id)
      const imageBase64 = `data:${quotedMsgObj.mimetype};base64,${mediaData.toString('base64')}`
     
      await client.sendImageAsSticker(from, imageBase64, {discord: "568919637366931463", author: 'Lalatina BOT', crop: true, pack: '🌎Alliαηcє Oтαkus🇯🇵⃟ ᴬᵗᵏ\nhttp://bit.ly/AtkSS'}) 
  } else if (quotedMsg && quotedMsgObj.mimetype == 'image/gif') {
      const mediaData = await decryptMedia(quotedMsg)
     await client.reply(from, '⏳ _Aguarde..._ ⏳\n*▻ !ci* deixa o sticker em circulo (somente imagens no momento) \n*▻ !s* deixa sticker resolução original\n*▻ !r* redimensiona o sticker\n*▻ !c* que corta o sticker\n*▻ !sticker (sua palavra)* faz um sticker com sua descrição, basta mandar imagem com o comando\n*▻ !roubar* para roubar marque um sticker com o comando !roubar (sua palavra), só não roubem figurinhas com descrição 🇯🇵⃟ ᴬᵗᵏ se não leva ban, o resto é liberado. ', message.id)
      const videoBase64 = `data:${quotedMsgObj.mimetype};base64,${mediaData.toString('base64')}`
       
      await client.sendMp4AsSticker(from, videoBase64, {fps: 10, startTime: '00:00:00.0', endTime : '00:00:05.0', loop: 0, crop: true}, {discord: "568919637366931469", author: 'Lalatina BOT', crop: true, pack: '🌎Alliαηcє Oтαkus🇯🇵⃟ ᴬᵗᵏ\n http://bit.ly/AtkSS'})
       }else if (quotedMsg && quotedMsgObj.mimetype == 'video/mp4') {
      const mediaData = await decryptMedia(quotedMsg)
      await client.reply(from,  '⏳ _Aguarde..._ ⏳\n*▻ !ci* deixa o sticker em circulo (somente imagens no momento) \n*▻ !s* deixa sticker resolução original\n*▻ !r* redimensiona o sticker\n*▻ !c* que corta o sticker\n*▻ !sticker (sua palavra)* faz um sticker com sua descrição, basta mandar imagem com o comando\n*▻ !roubar* para roubar marque um sticker com o comando !roubar (sua palavra), só não roubem figurinhas com descrição 🇯🇵⃟ ᴬᵗᵏ se não leva ban, o resto é liberado.  ', message.id)
      const videoBase64 = `data:${quotedMsgObj.mimetype};base64,${mediaData.toString('base64')}`
       
      await client.sendMp4AsSticker(from, videoBase64, {fps: 10, startTime: '00:00:00.0', endTime : '00:00:05.0', loop: 0, crop: true}, {discord: "568919637366931469", author: 'Lalatina BOT', pack: '🌎Alliαηcє Oтαkus🇯🇵⃟ ᴬᵗᵏ \nhttp://bit.ly/AtkSS'})
      }}
             
              break 
               
    
                           case 'ci':
                  case 'stickercirculo':
             

//-----------------------processo-----------------------//

const fnBots4 = (fn = new Client()) => {
  fn.onStateChanged(function (state) {
    if (state === "UNLAUNCHED") {
      fn.forceRefocus()
    }
    if (state === "UNPAIRED") {}
  });
  fn.onMessage(async(message) => {
    try {
      await bot(fn, message)
    } catch (error) {
      console.log(error.message)
    }
    fn.getAmountOfLoadedMessages()
      .then((x) => {
        if (x >= 4000) {
          fn.sendText('xxx@c.us', `Loaded message reach ${x}, cutting message cache...`)
          fn.cutMsgCache()
          fn.cutMsgCache()
          fn.cutMsgCache()
          fn.cutMsgCache()
          fn.cutMsgCache()
          fn.cutMsgCache()
        }
      })
  });
}


 {
  
    
   if (isMedia && mimetype == 'image/jpeg')  {
      const mediaData = await decryptMedia(message)
  await client.reply(from, '⏳ _Aguarde..._ ⏳\n*▻ !ci* deixa o sticker em circulo (somente imagens no momento) \n*▻ !s* deixa sticker resolução original\n*▻ !r* redimensiona o sticker\n*▻ !c* que corta o sticker\n*▻ !sticker (sua palavra)* faz um sticker com sua descrição, basta mandar imagem com o comando\n*▻ !roubar* para roubar marque um sticker com o comando !roubar (sua palavra), só não roubem figurinhas com descrição 🇯🇵⃟ ᴬᵗᵏ se não leva ban, o resto é liberado. ', message.id)
      const imageBase64 = `data:${mimetype};base64,${mediaData.toString('base64')}`
     
      await client.sendImageAsSticker(from, imageBase64, {discord: "568919637366931463", author: 'Lalatina BOT', crop: true, circle: true, pack: '🌎Alliαηcє Oтαkus🇯🇵⃟ ᴬᵗᵏ\n http://bit.ly/AtkSS'})
  
     
   
    } else
   
   if (isMedia && mimetype == 'image/gif') {
      const mediaData = await decryptMedia(message)
       await client.reply(from,  '⏳ _Aguarde..._ ⏳\n*▻ !ci* deixa o sticker em circulo (somente imagens no momento) \n*▻ !s* deixa sticker resolução original\n*▻ !r* redimensiona o sticker\n*▻ !c* que corta o sticker\n*▻ !sticker (sua palavra)* faz um sticker com sua descrição, basta mandar imagem com o comando\n*▻ !roubar* para roubar marque um sticker com o comando !roubar (sua palavra), só não roubem figurinhas com descrição 🇯🇵⃟ ᴬᵗᵏ se não leva ban, o resto é liberado. ', message.id)
      const videoBase64 = `data:${mimetype};base64,${mediaData.toString('base64')}`
       
      await client.sendMp4AsSticker(from, videoBase64, {fps: 10, startTime: '00:00:00.0', endTime : '00:00:05.0', loop: 0, crop: true, circle: true}, {discord: "568919637366931469", author: 'Lalatina BOT', crop: true, pack: '🌎Alliαηcє Oтαkus🇯🇵⃟ ᴬᵗᵏ \nhttp://bit.ly/AtkSS'})
    
    } else
    
   if (isMedia && mimetype == 'video/mp4') {
      const mediaData = await decryptMedia(message)
       await client.reply(from,  '⏳ _Aguarde..._ ⏳\n*▻ !ci* deixa o sticker em circulo (somente imagens no momento) \n*▻ !s* deixa sticker resolução original\n*▻ !r* redimensiona o sticker\n*▻ !c* que corta o sticker\n*▻ !sticker (sua palavra)* faz um sticker com sua descrição, basta mandar imagem com o comando\n*▻ !roubar* para roubar marque um sticker com o comando !roubar (sua palavra), só não roubem figurinhas com descrição 🇯🇵⃟ ᴬᵗᵏ se não leva ban, o resto é liberado. ', message.id)
      const videoBase64 = `data:${mimetype};base64,${mediaData.toString('base64')}`
      
      await client.sendMp4AsSticker(from, videoBase64, {fps: 10, startTime: '00:00:00.0', endTime : '00:00:05.0', loop: 0, crop: true, circle: true}, {discord: "568919637366931469", author: 'Lalatina BOT', pack: '🌎Alliαηcє Oтαkus🇯🇵⃟ ᴬᵗᵏ \nhttp://bit.ly/AtkSS'})
      
   
     } else if (quotedMsg && quotedMsg.type == 'image') {
                const mediaData = await decryptMedia(quotedMsg, uaOverride)
        await client.reply(from,  '⏳ _Aguarde..._ ⏳\n*▻ !ci* deixa o sticker em circulo (somente imagens no momento) \n*▻ !s* deixa sticker resolução original\n*▻ !r* redimensiona o sticker\n*▻ !c* que corta o sticker\n*▻ !sticker (sua palavra)* faz um sticker com sua descrição, basta mandar imagem com o comando\n*▻ !roubar* para roubar marque um sticker com o comando !roubar (sua palavra), só não roubem figurinhas com descrição 🇯🇵⃟ ᴬᵗᵏ se não leva ban, o resto é liberado. ', message.id)
      const imageBase64 = `data:${quotedMsgObj.mimetype};base64,${mediaData.toString('base64')}`
     
      await client.sendImageAsSticker(from, imageBase64, {discord: "568919637366931463", author: 'Lalatina BOT', crop: true, circle: true, pack: '🌎Alliαηcє Oтαkus🇯🇵⃟ ᴬᵗᵏ\nhttp://bit.ly/AtkSS'}) 
  } else if (quotedMsg && quotedMsgObj.mimetype == 'image/gif') {
      const mediaData = await decryptMedia(quotedMsg)
     await client.reply(from,'⏳ _Aguarde..._ ⏳\n*▻ !ci* deixa o sticker em circulo (somente imagens no momento) \n*▻ !s* deixa sticker resolução original\n*▻ !r* redimensiona o sticker\n*▻ !c* que corta o sticker\n*▻ !sticker (sua palavra)* faz um sticker com sua descrição, basta mandar imagem com o comando\n*▻ !roubar* para roubar marque um sticker com o comando !roubar (sua palavra), só não roubem figurinhas com descrição 🇯🇵⃟ ᴬᵗᵏ se não leva ban, o resto é liberado. ', message.id)
      const videoBase64 = `data:${quotedMsgObj.mimetype};base64,${mediaData.toString('base64')}`
       
      await client.sendMp4AsSticker(from, videoBase64, {fps: 10, startTime: '00:00:00.0', endTime : '00:00:05.0', loop: 0, crop: true, circle: true}, {discord: "568919637366931469", author: 'Lalatina BOT', crop: true, pack: '🌎Alliαηcє Oтαkus🇯🇵⃟ ᴬᵗᵏ\n http://bit.ly/AtkSS'})
       }else if (quotedMsg && quotedMsgObj.mimetype == 'video/mp4') {
      const mediaData = await decryptMedia(quotedMsg)
      await client.reply(from,  '⏳ _Aguarde..._ ⏳\n*▻ !ci* deixa o sticker em circulo (somente imagens no momento) \n*▻ !s* deixa sticker resolução original\n*▻ !r* redimensiona o sticker\n*▻ !c* que corta o sticker\n*▻ !sticker (sua palavra)* faz um sticker com sua descrição, basta mandar imagem com o comando\n*▻ !roubar* para roubar marque um sticker com o comando !roubar (sua palavra), só não roubem figurinhas com descrição 🇯🇵⃟ ᴬᵗᵏ se não leva ban, o resto é liberado. ', message.id)
      const videoBase64 = `data:${quotedMsgObj.mimetype};base64,${mediaData.toString('base64')}`
       
      await client.sendMp4AsSticker(from, videoBase64, {fps: 10, startTime: '00:00:00.0', endTime : '00:00:05.0', loop: 0, crop: true, circle: true}, {discord: "568919637366931469", author: 'Lalatina BOT', pack: '🌎Alliαηcє Oтαkus🇯🇵⃟ ᴬᵗᵏ \nhttp://bit.ly/AtkSS'})
      }}
             
              break 
               
               
               
               
               //leandr
                case 'enviarbot':
               await client.reply(from, '_Aguarde, estou empacotando-me♥️..._', id)
            client.sendFile(from, './Lala-Bot3.0-r29.zip', 'Lala-Bot3.0-r29.zip')
            break
               
               case 'freefire':
             client.sendText(from, 'Como pegar mestre 😳️ 🐂️\n Aguarde...')
              await sleep(3000)
                client.sendText(from, 'Como ganhar dimas gratis 💎️😳️ 🐂️\n Aguarde...')
                 await sleep(3000)
                 
          await    client.sendPtt(from, './media/fogogratis.mp3', id)
           await sleep(1000)
                client.reply(from, 'Toma vergonha seu corno, vai jogar algo que preste.', id)
               
               break
                case 'bot':
		
            if (isGroupMsg) {
                
				if (triple == 1) {
					const bots = await axios.get('https://meme-api.herokuapp.com/gimme/GothGirls')
					await client.sendFileFromUrl(from, bots.data.url, '','*BOT 🔴️ ONLINE*\nMande a foto/gif/vídeo (evite ser maior do que 1.0mb) usando um  dos comandos:\n\n*▻ !ci* deixa o sticker em circulo (somente imagens no momento)\n*▻ !s*, fará sticker com proporção original\n*▻ !r*, fará sticker redimensionado\n*▻ !c* fará sticker com corte\n*▻ !sticker (sua palavra)* faz um sticker com corte com sua descrição\n*▻ !roubar*, para roubar marque um sticker o comando !roubar (palavra), só não roubem figurinhas com descrição 🇯🇵⃟ ᴬᵗᵏ se não leva ban o resto é liberado.      \n\n                                                 ```Obs: Ir pv do BOT vai tomar block ou ban. Bot exclusivo desse grupo, não compartilhe com ninguém. Outros comandos veja em !menu.```', id)
				} else if (triple == 2) {
					const bots1 = await axios.get('https://meme-api.herokuapp.com/gimme/animewallpaper')
					await client.sendFileFromUrl(from, bots1.data.url, '','*BOT 🔴️ ONLINE*\nMande a foto/gif/vídeo (evite ser maior do que 1.0mb) usando um  dos comandos:\n\n*▻ !ci* deixa o sticker em circulo (somente imagens no momento)\n*▻ !s*, fará sticker com proporção original\n*▻ !r*, fará sticker redimensionado\n*▻ !c* fará sticker com corte\n*▻ !sticker (sua palavra)* faz um sticker com corte com sua descrição\n*▻ !roubar*, para roubar marque um sticker o comando !roubar (palavra), só não roubem figurinhas com descrição 🇯🇵⃟ ᴬᵗᵏ se não leva ban o resto é liberado.      \n\n                                                 ```Obs: Ir pv do BOT vai tomar block ou ban. Bot exclusivo desse grupo, não compartilhe com ninguém. Outros comandos veja em !menu.```', id)
				} else if (triple == 3) {
					const bots3 = await axios.get('https://nekos.life/api/v2/img/waifu')
					await client.sendFileFromUrl(from, bots3.data.url,'','*BOT 🔴️ ONLINE*\nMande a foto/gif/vídeo (evite ser maior do que 1.0mb) usando um  dos comandos:\n\n*▻ !ci* deixa o sticker em circulo (somente imagens no momento)\n*▻ !s*, fará sticker com proporção original\n*▻ !r*, fará sticker redimensionado\n*▻ !c* fará sticker com corte\n*▻ !sticker (sua palavra)* faz um sticker com corte com sua descrição\n*▻ !roubar*, para roubar marque um sticker o comando !roubar (palavra), só não roubem figurinhas com descrição 🇯🇵⃟ ᴬᵗᵏ se não leva ban o resto é liberado.      \n\n                                                 ```Obs: Ir pv do BOT vai tomar block ou ban. Bot exclusivo desse grupo, não compartilhe com ninguém. Outros comandos veja em !menu.```', id)
				}
			} else {
				if (triple == 1) {
					const bots = await axios.get('https://meme-api.herokuapp.com/gimme/GothGirls')
					await client.sendFileFromUrl(from, bots.data.url, '','*BOT 🔴️ ONLINE*\nMande a foto/gif/vídeo (evite ser maior do que 1.0mb) usando um  dos comandos:\n\n*▻ !ci* deixa o sticker em circulo (somente imagens no momento)\n*▻ !s*, fará sticker com proporção original\n*▻ !r*, fará sticker redimensionado\n*▻ !c* fará sticker com corte\n*▻ !sticker (sua palavra)* faz um sticker com corte com sua descrição\n*▻ !roubar*, para roubar marque um sticker o comando !roubar (palavra), só não roubem figurinhas com descrição 🇯🇵⃟ ᴬᵗᵏ se não leva ban o resto é liberado.      \n\n                                                 ```Obs: Ir pv do BOT vai tomar block ou ban. Bot exclusivo desse grupo, não compartilhe com ninguém. Outros comandos veja em !menu.```', id)
				} else if (triple == 2) {
					const bots1 = await axios.get('https://meme-api.herokuapp.com/gimme/animewallpaper')
					await client.sendFileFromUrl(from, bots1.data.url, '','*BOT 🔴️ ONLINE*\nMande a foto/gif/vídeo (evite ser maior do que 1.0mb) usando um  dos comandos:\n\n*▻ !ci* deixa o sticker em circulo (somente imagens no momento)\n*▻ !s*, fará sticker com proporção original\n*▻ !r*, fará sticker redimensionado\n*▻ !c* fará sticker com corte\n*▻ !sticker (sua palavra)* faz um sticker com corte com sua descrição\n*▻ !roubar*, para roubar marque um sticker o comando !roubar (palavra), só não roubem figurinhas com descrição 🇯🇵⃟ ᴬᵗᵏ se não leva ban o resto é liberado.      \n\n                                                 ```Obs: Ir pv do BOT vai tomar block ou ban. Bot exclusivo desse grupo, não compartilhe com ninguém. Outros comandos veja em !menu.```', id)
				} else if (triple == 3) {
					const bots3 = await axios.get('https://nekos.life/api/v2/img/waifu')
					await client.sendFileFromUrl(from, bots3.data.url, '','*BOT 🔴️ ONLINE*\nMande a foto/gif/vídeo (evite ser maior do que 1.0mb) usando um  dos comandos:\n\n*▻ !ci* deixa o sticker em circulo (somente imagens no momento)\n*▻ !s*, fará sticker com proporção original\n*▻ !r*, fará sticker redimensionado\n*▻ !c* fará sticker com corte\n*▻ !sticker (sua palavra)* faz um sticker com corte com sua descrição\n*▻ !roubar*, para roubar marque um sticker o comando !roubar (palavra), só não roubem figurinhas com descrição 🇯🇵⃟ ᴬᵗᵏ se não leva ban o resto é liberado.      \n\n                                                 ```Obs: Ir pv do BOT vai tomar block ou ban. Bot exclusivo desse grupo, não compartilhe com ninguém. Outros comandos veja em !menu.```', id)
				}
			}
			break
			case 'gotica':
			case 'gótica':
			const goth1 = await axios.get('https://meme-api.herokuapp.com/gimme/GothGirls')
					await client.sendFileFromUrl(from, goth1.data.url, '', '')
			
			const goth = await axios.get('https://meme-api.herokuapp.com/gimme/prettyaltgirls')
					await client.sendFileFromUrl(from, goth.data.url, '', '🖤\n🌎Alliαηce Oтαkus🇯🇵⃟ ᴬᵗᵏ', id)
					
					break
					
                 case 'casar':
            casar = body.trim().split(' ')
			if (args.length == 1) {
				const persona = author.replace('@c.us', '')
				client.sendTextWithMentions(from, '*════◄••❀💌❀••►════*\nA vida é feita de momentos bons e ruins. Aproveitem intensamente os bons e estejam unidos para superar os ruins. Assim se constrói um casamento duradouro e feliz.\n\n❤️ @' + persona + '  casou com ' + casar[1] + '\nParabéns! 👏🏻\n\n _Eu lhe desejo tudo o que há de melhor! Que esta nova etapa, junto da pessoa que você ama, seja para sempre e sempre nela reinem a harmonia, o amor, a amizade e o companheirismo._\n_Dividir a vida com alguém é muito mais do que compartilhar a mesma casa. Para ter um casamento feliz é necessário muito amor, respeito, fidelidade e paciência para aceitar os defeitos um do outro. Sejam muito felizes!_\n════◄••❀💌❀••►════')
               
               }
               break

		case 'verdade':
		case 'mentira':
            if (double == 1) {
            await client.reply(from, 'Verdade. Confirmo. ', id)
            } else if (double == 2) {
            await client.reply(from, 'Mentira. Que coisa mentirosa.', id)
			}
			break
                     case 'blocklist':
            case 'listanegra':
            
					
					let mort = `*Esta é a lista de números mortos(bloqueados) pela Lalatina BOT:*\nTotal de ${blockNumber.length} de infelizes que não verão mais a linda face de Lala.\n\n`
				for (let i of blockNumber) { mort += `✞⚰️ @${i.replace(/@c.us/g,'')}\n` }
				await client.sendTextWithMentions(from, mort)
					
					break
               
                  case 'trava':
                  await client.sendText(from,"5")
                   await sleep(1000)
                   await client.sendText(from,"4")
                    await sleep(1000)
                    await client.sendText(from,"3")
                     await sleep(1000)
                     await client.sendText(from,"2")
                     await sleep(1000) 
                     await client.sendText(from,"1")
                     
               await client.sendText(from,"Goooo!")
     await client.sendText(from,"😃⃢ᣳ⃟ᣳ⃟ᣳ⃟ᣳ⃟⃟ᣳ⃟ᣳ⃟ᣳ⃟ᣳ⃟ᣳᣳ⃟ᣳ⃟ᣳ⃟ᣳ⃟⃟ᣳ⃟ᣳ⃟ᣳ⃟ᣳ⃟ᣳ🤡̵̛͔͍̱͙̥͔̯͖̥͙̲͆ͬ̊̑🤡̵̛͔͍̱͙̥͔̯͖̥͙̲͆ͬ̊̑̔̂:ᣳ⃟ᣳ⃟ᣳ⃟ᣳ⃟⃟ᣳ⃟ᣳ⃟ᣳ⃟ᣳ⃟ꮎᷛ😈⃟⃢𖢄࿐ℒꮠ͙ͭꮮͤӃꮛ͙ͦꮎᷛ😈⃟⃢𖢄࿐྄ོོྀུྂꮎᷛ👾\n😃⃢ᣳ⃟🤡̵̛͔͍̱͙\n 😃⃢ᣳ⃟ᣳ⃟ᣳ⃟ᣳ⃟⃟ᣳ⃟ᣳ⃟ᣳ⃟ᣳ⃟ᣳᣳ⃟ᣳ⃟ᣳ⃟ᣳ⃟⃟ᣳ⃟ᣳ⃟ᣳ⃟ᣳ⃟ᣳ🤡̵̛͔͍̱͙̥͔̯͖̥͙̲͆ͬ̊̑🤡̵̛͔͍̱͙̥͔̯͖̥͙̲͆ͬ̊̑̔̂:ᣳ⃟ᣳ⃟ᣳ⃟⃟ᣳ⃟ᣳ⃟ᣳ⃟ᣳ⃟ꮎᷛ😈⃟⃢𖢄࿐ℒꮠ͙ͭꮮͤӃꮛ͙ͦꮎᷛ😈⃟⃢𖢄࿐྄ོོྀུྂꮎᷛ👾😃⃢ᣳ⃟🤡̵̛͔͍̱͙ \n\n\nCALMA RAPAZIADA,TO PASSANDO AKI SÓ PARA LEMBRAR VCS DE TOMAR ÁGUA  KKKKK\nCÓPIA E E MANDA EM OUTRO GRUPO TMJ 🐦🐦̵̛͔͍̱͙")         
     break
       
     
     
     
      
        case 'escolha':
			if (!isGroupMsg) return client.reply(from, '!escolha _[sua frase]_', id) 
            const memran = await client.getGroupMembers(groupId)
            const randme = memran[Math.floor(Math.random() * memran.length)]
			console.log(randme.id)
            await client.sendTextWithMentions(from, `═✪〘 Você foi escolhido(a)! 〙✪═ \n\n @${randme.id.replace(/@c.us/g, '')}\n\n Para: ${body.slice(8)} `)
            
            await sleep(2000)
            break
            case 'moe':
            const animefof= await axios.get('https://meme-api.herokuapp.com/gimme/awwnime')
					await client.sendFileFromUrl(from, animefof.data.url, '','Moee\n🌎Alliαηce Oтαkus🇯🇵⃟ ᴬᵗᵏ', id)
            
            break
            
              case 'divinomoe':
            const divinef= await axios.get('https://meme-api.herokuapp.com/gimme/DivineMoe')
					await client.sendFileFromUrl(from, divinef.data.url, '','', id)
             const divinefd= await axios.get('https://meme-api.herokuapp.com/gimme/DivineMoe')
					await client.sendFileFromUrl(from, divinefd.data.url, '','😇️\n🌎Alliαηce Oтαkus🇯🇵⃟ ᴬᵗᵏ', id)
            break
              case 'anjo':
            const divine1f= await axios.get('https://meme-api.herokuapp.com/gimme/animeangels')
					await client.sendFileFromUrl(from, divine1f.data.url, '','👐️\n🌎Alliαηce Oтαkus🇯🇵⃟ ᴬᵗᵏ', id)
            break
        case 'invocação':
			if (!isGroupMsg) return client.reply(from, mess.error.Gp, id) 
            const memran1 = await client.getGroupMembers(groupId)
            const randme1 = memran1[Math.floor(Math.random() * memran1.length)]
			
		await	 client.sendVideoAsGif(from, './media/jutsu.mp4', '', '\nK u c h i y o s e • n o • J u t s u\n\n\n\n\n\n\n\n-̵̸̵̵̢͙͙̠͕͓͎̙͔͐̐̀͛̐̓̾̿̚͘͜͝-̴̵̸̸̡̡̠̺̝͙͚͍̘̻͍͎̓̒͒͋̒̈́̀͐̽̚͝-̴̴̸̴̡̪̪̟̦̺̙͓͉̻͙͆͐͒͑̓͒̾̚͠͠-̴̴̸̸̪̪͕͖͇̝̼̟̦̓̔͌́̓͑͐̿̐̔̾̿͜-̸̵̴̸̢͉͖͍͙̼̝̫͕̞͍͐̿͐͋͋͆̾́̾͠͠-̴̴̸̸̡̻͙̪͉̠͕͙̦̝̟͒̿̿͋̾͆͐̓̀̈́͝͝-̴̵̵̵͎͕͍̻̺͇̪̘̞̪͍̻̾̽̽͊̓̽͒͌̈́͋̕͠-̸̴̴̸̡͍̘̠͙͓̞̘̠̦͎̔̓͛͆̔̐̈́̕͠͝͝-̴̸̸̸͖͚͕̝̻͔̼͔̘̔͊͒̐̽͌̿̾͐̿̚͜͝𒅒̴̴̸̸̢̢͙̪̙̠̦͖̞̙̺͇͑͛͒̓͛̓̽̐̽̕͠-̴̸̸̵̺̦̼͙̦͚͖̻͉̦͊͐͆̐͛̒̾̒̚̚͘͝-̸̸̸̸̢̻̼̝̼͓̼̞͙̙̙͐̒͐̔̓̔̔̐̚͝͝-̵̸̴̸͔͖̻̦̦̞̝̺̟͍̈́́͋̐͒̓͌̀̾̚͘͜͝-̵̸̸̸̡̻̫͚͚̼̺̼̞̈́͊̀̀͊̾̔̔͒͑̔͜͠-̸̴̸̴̡͍̼̞̪̘̞͖͔̞̫̼͛́̀͒̒̀̽͋̓̈́̕̕-̸̴̴̸̡̟̺̘̻̫̟͕̘̺́̓͌͒̀̽͛͋͑̕͘͜͝-̴̴̵̵͍̘͔͇̻̙̼͚̼̞̼̽̓͌̀͑̽͛͛͋̒͌͌-̴̸̴̵̪̫̘̠͍̦͇͕̪̠̫̝͊͆͊̒̒̾̀̓̿͝͠͝-̸̸̵̸͇̼͚̫͓̟̟͉͍͓͒̾͌͌͊͋͊̿͋̓̓̕͜͜\n\n\n\n\n\n\n')
			 
			  
          client.sendTextWithMentions(from, `@${randme1.id.replace(/@c.us/g, '')}💨️💨️ Foi invocado`)
            
            await sleep(2000)
            break
                     case 'cantar':
			 arg = body.trim().split(' ')
			const rcanta = fs.readFileSync('./lib/cantadas.txt').toString().split('\n')
			const rsudd = rcanta[Math.floor(Math.random() * rcanta.length)]
			console.log(rsudd)
			await client.sendTextWithMentions(from, arg[1] + rsudd )
			break
               
               	case 'addcantada':
			if (args.length == 0) return client.reply(from, 'Faltou a frase para ser adicionada.', id)
			fs.appendFile('./lib/cantadas.txt', `\n${body.slice(10)}`)
			await client.reply(from, 'Frase adicionada ao bot.', id)
			break
			  case 'ava':
			 if (!isBotGroupAdmins) return client.reply(from, 'Somente ADMs', id)
			await client.sendFile(from, './avaliacao.txt', 'Avaliação.txt' )
			
			break
			case 'avalie':
			if (args.length == 0) return client.reply(from, 'Faltou a texto para ser adicionada. Ex.: !avalie Bom grupo, me divirto muito, mas eu queria tal coisa, etc.', id)
			fs.appendFile('./avaliacao.txt', `\n${body.slice(10)}`)
			await client.reply(from, '_✅️Foi enviado aos ADMs do grupo, obrigada._', id)
			break
			          case 'baternopopo':
            arg = body.trim().split(' ')
            const person1 = author.replace('@c.us', '')
            await client.sendGiphyAsSticker(from, 'https://media.giphy.com/media/i1yHbcMMv37KBuzAFo/giphy.gif')
            client.sendTextWithMentions(from, '@' + person1 + ' *batendo na bundinha de* ' + arg[1])
            break
                 
        case 'rebolar':
            arg = body.trim().split(' ')
            const person2 = author.replace('@c.us', '')
             await client.sendGiphyAsSticker(from, 'https://media.giphy.com/media/qVhcrMQpYCd0QdeyKP/giphy.gif')
            await  client.sendTextWithMentions(from, '@' + person2 + 'a rebolar para😘' + arg[1])
            break 
             	
               
                  case 'link':
                 await    client.sendLinkWithAutoPreview(from, "http://linktr.ee/allianceotakus" )
               
               break
                 case 'casal' :
            if (!isGroupMsg) return client.reply(from, 'Apenas grupos!', id)
			await client.reply(from, '_A Cupido 👼 está a procurar o casal..._', id)
            await sleep(3500)
            const eu1 = await client.getGroupMembers(groupId)
            const casal1 = eu1[Math.floor(Math.random() * eu1.length)]
            const casal2 = eu1[Math.floor(Math.random() * eu1.length)]
		
            await client.sendTextWithMentions(from, `*════◄••❀💌❀••►════*\n_A Cupido analisou os membros e achei o par ideal:_\n\n❤️@${casal1.id.replace(/@c.us/g, '')} e @${casal2.id.replace(/@c.us/g, '')} ❤️\n*Parabéns!* 👏🏻\n\n_Eu lhe desejo tudo o que há de melhor! Que esta nova etapa, junto da pessoa que você ama, seja para sempre e sempre nela reinem a harmonia, o amor, a amizade e o companheirismo._\n_Que junto da pessoa a quem unirá sua vida, construa uma família linda e abençoada, pois vocês merecem que todos os seus sonhos se tornem realidade. Sejam muito felizes!_`)
            await sleep(2000)
            break	     
                    
                            case 'chupar':
                               if (isGroupMsg && !isNsfw) return await client.reply(from,'_Negado._', id)
            arqa = body.trim().split(' ')
			if (args.length == 1) {
				const persona = author.replace('@c.us', '')
				client.sendTextWithMentions(from, '@' + persona + ' dando uma chupadinha em ' + arqa[1] + ' 👅')
	
				            const list = ["./media/chupa1.mp4", "./media/chupa2.mp4", "./media/chupa3.mp4", "./media/chupa4.mp4","./media/chupa5.mp4","./media/chupa6.mp4", "./media/chupa7.mp4","./media/chupa8.mp4","./media/chupa9.mp4","./media/chupa10.mp4","./media/chupa11.mp4","./media/chupa12.mp4","./media/chupa13.mp4","./media/chupa14.mp4","./media/chupa15.mp4","./media/chupa16.mp4","./media/chupa17.mp4","./media/chupa18.mp4","./media/chupa19.mp4","./media/chupa20.mp4","./media/chupa21.mp4","./media/chupa22.mp4","./media/chupa23.mp4","./media/chupa24.mp4","./media/chupa25.mp4","./media/chupa26.mp4","./media/chupa27.mp4","./media/chupa28.mp4", ]
            let kya = list[Math.floor(Math.random() * list.length)]
           client.sendVideoAsGif(from, kya, 'chup.mp4', '', id)
				
			
            }
			break
					
			case 'rl':
				if (isQuotedSticker ) {
					await client.reply(from, 'ADM Roubando...', id)
					const stickerMeta = await decryptMedia(quotedMsg)
					await client.sendImageAsSticker(from, `data:${quotedMsg.mimetype};base64,${stickerMeta.toString('base64')}`, { author: '🌍Alliance🇯🇵⃟ ᴬᵗᵏ\n⤷ bit.ly/AtkSS', pack: 'LҽαղժɾօCS  ☧ ⃟ ᴬᵗᵏ  ' })
				} else return await client.reply(from, '.', id)
				break
				
				case 'rk':
				if (isQuotedSticker ) {
					await client.reply(from, 'ADM Roubando...', id)
					const stickerMeta = await decryptMedia(quotedMsg)
					await client.sendImageAsSticker(from, `data:${quotedMsg.mimetype};base64,${stickerMeta.toString('base64')}`, { author: 'Cranel 🇯🇵⃟ ᴬᵗᵏ ', pack: '🌍Alliance🇯🇵⃟ ᴬᵗᵏ\n⤷ bit.ly/AtkSS' })
				} else return await client.reply(from, '.', id)
				break
				case 'roubar':
				if (isQuotedSticker ) {
				// arqa = body.trim().split(' ')
					await client.reply(from,  '⏳ _Aguarde..._ ⏳\n*▻ !ci* deixa o sticker em circulo (somente imagens no momento) \n*▻ !s* deixa sticker resolução original\n*▻ !r* redimensiona o sticker\n*▻ !c* que corta o sticker\n*▻ !sticker (sua palavra)* faz um sticker com sua descrição, basta mandar imagem com o comando\n*▻ !roubar* para roubar marque um sticker com o comando !roubar (sua palavra), só não roubem figurinhas com descrição 🇯🇵⃟ ᴬᵗᵏ se não leva ban, o resto é liberado. ', id)
					const stickerMeta = await decryptMedia(quotedMsg)
					await client.sendImageAsSticker(from, `data:${quotedMsg.mimetype};base64,${stickerMeta.toString('base64')}`, { author: body.slice(7), pack: '🌍Alliance🇯🇵⃟ ᴬᵗᵏ\n ⤷bit.ly/AtkSS' })
				} else return await client.reply(from, '_Para roubar marque um sticker o comando !roubar (palavra), só não roubem figurinhas com descrição 🇯🇵⃟ ᴬᵗᵏ se não leva ban o resto é liberado._', id)
				                  
				break
				      case 'sticker':
              case 'stickers':
    
   if (isMedia && mimetype == 'image/jpeg')  {
      const mediaData = await decryptMedia(message)
  await client.reply(from, '⏳ _Aguarde..._ ⏳\n*▻ !ci* deixa o sticker em circulo (somente imagens no momento) \n*▻ !s* deixa sticker resolução original\n*▻ !r* redimensiona o sticker\n*▻ !c* que corta o sticker\n*▻ !sticker (sua palavra)* faz um sticker com sua descrição, basta mandar imagem com o comando\n*▻ !roubar* para roubar marque um sticker com o comando !roubar (sua palavra), só não roubem figurinhas com descrição 🇯🇵⃟ ᴬᵗᵏ se não leva ban, o resto é liberado. ', message.id)
      const imageBase64 = `data:${mimetype};base64,${mediaData.toString('base64')}`
     
      await client.sendImageAsSticker(from, imageBase64, {discord: "568919637366931463", author:  body.slice(9), pack: '🌍Alliance🇯🇵⃟ ᴬᵗᵏ\n⤷ bit.ly/AtkSS'})
  
     
   
    } else
   
   if (isMedia && mimetype == 'image/gif') {
      const mediaData = await decryptMedia(message)
       await client.reply(from,  '⏳ _Aguarde..._ ⏳\n*▻ !ci* deixa o sticker em circulo (somente imagens no momento) \n*▻ !s* deixa sticker resolução original\n*▻ !r* redimensiona o sticker\n*▻ !c* que corta o sticker\n*▻ !sticker (sua palavra)* faz um sticker com sua descrição, basta mandar imagem com o comando\n*▻ !roubar* para roubar marque um sticker com o comando !roubar (sua palavra), só não roubem figurinhas com descrição 🇯🇵⃟ ᴬᵗᵏ se não leva ban, o resto é liberado. ', message.id)
      const videoBase64 = `data:${mimetype};base64,${mediaData.toString('base64')}`
       
      await client.sendMp4AsSticker(from, videoBase64, {fps: 10, startTime: '00:00:00.0', endTime : '00:00:05.0', loop: 0}, {discord: "568919637366931469", author:  body.slice(9),  pack: '🌍Alliance🇯🇵⃟ ᴬᵗᵏ\n⤷ bit.ly/AtkSS'})
    
    } else
    
   if (isMedia && mimetype == 'video/mp4') {
      const mediaData = await decryptMedia(message)
       await client.reply(from,  '⏳ _Aguarde..._ ⏳\n*▻ !ci* deixa o sticker em circulo (somente imagens no momento) \n*▻ !s* deixa sticker resolução original\n*▻ !r* redimensiona o sticker\n*▻ !c* que corta o sticker\n*▻ !sticker (sua palavra)* faz um sticker com sua descrição, basta mandar imagem com o comando\n*▻ !roubar* para roubar marque um sticker com o comando !roubar (sua palavra), só não roubem figurinhas com descrição 🇯🇵⃟ ᴬᵗᵏ se não leva ban, o resto é liberado. ', message.id)
      const videoBase64 = `data:${mimetype};base64,${mediaData.toString('base64')}`
      
      await client.sendMp4AsSticker(from, videoBase64, {fps: 10, startTime: '00:00:00.0', endTime : '00:00:05.0', loop: 0}, {discord: "568919637366931469", author:  body.slice(9), pack:'🌍Alliance🇯🇵⃟ ᴬᵗᵏ\n⤷ bit.ly/AtkSS'})
      
   
     } else if (quotedMsg && quotedMsg.type == 'image') {
                const mediaData = await decryptMedia(quotedMsg, uaOverride)
        await client.reply(from, '⏳ _Aguarde..._ ⏳\n*▻ !ci* deixa o sticker em circulo (somente imagens no momento) \n*▻ !s* deixa sticker resolução original\n*▻ !r* redimensiona o sticker\n*▻ !c* que corta o sticker\n*▻ !sticker (sua palavra)* faz um sticker com sua descrição, basta mandar imagem com o comando\n*▻ !roubar* para roubar marque um sticker com o comando !roubar (sua palavra), só não roubem figurinhas com descrição 🇯🇵⃟ ᴬᵗᵏ se não leva ban, o resto é liberado. ', message.id)
      const imageBase64 = `data:${quotedMsgObj.mimetype};base64,${mediaData.toString('base64')}`
     
      await client.sendImageAsSticker(from, imageBase64, {discord: "568919637366931463", author:  body.slice(9), pack: '🌍Alliance🇯🇵⃟ ᴬᵗᵏ\n⤷ bit.ly/AtkSS'}) 
  } else if (quotedMsg && quotedMsgObj.mimetype == 'image/gif') {
      const mediaData = await decryptMedia(quotedMsg)
     await client.reply(from,  '⏳ _Aguarde..._ ⏳\n*▻ !ci* deixa o sticker em circulo (somente imagens no momento) \n*▻ !s* deixa sticker resolução original\n*▻ !r* redimensiona o sticker\n*▻ !c* que corta o sticker\n*▻ !sticker (sua palavra)* faz um sticker com sua descrição, basta mandar imagem com o comando\n*▻ !roubar* para roubar marque um sticker com o comando !roubar (sua palavra), só não roubem figurinhas com descrição 🇯🇵⃟ ᴬᵗᵏ se não leva ban, o resto é liberado. ', message.id)
      const videoBase64 = `data:${quotedMsgObj.mimetype};base64,${mediaData.toString('base64')}`
       
      await client.sendMp4AsSticker(from, videoBase64, {fps: 10, startTime: '00:00:00.0', endTime : '00:00:05.0', loop: 0 }, {discord: "568919637366931469", author:  body.slice(9) , pack: '🌍Alliance🇯🇵⃟ ᴬᵗᵏ\n⤷ bit.ly/AtkSS'})
       } else if (quotedMsg && quotedMsgObj.mimetype == 'video/mp4') {
      const mediaData = await decryptMedia(quotedMsg)
      await client.reply(from,  '⏳ _Aguarde..._ ⏳\n*▻ !ci* deixa o sticker em circulo (somente imagens no momento) \n*▻ !s* deixa sticker resolução original\n*▻ !r* redimensiona o sticker\n*▻ !c* que corta o sticker\n*▻ !sticker (sua palavra)* faz um sticker com sua descrição, basta mandar imagem com o comando\n*▻ !roubar* para roubar marque um sticker com o comando !roubar (sua palavra), só não roubem figurinhas com descrição 🇯🇵⃟ ᴬᵗᵏ se não leva ban, o resto é liberado. ', message.id)
      const videoBase64 = `data:${quotedMsgObj.mimetype};base64,${mediaData.toString('base64')}`
       
      await client.sendMp4AsSticker(from, videoBase64, {fps: 10, startTime: '00:00:00.0', endTime : '00:00:05.0', loop: 0, crop: true}, {discord: "568919637366931469", author:  body.slice(9), pack: '🌍Alliance🇯🇵⃟ ᴬᵗᵏ\n⤷ bit.ly/AtkSS'})
      }
             
              break 
               
		
			        case 'oppai':
			        
           
                   if (isGroupMsg && !isNsfw) return await client.reply(from,'_Negado._', id) 
           
			if (octo == 1) {
				const tits = await axios.get('https://meme-api.herokuapp.com/gimme/Oppai')
				client.sendFileFromUrl(from, tits.data.url, '', '🌎Alliαηce Oтαkus🇯🇵⃟ ᴬᵗᵏ', id)
			} else if (octo == 2) {
				const tits = await axios.get('https://meme-api.herokuapp.com/gimme/OppaiLove')
				client.sendFileFromUrl(from, tits.data.url, '', '🌎Alliαηce Oтαkus🇯🇵⃟ ᴬᵗᵏ', id)
			} else if (octo == 3) {
				const tits = await axios.get('https://meme-api.herokuapp.com/gimme/oppai_gif')
				client.sendFileFromUrl(from, tits.data.url, '', '🌎Alliαηce Oтαkus🇯🇵⃟ ᴬᵗᵏ', id)
			} else if (octo == 4) {
				const tits = await axios.get('https://meme-api.herokuapp.com/gimme/OppaiHentai')
				client.sendFileFromUrl(from, tits.data.url, '', '🌎Alliαηce Oтαkus🇯🇵⃟ ᴬᵗᵏ', id)
			} else if (octo == 5) {
				const tits = await axios.get('https://meme-api.herokuapp.com/gimme/OppaiHentai')
				client.sendFileFromUrl(from, tits.data.url, '', '🌎Alliαηce Oтαkus🇯🇵⃟ ᴬᵗᵏ', id)
			} else if (octo == 6) {
				const tits = await axios.get('https://meme-api.herokuapp.com/gimme/OppaiHentai')
				client.sendFileFromUrl(from, tits.data.url, '', '🌎Alliαηce Oтαkus🇯🇵⃟ ᴬᵗᵏ', id)
			l(from, tits.data.url, '', '🌎Alliαηce Oтαkus🇯🇵⃟ ᴬᵗᵏ', id)
			}
			
                    break
                    
                   
                                           case 'maid':
             
                  if (isGroupMsg && !isNsfw) return await client.reply(from,'_Negado._', id)
           
			if (octo == 1) {
				const maid = await axios.get('https://meme-api.herokuapp.com/gimme/Maidsex')
				client.sendFileFromUrl(from, maid.data.url, '', '🌎Alliαηce Oтαkus🇯🇵⃟ ᴬᵗᵏ', id)
			} else if (octo == 2) {
				const maid = await axios.get('https://meme-api.herokuapp.com/gimme/frenchmaid')
				client.sendFileFromUrl(from, maid.data.url, '', '🌎Alliαηce Oтαkus🇯🇵⃟ ᴬᵗᵏ', id)
			} else if (octo == 3) {
				const maid = await axios.get('https://meme-api.herokuapp.com/gimme/MaidHentai')
				client.sendFileFromUrl(from, maid.data.url, '', '🌎Alliαηce Oтαkus🇯🇵⃟ ᴬᵗᵏ', id)
			} else if (octo == 4) {
				const maid = await axios.get('https://meme-api.herokuapp.com/gimme/Maidsex')
				client.sendFileFromUrl(from, maid.data.url, '', '🌎Alliαηce Oтαkus🇯🇵⃟ ᴬᵗᵏ', id)
			} else if (octo == 5) {
				const maid = await axios.get('https://meme-api.herokuapp.com/gimme/MaidHentai')
				client.sendFileFromUrl(from, maid.data.url, '', '🌎Alliαηce Oтαkus🇯🇵⃟ ᴬᵗᵏ', id)
			} else if (octo == 6) {
				const maid = await axios.get('https://meme-api.herokuapp.com/gimme/Maidsex')
				client.sendFileFromUrl(from, maid.data.url, '', '🌎Alliαηce Oтαkus🇯🇵⃟ ᴬᵗᵏ', id)
				} else if (octo == 7) {
				const maid = await axios.get('https://meme-api.herokuapp.com/gimme/frenchmaid')
				client.sendFileFromUrl(from, maid.data.url, '', '🌎Alliαηce Oтαkus🇯🇵⃟ ᴬᵗᵏ', id)
			
			}
			
                    break
                      case 'milf':
             
                  if (isGroupMsg && !isNsfw) return await client.reply(from,'_Negado._', id)
           
			
				const milf = await axios.get('https://meme-api.herokuapp.com/gimme/milf')
				client.sendFileFromUrl(from, milf.data.url, '', '🌎Alliαηce Oтαkus🇯🇵⃟ ᴬᵗᵏ')
				const milf1 = await axios.get('https://meme-api.herokuapp.com/gimme/hotmoms')
				client.sendFileFromUrl(from, milf1.data.url, '', '🌎Alliαηce Oтαkus🇯🇵⃟ ᴬᵗᵏ', id)
                            break
                            case 'cosplay18':
           
                    if (isGroupMsg && !isNsfw) return await client.reply(from,'_Negado._', id)
           
			if (octo == 1) {
				const cos1 = await axios.get('https://meme-api.herokuapp.com/gimme/cosplaygirls')
				client.sendFileFromUrl(from, cos1.data.url, '', '🌎Alliαηce Oтαkus🇯🇵⃟ ᴬᵗᵏ', id)
			} else if (octo == 2) {
				const cos1 = await axios.get('https://meme-api.herokuapp.com/gimme/CosplayBoobs')
				client.sendFileFromUrl(from, cos1.data.url, '', '🌎Alliαηce Oтαkus🇯🇵⃟ ᴬᵗᵏ', id)
			} else if (octo == 3) {
				const cos1 = await axios.get('https://meme-api.herokuapp.com/gimme/CosplayPornVideos')
				client.sendFileFromUrl(from, cos1.data.url, '', '🌎Alliαηce Oтαkus🇯🇵⃟ ᴬᵗᵏ', id)
			} else if (octo == 4) {
				const cos1 = await axios.get('https://meme-api.herokuapp.com/gimme/cosplaybabes')
				client.sendFileFromUrl(from, cos1.data.url, '', '🌎Alliαηce Oтαkus🇯🇵⃟ ᴬᵗᵏ', id)
			} else if (octo == 5) {
				const cos1 = await axios.get('https://meme-api.herokuapp.com/gimme/nsfwcosplay')
				client.sendFileFromUrl(from, cos1.data.url, '', '🌎Alliαηce Oтαkus🇯🇵⃟ ᴬᵗᵏ', id)
			} else if (octo == 6) {
				const cos1 = await axios.get('https://meme-api.herokuapp.com/gimme/cosplaybutts')
				client.sendFileFromUrl(from, cos1.data.url, '', '🌎Alliαηce Oтαkus🇯🇵⃟ ᴬᵗᵏ', id)
				} else if (octo == 7) {
				const cos1 = await axios.get('https://meme-api.herokuapp.com/gimme/CosplayLewd')
				client.sendFileFromUrl(from, cos1.data.url, '', '🌎Alliαηce Oтαkus🇯🇵⃟ ᴬᵗᵏ', id)
			
			}
			
                    break
                    case 'cosplay':
           
                 const cos = await axios.get('https://meme-api.herokuapp.com/gimme/cosplay')
				 client.sendFileFromUrl(from, cos.data.url, '', '🌎Alliαηce Oтαkus🇯🇵⃟ ᴬᵗᵏ', id)
		break
			             case 'sissi':
            if (isGroupMsg && !isNsfw) return await client.reply(from,'_Negado._', id)
                const siss = await axios.get('https://meme-api.herokuapp.com/gimme/Sissies')
				 client.sendFileFromUrl(from, siss.data.url, '', '🌎Alliαηce Oтαkus🇯🇵⃟ ᴬᵗᵏ', id)
				  const siss1 = await axios.get('https://meme-api.herokuapp.com/gimme/Sissyperfection')
				 client.sendFileFromUrl(from, siss1.data.url, '', '🌎Alliαηce Oтαkus🇯🇵⃟ ᴬᵗᵏ', id)
		
                    break
                  
     case 'htemp':
	 case 'superpack':
					
              
            if (isGroupMsg && !isNsfw) return await client.reply(from,'_Negado._', id)
            
            
			const tp001 = await axios.get('https://meme-api.herokuapp.com/gimme/thick_hentai')
			await client.sendFileFromUrl(from, tp001.data.url, '', 'Lalatina BOT\n*🌎Alliαηce Oтαkus🇯🇵⃟ ᴬᵗᵏ*')
			  //await sleep(200000)
			const tp1 = await axios.get('https://meme-api.herokuapp.com/gimme/Erza34')
			await client.sendFileFromUrl(from, tp1.data.url, '', 'Lalatina BOT\n*🌎Alliαηce Oтαkus🇯🇵⃟ ᴬᵗᵏ*')
			  //await sleep(200000)
			 
			const tp2 = await axios.get('https://meme-api.herokuapp.com/gimme/FreeuseHentai')
			await client.sendFileFromUrl(from, tp2.data.url, '', 'Lalatina BOT\n*🌎Alliαηce Oтαkus🇯🇵⃟ ᴬᵗᵏ*')
			
			  //await sleep(200000)
			 
			const tp3 = await axios.get('https://nekos.life/api/v2/img/femdom')
			await client.sendFileFromUrl(from, tp3.data.url, '', 'Lalatina BOT\n*🌎Alliαηce Oтαkus🇯🇵⃟ ᴬᵗᵏ*')
			
			  //await sleep(200000)
			 
			const tp4 = await axios.get('https://meme-api.herokuapp.com/gimme/rule34')
			await client.sendFileFromUrl(from, tp4.data.url, '', 'Lalatina BOT\n*🌎Alliαηce Oтαkus🇯🇵⃟ ᴬᵗᵏ*')
			
			  //await sleep(200000)
			 
			const tp5 = await axios.get('https://nekos.life/api/v2/img/classic')
			await client.sendFileFromUrl(from, tp5.data.url, '', 'Lalatina BOT\n*🌎Alliαηce Oтαkus🇯🇵⃟ ᴬᵗᵏ*')
			
			  //await sleep(200000)
			 
			const tp6 = await axios.get('https://meme-api.herokuapp.com/gimme/Hentai4Everyone')
			await client.sendFileFromUrl(from, tp6.data.url, '', 'Lalatina BOT\n*🌎Alliαηce Oтαkus🇯🇵⃟ ᴬᵗᵏ*')
			
			  //await sleep(200000)
			 
			const tp7 = await axios.get('https://meme-api.herokuapp.com/gimme/Overwatch_Porn')
			await client.sendFileFromUrl(from, tp7.data.url, '', 'Lalatina BOT\n*🌎Alliαηce Oтαkus🇯🇵⃟ ᴬᵗᵏ*')
			
			  //await sleep(200000)
			 
			const tp8 = await axios.get('https://meme-api.herokuapp.com/gimme/rule34')
			await client.sendFileFromUrl(from, tp8.data.url, '', 'Lalatina BOT\n*🌎Alliαηce Oтαkus🇯🇵⃟ ᴬᵗᵏ*')
			
			  //await sleep(200000)
			 
			const tp9 = await axios.get('https://nekos.life/api/v2/img/pussy')
			await client.sendFileFromUrl(from, tp9.data.url, '', 'Lalatina BOT\n*🌎Alliαηce Oтαkus🇯🇵⃟ ᴬᵗᵏ*')
			
			  //await sleep(200000)
			  const tp9a1 = await axios.get('https://meme-api.herokuapp.com/gimme/hentai')
			await client.sendFileFromUrl(from, tp9a1.data.url, '', 'Lalatina BOT\n*🌎Alliαηce Oтαkus🇯🇵⃟ ᴬᵗᵏ*')
			  //await sleep(200000)
			   const tp9a2 = await axios.get('https://meme-api.herokuapp.com/gimme/tentai')
			await client.sendFileFromUrl(from, tp9a2.data.url, '', 'Lalatina BOT\n*🌎Alliαηce Oтαkus🇯🇵⃟ ᴬᵗᵏ*')
		
			  //await sleep(200000)
			    const tp9a3 = await axios.get('https://nekos.life/api/v2/img/keta')
			await client.sendFileFromUrl(from, tp9a3.data.url, '', 'Lalatina BOT\n*🌎Alliαηce Oтαkus🇯🇵⃟ ᴬᵗᵏ*')
			  //await sleep(200000)
			  
			    const tp9a4 = await axios.get('https://meme-api.herokuapp.com/gimme/hentaianal')
			await client.sendFileFromUrl(from, tp9a4.data.url, '', 'Lalatina BOT\n*🌎Alliαηce Oтαkus🇯🇵⃟ ᴬᵗᵏ*')
			  //await sleep(200000)
			     const tp9a5 = await axios.get('https://meme-api.herokuapp.com/gimme/maidhentai')
			await client.sendFileFromUrl(from, tp9a5.data.url, '', 'Lalatina BOT\n*🌎Alliαηce Oтαkus🇯🇵⃟ ᴬᵗᵏ*')
			  //await sleep(200000)
			   const tp9a6= await axios.get('https://meme-api.herokuapp.com/gimme/nekomimi')
			await client.sendFileFromUrl(from, tp9a6.data.url, '', 'Lalatina BOT\n*🌎Alliαηce Oтαkus🇯🇵⃟ ᴬᵗᵏ*')
			  //await sleep(200000)
			     const tp9a7= await axios.get('https://meme-api.herokuapp.com/gimme/traphentai')
			await client.sendFileFromUrl(from, tp9a7.data.url, '', 'Lalatina BOT\n*🌎Alliαηce Oтαkus🇯🇵⃟ ᴬᵗᵏ*')
			  //await sleep(200000)
			  const tp9a8= await axios.get('https://meme-api.herokuapp.com/gimme/remhentai')
			await client.sendFileFromUrl(from, tp9a8.data.url, '')
			  //await sleep(200000)
			    const tp9a9= await axios.get('https://meme-api.herokuapp.com/gimme/hentai_fish')
			await client.sendFileFromUrl(from, tp9a9.data.url, '', 'Lalatina BOT\n*🌎Alliαηce Oтαkus🇯🇵⃟ ᴬᵗᵏ*')
			  //await sleep(200000)
			const ttp10= await axios.get('https://meme-api.herokuapp.com/gimme/hentaibondage')
			await client.sendFileFromUrl(from, ttp10.data.url, '', 'Lalatina BOT\n*🌎Alliαηce Oтαkus🇯🇵⃟ ᴬᵗᵏ*')
			  //await sleep(200000)
			  const tp9a392 = await axios.get('https://nekos.life/api/v2/img/hentai')
			await client.sendFileFromUrl(from, tp9a392.data.url, '', 'Lalatina BOT\n*🌎Alliαηce Oтαkus🇯🇵⃟ ᴬᵗᵏ*')
			 
			 const tp1c = await axios.get('https://meme-api.herokuapp.com/gimme/ecchi')
			await client.sendFileFromUrl(from, tp1c.data.url, '', 'Lalatina BOT *🌎Alliαηce Oтαkus🇯🇵⃟ ᴬᵗᵏ*')
			  //await sleep(200000)
			 
			const tp2c = await axios.get('https://meme-api.herokuapp.com/gimme/ecchimanga')
			await client.sendFileFromUrl(from, tp2c.data.url, '', 'Lalatina BOT *🌎Alliαηce Oтαkus🇯🇵⃟ ᴬᵗᵏ*')
			
			  //await sleep(200000)
			 
			const tp3c = await axios.get('https://meme-api.herokuapp.com/gimme/ecchigifs')
			await client.sendFileFromUrl(from, tp3c.data.url, '', 'Lalatina BOT *🌎Alliαηce Oтαkus🇯🇵⃟ ᴬᵗᵏ*')
			
			  //await sleep(200000)
			 
			const tp4c = await axios.get('https://meme-api.herokuapp.com/gimme/RWBYecchi')
			await client.sendFileFromUrl(from, tp4c.data.url, '', 'Lalatina BOT *🌎Alliαηce Oтαkus🇯🇵⃟ ᴬᵗᵏ*')
			
			  //await sleep(200000)
			 
			const tp5c = await axios.get('https://meme-api.herokuapp.com/gimme/pantsu')
			await client.sendFileFromUrl(from, tp5c.data.url, '', 'Lalatina BOT *🌎Alliαηce Oтαkus🇯🇵⃟ ᴬᵗᵏ*')
			
			  //await sleep(200000)
			 
			const tp6c = await axios.get('https://meme-api.herokuapp.com/gimme/Ecchi')
			await client.sendFileFromUrl(from, tp6c.data.url, '', 'Lalatina BOT *🌎Alliαηce Oтαkus🇯🇵⃟ ᴬᵗᵏ*')
			
			  //await sleep(200000)
			 
			const tp7c = await axios.get('https://meme-api.herokuapp.com/gimme/teamecchi')
			await client.sendFileFromUrl(from, tp7c.data.url, '', 'Lalatina BOT *🌎Alliαηce Oтαkus🇯🇵⃟ ᴬᵗᵏ*')
			
			  //await sleep(200000)
			 
			const tp8c = await axios.get('https://meme-api.herokuapp.com/gimme/Artistic_Ecchi')
			await client.sendFileFromUrl(from, tp8c.data.url, '', 'Lalatina BOT *🌎Alliαηce Oтαkus🇯🇵⃟ ᴬᵗᵏ*')
			
			  //await sleep(200000)
			 
			const tp9c = await axios.get('https://meme-api.herokuapp.com/gimme/ecchimanga')
			await client.sendFileFromUrl(from, tp9c.data.url, '', 'Lalatina BOT *🌎Alliαηce Oтαkus🇯🇵⃟ ᴬᵗᵏ*')
			
			  //await sleep(200000)
			 
			const tp10c = await axios.get('https://meme-api.herokuapp.com/gimme/ecchi')
			await client.sendFileFromUrl(from, tp10c.data.url, '', '*🌎Alliαηce Oтαkus🇯🇵⃟ ᴬᵗᵏ*', id)
			 //await sleep(200000)
			
			
                  
                 
			
			const tc1 = await axios.get('https://meme-api.herokuapp.com/gimme/CosplayLewd')
			await client.sendFileFromUrl(from, tc1.data.url, '', 'Lalatina BOT *🌎Alliαηce Oтαkus🇯🇵⃟ ᴬᵗᵏ*')
			  //await sleep(200000)
			 
			const tc2 = await axios.get('https://meme-api.herokuapp.com/gimme/cosplaybutts')
			await client.sendFileFromUrl(from, tc2.data.url, '', 'Lalatina BOT *🌎Alliαηce Oтαkus🇯🇵⃟ ᴬᵗᵏ*')
			
			  //await sleep(200000)
			 
			const tc3 = await axios.get('https://meme-api.herokuapp.com/gimme/cosplay')
			await client.sendFileFromUrl(from, tc3.data.url, '', 'Lalatina BOT *🌎Alliαηce Oтαkus🇯🇵⃟ ᴬᵗᵏ*')
			
			  //await sleep(200000)
			 
			const tc4 = await axios.get('https://meme-api.herokuapp.com/gimme/nsfwcosplay')
			await client.sendFileFromUrl(from, tc4.data.url, '', 'Lalatina BOT *🌎Alliαηce Oтαkus🇯🇵⃟ ᴬᵗᵏ*')
			
			  //await sleep(200000)
			 
			const tc5 = await axios.get('https://meme-api.herokuapp.com/gimme/cosplaybabes')
			await client.sendFileFromUrl(from, tc5.data.url, '', 'Lalatina BOT *🌎Alliαηce Oтαkus🇯🇵⃟ ᴬᵗᵏ*')
			
			  //await sleep(200000)
			 
			const tc6 = await axios.get('https://meme-api.herokuapp.com/gimme/CosplayPornVideos')
			await client.sendFileFromUrl(from, tc6.data.url, '', 'Lalatina BOT *🌎Alliαηce Oтαkus🇯🇵⃟ ᴬᵗᵏ*')
			
			  //await sleep(200000)
			 
			const tc7 = await axios.get('https://meme-api.herokuapp.com/gimme/cosplaygirls')
			await client.sendFileFromUrl(from, tc7.data.url, '', 'Lalatina BOT *🌎Alliαηce Oтαkus🇯🇵⃟ ᴬᵗᵏ*')
			
			  //await sleep(200000)
	
			 
			const tc8 = await axios.get('https://meme-api.herokuapp.com/gimme/CosplayBoobs')
			await client.sendFileFromUrl(from, tc8.data.url, '', 'Lalatina BOT *🌎Alliαηce Oтαkus🇯🇵⃟ ᴬᵗᵏ*')
			
			  //await sleep(200000)
			 
			const tc9 = await axios.get('https://meme-api.herokuapp.com/gimme/cosplay')
			await client.sendFileFromUrl(from, tc9.data.url, '', 'Lalatina BOT *🌎Alliαηce Oтαkus🇯🇵⃟ ᴬᵗᵏ*')
			
			  //await sleep(200000)
			 
			const tc10= await axios.get('https://meme-api.herokuapp.com/gimme/cosplaygirls')
			await client.sendFileFromUrl(from, tc10.data.url, '', '*🌎Alliαηce Oтαkus🇯🇵⃟ ᴬᵗᵏ*')
			 //await sleep(200000)
		
			
			const tn1 = await axios.get('https://meme-api.herokuapp.com/gimme/Girlplay')
			await client.sendFileFromUrl(from, tn1.data.url, '', 'Lalatina BOT *🌎Alliαηce Oтαkus🇯🇵⃟ ᴬᵗᵏ*')
			  //await sleep(200000)
			 
			const tn2 = await axios.get('https://meme-api.herokuapp.com/gimme/Sexygirls')
			await client.sendFileFromUrl(from, tn2.data.url, '', 'Lalatina BOT *🌎Alliαηce Oтαkus🇯🇵⃟ ᴬᵗᵏ*')
			
			  //await sleep(200000)
			 
			const tn3 = await axios.get('https://meme-api.herokuapp.com/gimme/traps')
			await client.sendFileFromUrl(from, tn3.data.url, '', 'Lalatina BOT *🌎Alliαηce Oтαkus🇯🇵⃟ ᴬᵗᵏ*')
			
			  //await sleep(200000)
			 
			const tn4 = await axios.get('https://meme-api.herokuapp.com/gimme/Plugged')
			await client.sendFileFromUrl(from, tn4.data.url, '', 'Lalatina BOT *🌎Alliαηce Oтαkus🇯🇵⃟ ᴬᵗᵏ*')
			
			  //await sleep(200000)
			 
			const tn5 = await axios.get('https://meme-api.herokuapp.com/gimme/Maturemilf')
			await client.sendFileFromUrl(from, tn5.data.url, '', 'Lalatina BOT *🌎Alliαηce Oтαkus🇯🇵⃟ ᴬᵗᵏ*')
			
			  //await sleep(200000)
			 
			const tn6 = await axios.get('https://meme-api.herokuapp.com/gimme/Cat_girls')
			await client.sendFileFromUrl(from, tn6.data.url, '', 'Lalatina BOT *🌎Alliαηce Oтαkus🇯🇵⃟ ᴬᵗᵏ*')
			
			  //await sleep(200000)
			 
			const tn7 = await axios.get('https://meme-api.herokuapp.com/gimme/SexyWallpapers')
			await client.sendFileFromUrl(from, tn7.data.url, '', 'Lalatina BOT *🌎Alliαηce Oтαkus🇯🇵⃟ ᴬᵗᵏ*')
			
			  //await sleep(200000)
			 
			const tn8 = await axios.get('https://meme-api.herokuapp.com/gimme/Hotgirls')
			await client.sendFileFromUrl(from, tn8.data.url, '', 'Lalatina BOT *🌎Alliαηce Oтαkus🇯🇵⃟ ᴬᵗᵏ*')
			
			  //await sleep(200000)
			 
			const tn9 = await axios.get('https://meme-api.herokuapp.com/gimme/Gothsluts')
			await client.sendFileFromUrl(from, tn9.data.url, '', 'Lalatina BOT *🌎Alliαηce Oтαkus🇯🇵⃟ ᴬᵗᵏ*')
			
			  //await sleep(200000)
			 
			const tn10= await axios.get('https://meme-api.herokuapp.com/gimme/Monokini')
			await client.sendFileFromUrl(from, tn10.data.url, '', 'Lalatina BOT *🌎Alliαηce Oтαkus🇯🇵⃟ ᴬᵗᵏ*')
			  //await sleep(200000)
			  
			 const tn11 = await axios.get('https://meme-api.herokuapp.com/gimme/ass')
			await client.sendFileFromUrl(from, tn11.data.url, '', 'Lalatina BOT *🌎Alliαηce Oтαkus🇯🇵⃟ ᴬᵗᵏ*')
			  //await sleep(200000)
			  
			 const tn11a1 = await axios.get('https://meme-api.herokuapp.com/gimme/bigasses')
			await client.sendFileFromUrl(from, tn11a1.data.url, '', 'Lalatina BOT *🌎Alliαηce Oтαkus🇯🇵⃟ ᴬᵗᵏ*')
			
			  //await sleep(200000)
			 const tn12 = await axios.get('https://meme-api.herokuapp.com/gimme/pussy')
			await client.sendFileFromUrl(from, tn12.data.url, '', 'Lalatina BOT *🌎Alliαηce Oтαkus🇯🇵⃟ ᴬᵗᵏ*')
			
			  //await sleep(200000)
			  const tn13 = await axios.get('https://meme-api.herokuapp.com/gimme/rearpussy')
			await client.sendFileFromUrl(from, tn13.data.url, '', 'Lalatina BOT *🌎Alliαηce Oтαkus🇯🇵⃟ ᴬᵗᵏ*')
			
			  //await sleep(200000)
			  const tn14 = await axios.get('https://meme-api.herokuapp.com/gimme/vulva')
			await client.sendFileFromUrl(from, tn14.data.url, '', 'Lalatina BOT *🌎Alliαηce Oтαkus🇯🇵⃟ ᴬᵗᵏ*')
			
			  //await sleep(200000)
			  const tn144 = await axios.get('https://meme-api.herokuapp.com/gimme/PreggoPorn')
			await client.sendFileFromUrl(from, tn144.data.url, '', 'Lalatina BOT *🌎Alliαηce Oтαkus🇯🇵⃟ ᴬᵗᵏ*')
			
			  //await sleep(200000)
			 const tn15 = await axios.get('https://meme-api.herokuapp.com/gimme/SexyFrex')
			await client.sendFileFromUrl(from, tn15.data.url, '', 'Lalatina BOT *🌎Alliαηce Oтαkus🇯🇵⃟ ᴬᵗᵏ*')
			
			  //await sleep(200000)
			 
			 const tn16 = await axios.get('https://meme-api.herokuapp.com/gimme/curvy')
			await client.sendFileFromUrl(from, tn16.data.url, '', 'Lalatina BOT *🌎Alliαηce Oтαkus🇯🇵⃟ ᴬᵗᵏ*')
			
			  //await sleep(200000)
			   const tn17 = await axios.get('https://meme-api.herokuapp.com/gimme/AsiansGoneWild')
			await client.sendFileFromUrl(from, tn17.data.url, '', 'Lalatina BOT *🌎Alliαηce Oтαkus🇯🇵⃟ ᴬᵗᵏ*')
			 //await sleep(200000)
			   const tn18 = await axios.get('https://meme-api.herokuapp.com/gimme/collegensfw')
			await client.sendFileFromUrl(from, tn18.data.url, '', 'Lalatina BOT *🌎Alliαηce Oтαkus🇯🇵⃟ ᴬᵗᵏ*')
			 //await sleep(200000)
			   const tn19 = await axios.get('https://meme-api.herokuapp.com/gimme/creamy')
			await client.sendFileFromUrl(from, tn19.data.url, '', 'Lalatina BOT *🌎Alliαηce Oтαkus🇯🇵⃟ ᴬᵗᵏ*')
		
			  //await sleep(200000)
			    
			  const ttr9004 = await axios.get('https://meme-api.herokuapp.com/gimme/traps')
			await client.sendFileFromUrl(from, ttr9004.data.url, '', '')
			  //await sleep(200000)
			  const ttr9005 = await axios.get('https://meme-api.herokuapp.com/gimme/sissi')
			await client.sendFileFromUrl(from, ttr9005.data.url, '', '')
			  //await sleep(200000)
			  const ttr90051 = await axios.get('https://meme-api.herokuapp.com/gimme/futatrap')
			await client.sendFileFromUrl(from, ttr90051.data.url, '', '')
			  //await sleep(200000)
			    const ttr90052 = await axios.get('https://meme-api.herokuapp.com/gimme/futa_trap')
			await client.sendFileFromUrl(from, ttr90052.data.url, '', '')
		await sleep(1000)
			   const tn23 = await axios.get('https://meme-api.herokuapp.com/gimme/fegalvao')
			await client.sendFileFromUrl(from, tn23.data.url, '', 'Lalatina BOT *🌎Alliαηce Oтαkus🇯🇵⃟ ᴬᵗᵏ*')
			 //await sleep(200000)
			 const tn23pp = await axios.get('https://meme-api.herokuapp.com/gimme/onlyfans101')
			await client.sendFileFromUrl(from, tn23pp.data.url, '', 'Lalatina BOT *🌎Alliαηce Oтαkus🇯🇵⃟ ᴬᵗᵏ*')
			 //await sleep(200000)
			    const tn23a1 = await axios.get('https://meme-api.herokuapp.com/gimme/MouthFantasy')
			await client.sendFileFromUrl(from, tn23a1.data.url, '', 'Lalatina BOT* 🌎Alliαηce Oтαkus🇯🇵⃟ ᴬᵗᵏ*')
			 //await sleep(200000)
			 const tn23a3 = await axios.get('https://meme-api.herokuapp.com/gimme/collegensfw')
			await client.sendFileFromUrl(from, tn23a3.data.url, '', 'Lalatina BOT* 🌎Alliαηce Oтαkus🇯🇵⃟ ᴬᵗᵏ*')
			 //await sleep(200000)
			 const tn23a4 = await axios.get('https://meme-api.herokuapp.com/gimme/collegesluts')
			await client.sendFileFromUrl(from, tn23a4.data.url, '', 'Lalatina BOT *🌎Alliαηce Oтαkus🇯🇵⃟ ᴬᵗᵏ*')
			 //await sleep(200000)
			  const tn23a5 = await axios.get('https://meme-api.herokuapp.com/gimme/springbreakers')
			await client.sendFileFromUrl(from, tn23a5.data.url, '', 'Lalatina BOT *🌎Alliαηce Oтαkus🇯🇵⃟ ᴬᵗᵏ*')
			 //await sleep(200000)
			  const tn23a6 = await axios.get('https://meme-api.herokuapp.com/gimme/youngporn')
			await client.sendFileFromUrl(from, tn23a6.data.url, '', 'Lalatina BOT *🌎Alliαηce Oтαkus🇯🇵⃟ ᴬᵗᵏ*')
			 //await sleep(200000)
			    const tn23a2 = await axios.get('https://meme-api.herokuapp.com/gimme/LegalTeens')
			await client.sendFileFromUrl(from, tn23a2.data.url, '', 'Lalatina BOT\n*🌎Alliαηce Oтαkus🇯🇵⃟ ᴬᵗᵏ*')
				   const tn20 = await axios.get('https://meme-api.herokuapp.com/gimme/OnlyFansAsstastic')
			await client.sendFileFromUrl(from, tn20.data.url, '', '_💕Onlyfans++_')
		
			   //await sleep(200000)
			   const tn21 = await axios.get('https://meme-api.herokuapp.com/gimme/Onlyfans_Promo')
			await client.sendFileFromUrl(from, tn21.data.url, '', '_💕Onlyfans++_')
			   //await sleep(200000)
			   const tn22 = await axios.get('https://meme-api.herokuapp.com/gimme/promoteonlyfans')
			await client.sendFileFromUrl(from, tn22.data.url, '', '_💕Onlyfans++_')
			 //await sleep(200000)
			   const tn22a1 = await axios.get('https://meme-api.herokuapp.com/gimme/onlyfansgirls101')
			await client.sendFileFromUrl(from, tn22a1.data.url, '', '_💕Onlyfans++_')
			  const tn22a2 = await axios.get('https://meme-api.herokuapp.com/gimme/onlyfans101')
			await client.sendFileFromUrl(from, tn22a2.data.url, '', '_💕Onlyfans++_')
			 			    //await sleep(200000)
			   const tn22a3 = await axios.get('https://meme-api.herokuapp.com/gimme/FreeOnlyFansPage')
			await client.sendFileFromUrl(from, tn22a3.data.url, '', '_💕Onlyfans++_')
			 //await sleep(200000)
			   const tn22a4 = await axios.get('https://meme-api.herokuapp.com/gimme/OnlyfansXXX')
			await client.sendFileFromUrl(from, tn22a4.data.url, '', '_💕Onlyfans++_')
			 			   //await sleep(200000)
			   const tn24 = await axios.get('https://meme-api.herokuapp.com/gimme/bois')
			await client.sendFileFromUrl(from, tn24.data.url, '', 'Lalatina BOT *🌎Alliαηce Oтαkus🇯🇵⃟ ᴬᵗᵏ*')
			    //await sleep(200000)
			   const tn25 = await axios.get('https://meme-api.herokuapp.com/gimme/PiercedNSFW')
			await client.sendFileFromUrl(from, tn25.data.url, '', 'Lalatina BOT *🌎Alliαηce Oтαkus🇯🇵⃟ ᴬᵗᵏ*')
			 //await sleep(200000)
			   const tn26 = await axios.get('https://meme-api.herokuapp.com/gimme/Hotchickswithtattoos')
			await client.sendFileFromUrl(from, tn26.data.url, '', '')
			 //await sleep(200000)
			
			const ttr1 = await axios.get('https://nekos.life/api/v2/img/trap')
			await client.sendFileFromUrl(from, ttr1.data.url, '', '')
			  //await sleep(200000)
			 
			const ttr2 = await axios.get('https://nekos.life/api/v2/img/futanari')
			await client.sendFileFromUrl(from, ttr2.data.url, '', '')
			
			  //await sleep(200000)
			 
			const ttr3 = await axios.get('https://meme-api.herokuapp.com/gimme/DeliciousTraps')
			await client.sendFileFromUrl(from, ttr3.data.url, '', '')
			
			  //await sleep(200000)
			 
			const ttr4 = await axios.get('https://meme-api.herokuapp.com/gimme/futanari')
			await client.sendFileFromUrl(from, ttr4.data.url, '', '')
			
			  //await sleep(200000)
			 
			const ttr5 = await axios.get('https://meme-api.herokuapp.com/gimme/traps')
			await client.sendFileFromUrl(from, ttr5.data.url, '', '')
			
			  //await sleep(200000)
			 
			const ttr6 = await axios.get('https://meme-api.herokuapp.com/gimme/sissies')
			await client.sendFileFromUrl(from, ttr6.data.url, '', '')
			
			  //await sleep(200000)
			 
			const ttr7 = await axios.get('https://meme-api.herokuapp.com/gimme/sissi')
			await client.sendFileFromUrl(from, ttr7.data.url, '', '')
			
			  //await sleep(200000)
			 
			const ttr8 = await axios.get('https://meme-api.herokuapp.com/gimme/tgirls')
			await client.sendFileFromUrl(from, ttr8.data.url, '', '')
			
			  //await sleep(200000)
			 
			const ttr9 = await axios.get('https://meme-api.herokuapp.com/gimme/traphentai')
			await client.sendFileFromUrl(from, ttr9.data.url, '', '')
			
			  //await sleep(200000)
			  const ttr9a1 = await axios.get('https://meme-api.herokuapp.com/gimme/traps')
			await client.sendFileFromUrl(from, ttr9a1.data.url, '', '')
			  //await sleep(200000)
			   const ttr9a2 = await axios.get('https://meme-api.herokuapp.com/gimme/DeliciousTraps')
			await client.sendFileFromUrl(from, ttr9a2.data.url, '', '')
		
			  //await sleep(200000)
			    const ttr9a3 = await axios.get('https://meme-api.herokuapp.com/gimme/cutetraps')
			await client.sendFileFromUrl(from, ttr9a3.data.url, '', '')
			  //await sleep(200000)
			  
			    const ttr9a4 = await axios.get('https://meme-api.herokuapp.com/gimme/FutanariPegging')
			await client.sendFileFromUrl(from, ttr9a4.data.url, '', '')
			  //await sleep(200000)
			     const ttr9a5 = await axios.get('https://meme-api.herokuapp.com/gimme/HorsecockFuta')
			await client.sendFileFromUrl(from, ttr9a5.data.url, '', '')
			  //await sleep(200000)
			   const ttr9a6= await axios.get('https://meme-api.herokuapp.com/gimme/futamilf')
			await client.sendFileFromUrl(from, ttr9a6.data.url, '', '')
			  //await sleep(200000)
			     const ttr9a7= await axios.get('https://meme-api.herokuapp.com/gimme/cutefutanari')
			await client.sendFileFromUrl(from, ttr9a7.data.url, '', '')
			  //await sleep(200000)
			  const ttr9a8= await axios.get('https://meme-api.herokuapp.com/gimme/futacum')
			await client.sendFileFromUrl(from, ttr9a8.data.url, '', '')
			
			  //await sleep(200000)
			      const ttr90053 = await axios.get('https://meme-api.herokuapp.com/gimme/futaonfemale')
			await client.sendFileFromUrl(from, ttr90053.data.url, '', '')
			  //await sleep(200000)
			   const ttr90054 = await axios.get('https://meme-api.herokuapp.com/gimme/monsterfuta')
			await client.sendFileFromUrl(from, ttr90054.data.url, '', '')
			  //await sleep(200000)
			const ttr10= await axios.get('https://meme-api.herokuapp.com/gimme/traps')
			await client.sendFileFromUrl(from, ttr10.data.url, '', '*🌎Alliαηce Oтαkus🇯🇵⃟ ᴬᵗᵏ*')
			 //await sleep(200000)
			const ttr101= await axios.get('https://meme-api.herokuapp.com/gimme/Fairytail_hentai')
			await client.sendFileFromUrl(from, ttr101.data.url, '', '*🌎Alliαηce Oтαkus🇯🇵⃟ ᴬᵗᵏ*')
			 //await sleep(200000)
			const ttr102= await axios.get('https://meme-api.herokuapp.com/gimme/animeplot')
			await client.sendFileFromUrl(from, ttr101.data.url, '', '*🌎Alliαηce Oтαkus🇯🇵⃟ ᴬᵗᵏ*')
			 //await sleep(200000)
			 const ttr1095= await axios.get('https://meme-api.herokuapp.com/gimme/gloryho')
			await client.sendFileFromUrl(from, ttr1095.data.url, '', 'Lalatina BOT\n*🌎Alliαηce Oтαkus🇯🇵⃟ ᴬᵗᵏ*')
			 //await sleep(200000)
			 const ttr103= await axios.get('https://meme-api.herokuapp.com/gimme/funpiece')
			await client.sendFileFromUrl(from, ttr103.data.url, '', 'Lalatina BOT\n*🌎Alliαηce Oтαkus🇯🇵⃟ ᴬᵗᵏ*')
			 //await sleep(200000)
			  const ttr104= await axios.get('https://meme-api.herokuapp.com/gimme/AnimeCumtributes')
			await client.sendFileFromUrl(from, ttr104.data.url, '', 'Lalatina BOT\n*🌎Alliαηce Oтαkus🇯🇵⃟ ᴬᵗᵏ*')
			 //await sleep(200000)
			 const ttr105= await axios.get('https://meme-api.herokuapp.com/gimme/Katekey')
			await client.sendFileFromUrl(from, ttr105.data.url, '', 'Lalatina BOT\n*🌎Alliαηce Oтαkus🇯🇵⃟ ᴬᵗᵏ*')
			 //await sleep(200000)
			 const ttr106= await axios.get('https://meme-api.herokuapp.com/gimme/araara')
			await client.sendFileFromUrl(from, ttr106.data.url, '', 'Lalatina BOT\n*🌎Alliαηce Oтαkus🇯🇵⃟ ᴬᵗᵏ*')
			 //await sleep(200000)
			 const ttr107= await axios.get('https://nekos.life/api/v2/img/eroyuri')
			await client.sendFileFromUrl(from, ttr107.data.url, '', 'Lalatina BOT\n*🌎Alliαηce Oтαkus🇯🇵⃟ ᴬᵗᵏ*')
			 //await sleep(200000)
			  const ttr108= await axios.get('https://nekos.life/api/v2/img/femdom')
			await client.sendFileFromUrl(from, ttr108.data.url, '', 'Lalatina BOT\n*🌎Alliαηce Oтαkus🇯🇵⃟ ᴬᵗᵏ*')
			 //await sleep(200000)
			  const ttr109= await axios.get('https://meme-api.herokuapp.com/gimme/BigAnimeTiddies')
			await client.sendFileFromUrl(from, ttr109.data.url, '', 'Lalatina BOT\n*🌎Alliαηce Oтαkus🇯🇵⃟ ᴬᵗᵏ*')
			 //await sleep(200000)
			  const ttr1091= await axios.get('https://meme-api.herokuapp.com/gimme/AnimeBunnyGirls')
			await client.sendFileFromUrl(from, ttr1091.data.url, '', 'Lalatina BOT\n*🌎Alliαηce Oтαkus🇯🇵⃟ ᴬᵗᵏ*')
			 //await sleep(200000)
			  const ttr1092= await axios.get('https://meme-api.herokuapp.com/gimme/KimetsuNoYaibaHentai')
			await client.sendFileFromUrl(from, ttr1092.data.url, '', 'Lalatina BOT\n*🌎Alliαηce Oтαkus🇯🇵⃟ ᴬᵗᵏ*')
			//await sleep(240000)
			  const ttr1093= await axios.get('https://meme-api.herokuapp.com/gimme/animefeets')
			await client.sendFileFromUrl(from, ttr1093.data.url, '', 'Lalatina BOT\n*🌎Alliαηce Oтαkus🇯🇵⃟ ᴬᵗᵏ*')
			//await sleep(240000)
			  const ttr1094= await axios.get('https://meme-api.herokuapp.com/gimme/araragi')
			await client.sendFileFromUrl(from, ttr1094.data.url, '', 'Lalatina BOT\n*🌎Alliαηce Oтαkus🇯🇵⃟ ᴬᵗᵏ*')
			 //await sleep(200000)
			 const ttr1095a1= await axios.get('https://meme-api.herokuapp.com/gimme/gloryho')
			await client.sendFileFromUrl(from, ttr1095a1.data.url, '', 'Lalatina BOT\n*🌎Alliαηce Oтαkus🇯🇵⃟ ᴬᵗᵏ*')
			 //await sleep(200000)
			            const clas1 = await axios.get('https://nekos.life/api/v2/img/classic')
					await client.sendFileFromUrl(from, clas1.data.url, '', '🌎Alliαηce Oтαkus🇯🇵⃟ ᴬᵗᵏ', id)
				 //await sleep(200000)
					const hentaiu = await axios.get('https://nekos.life/api/v2/img/hentai')
					await client.sendFileFromUrl(from, hentaiu, '', '🌎Alliαηce Oтαkus🇯🇵⃟ ᴬᵗᵏ', id)
				 //await sleep(200000)
				
				 //await sleep(200000)
					const hentaiu4 = await axios.get('https://nekos.life/api/v2/img/pussy_jpg')
					await client.sendFileFromUrl(from, hentaiu4.data.url, '', '🌎Alliαηce Oтαkus🇯🇵⃟ ᴬᵗᵏ', id)
				 //await sleep(200000)
					const hentaiu5 = await axios.get('https://nekos.life/api/v2/img/hentai')
					await client.sendFileFromUrl(from, hentaiu5.data.url, '', '🌎Alliαηce Oтαkus🇯🇵⃟ ᴬᵗᵏ', id)
				   //await sleep(200000)
					const hentaiu6 = await axios.get('https://nekos.life/api/v2/img/pussy')
					await client.sendFileFromUrl(from, hentaiu6.data.url, '', '🌎Alliαηce Oтαkus🇯🇵⃟ ᴬᵗᵏ', id)
			  //await sleep(200000)
			break
                    
                             case 'packhentai':
                                if (isGroupMsg && !isNsfw) return await client.reply(from,'_Negado._', id)
			
			const p1 = await axios.get('https://meme-api.herokuapp.com/gimme/hentai')
			await client.sendFileFromUrl(from, p1.data.url, '', '', id)
			  await sleep(1000)
			 
			const p2 = await axios.get('https://meme-api.herokuapp.com/gimme/FreeuseHentai')
			await client.sendFileFromUrl(from, p2.data.url, '', '', id)
			
			  await sleep(1000)
			 
			const p3 = await axios.get('https://meme-api.herokuapp.com/gimme/DeliciousTraps')
			await client.sendFileFromUrl(from, p3.data.url, '', '', id)
			
			  await sleep(1000)
			 
			const p4 = await axios.get('https://meme-api.herokuapp.com/gimme/rule34')
			await client.sendFileFromUrl(from, p4.data.url, '', '', id)
			
			  await sleep(1000)
			 
			const p5 = await axios.get('https://meme-api.herokuapp.com/gimme/HelplessHentai')
			await client.sendFileFromUrl(from, p5.data.url, '', '', id)
			
			  await sleep(1000)
			 
			const p6 = await axios.get('https://meme-api.herokuapp.com/gimme/Hentai4Everyone')
			await client.sendFileFromUrl(from, p6.data.url, '', '', id)
			
			  await sleep(1000)
			 
			const p7 = await axios.get('https://meme-api.herokuapp.com/gimme/Overwatch_Porn')
			await client.sendFileFromUrl(from, p7.data.url, '', '', id)
			
			  await sleep(1000)
			 
			const p8 = await axios.get('https://meme-api.herokuapp.com/gimme/netorare')
			await client.sendFileFromUrl(from, p8.data.url, '', '', id)
			
			  await sleep(1000)
			 
			const p9 = await axios.get('https://meme-api.herokuapp.com/gimme/traphentai')
			await client.sendFileFromUrl(from, p9.data.url, '', '', id)
			
			  await sleep(1000)
			  const p9a1 = await axios.get('https://meme-api.herokuapp.com/gimme/hentai')
			await client.sendFileFromUrl(from, p9a1.data.url, '', '', id)
			  await sleep(1000)
			   const p9a2 = await axios.get('https://meme-api.herokuapp.com/gimme/tentai')
			await client.sendFileFromUrl(from, p9a2.data.url, '', '', id)
		
			  await sleep(1000)
			    const p9a3 = await axios.get('https://meme-api.herokuapp.com/gimme/Naruto_Hentai')
			await client.sendFileFromUrl(from, p9a3.data.url, '', '', id)
			  await sleep(1000)
			  
			    const p9a4 = await axios.get('https://meme-api.herokuapp.com/gimme/hentaianal')
			await client.sendFileFromUrl(from, p9a4.data.url, '', '', id)
			  await sleep(1000)
			     const p9a5 = await axios.get('https://meme-api.herokuapp.com/gimme/maidhentai')
			await client.sendFileFromUrl(from, p9a5.data.url, '', '', id)
			  await sleep(1000)
			   const p9a6= await axios.get('https://meme-api.herokuapp.com/gimme/DeliciousTraps')
			await client.sendFileFromUrl(from, p9a6.data.url, '', '', id)
			  await sleep(1000)
			     const p9a7= await axios.get('https://meme-api.herokuapp.com/gimme/traphentai')
			await client.sendFileFromUrl(from, p9a7.data.url, '', '', id)
			  await sleep(1000)
			  const p9a8= await axios.get('https://meme-api.herokuapp.com/gimme/hentailactation')
			await client.sendFileFromUrl(from, p9a8.data.url, '', '', id)
			  await sleep(1000)
			    const p9a9= await axios.get('https://meme-api.herokuapp.com/gimme/hentai_fish')
			await client.sendFileFromUrl(from, p9a9.data.url, '', '', id)
			  await sleep(1000)
			   const ttr1081= await axios.get('https://nekos.life/api/v2/img/femdom')
			await client.sendFileFromUrl(from, ttr1081.data.url, '', 'Lalatina BOT\n*🌎Alliαηce Oтαkus🇯🇵⃟ ᴬᵗᵏ*')
			 //await sleep(200000)
			  const ttr1091m= await axios.get('https://meme-api.herokuapp.com/gimme/BigAnimeTiddies')
			await client.sendFileFromUrl(from, ttr1091m.data.url, '', 'Lalatina BOT\n*🌎Alliαηce Oтαkus🇯🇵⃟ ᴬᵗᵏ*')
			 //await sleep(200000)
			  const ttr10911= await axios.get('https://meme-api.herokuapp.com/gimme/AnimeBunnyGirls')
			await client.sendFileFromUrl(from, ttr10911.data.url, '', 'Lalatina BOT\n*🌎Alliαηce Oтαkus🇯🇵⃟ ᴬᵗᵏ*')
			 //await sleep(200000)
			  const ttr10921= await axios.get('https://meme-api.herokuapp.com/gimme/KimetsuNoYaibaHentai')
			await client.sendFileFromUrl(from, ttr10921.data.url, '', 'Lalatina BOT\n*🌎Alliαηce Oтαkus🇯🇵⃟ ᴬᵗᵏ*')
			//await sleep(240000)
			  const ttr10931= await axios.get('https://meme-api.herokuapp.com/gimme/animefeets')
			await client.sendFileFromUrl(from, ttr10931.data.url, '', 'Lalatina BOT\n*🌎Alliαηce Oтαkus🇯🇵⃟ ᴬᵗᵏ*')
			//await sleep(240000)
			  const ttr10941= await axios.get('https://meme-api.herokuapp.com/gimme/araragi')
			await client.sendFileFromUrl(from, ttr10941.data.url, '', 'Lalatina BOT\n*🌎Alliαηce Oтαkus🇯🇵⃟ ᴬᵗᵏ*')
			 //await sleep(200000)
			 const ttr1095a11= await axios.get('https://meme-api.herokuapp.com/gimme/gloryho')
			await client.sendFileFromUrl(from, ttr1095a11.data.url, '', 'Lalatina BOT\n*🌎Alliαηce Oтαkus🇯🇵⃟ ᴬᵗᵏ*')
			 //await sleep(200000)
			            const clas111 = await axios.get('https://nekos.life/api/v2/img/classic')
					await client.sendFileFromUrl(from, clas111.data.url, '', '🌎Alliαηce Oтαkus🇯🇵⃟ ᴬᵗᵏ')
					  
					
			const p101= await axios.get('https://meme-api.herokuapp.com/gimme/hentaibondage')
			await client.sendFileFromUrl(from, p101.data.url, '', '_Seu pack foi finalizado._\n*🌎Alliαηce Oтαkus🇯🇵⃟ ᴬᵗᵏ*', id)
			
			break
			 
			    case 'ahegao':
			       if (isGroupMsg && !isNsfw) return await client.reply(from,'_Negado._', id)
                      const ahe = await axios.get('https://meme-api.herokuapp.com/gimme/RealAhegao')
				client.sendFileFromUrl(from, ahe.data.url, '', '🌎Alliαηce Oтαkus🇯🇵⃟ ᴬᵗᵏ', id)
				
                      const ahe1 = await axios.get('https://meme-api.herokuapp.com/gimme/Ahegao')
				client.sendFileFromUrl(from, ahe1.data.url, '', '🌎Alliαηce Oтαkus🇯🇵⃟ ᴬᵗᵏ', id)
                     const ahe2 = await axios.get('https://meme-api.herokuapp.com/gimme/Ahegaos')
				client.sendFileFromUrl(from, ahe2.data.url, '', '🌎Alliαηce Oтαkus🇯🇵⃟ ᴬᵗᵏ', id)
				   const ahe3 = await axios.get('https://meme-api.herokuapp.com/gimme/AhegaoGirls')
				client.sendFileFromUrl(from, ahe3.data.url, '', '🌎Alliαηce Oтαkus🇯🇵⃟ ᴬᵗᵏ', id)
				 await sleep(1000)
                    break 
			 
			 
			 case 'packecchi':
			    if (isGroupMsg && !isNsfw) return await client.reply(from,'_Negado._', id)
			
			const p1c = await axios.get('https://meme-api.herokuapp.com/gimme/ecchi')
			await client.sendFileFromUrl(from, p1c.data.url, '', '', id)
			  await sleep(1000)
			 
			const p2c = await axios.get('https://meme-api.herokuapp.com/gimme/ecchimanga')
			await client.sendFileFromUrl(from, p2c.data.url, '', '', id)
			
			  await sleep(1000)
			 
			const p3c = await axios.get('https://meme-api.herokuapp.com/gimme/ecchigifs')
			await client.sendFileFromUrl(from, p3c.data.url, '', '', id)
			
			  await sleep(1000)
			 
			const p4c = await axios.get('https://meme-api.herokuapp.com/gimme/RWBYecchi')
			await client.sendFileFromUrl(from, p4c.data.url, '', '', id)
			
			  await sleep(1000)
			 
			const p5c = await axios.get('https://meme-api.herokuapp.com/gimme/pantsu')
			await client.sendFileFromUrl(from, p5c.data.url, '', '', id)
			
			  await sleep(1000)
			 
			const p6c = await axios.get('https://meme-api.herokuapp.com/gimme/Ecchi')
			await client.sendFileFromUrl(from, p6c.data.url, '', '', id)
			
			  await sleep(1000)
			 
			const p7c = await axios.get('https://meme-api.herokuapp.com/gimme/teamecchi')
			await client.sendFileFromUrl(from, p7c.data.url, '', '', id)
			
			  await sleep(1000)
			 
			const p8c = await axios.get('https://meme-api.herokuapp.com/gimme/Artistic_Ecchi')
			await client.sendFileFromUrl(from, p8c.data.url, '', '', id)
			
			  await sleep(1000)
			 
			const p9c = await axios.get('https://meme-api.herokuapp.com/gimme/ecchimanga')
			await client.sendFileFromUrl(from, p9c.data.url, '', '', id)
			
			  await sleep(1000)
			 
			  const necchi = await axios.get('https://meme-api.herokuapp.com/gimme/BigAnimeTiddies')
			await client.sendFileFromUrl(from, necchi.data.url, '', '')
		         const necchi1 = await axios.get('https://meme-api.herokuapp.com/gimme/Sukebei')
			await client.sendFileFromUrl(from, necchi1.data.url, '', '')
			  const necchi2 = await axios.get('https://meme-api.herokuapp.com/gimme/pantsu')
			await client.sendFileFromUrl(from, necchi2.data.url, '', '')
				
			const p10c = await axios.get('https://meme-api.herokuapp.com/gimme/ecchi')
			await client.sendFileFromUrl(from, p10c.data.url, '', '_Seu pack foi finalizado._\n*🌎Alliαηce Oтαkus🇯🇵⃟ ᴬᵗᵏ*', id)					
			break
			
                  
                    case 'packcosplay':
			   if (isGroupMsg && !isNsfw) return await client.reply(from,'_Negado._', id)
			const c1 = await axios.get('https://meme-api.herokuapp.com/gimme/CosplayLewd')
			await client.sendFileFromUrl(from, c1.data.url, '', '', id)
			  await sleep(1000)
			 
			const c2 = await axios.get('https://meme-api.herokuapp.com/gimme/cosplaybutts')
			await client.sendFileFromUrl(from, c2.data.url, '', '', id)
			
			  await sleep(1000)
			 
			const c3 = await axios.get('https://meme-api.herokuapp.com/gimme/cosplay')
			await client.sendFileFromUrl(from, c3.data.url, '', '', id)
			
			  await sleep(1000)
			 
			const c4 = await axios.get('https://meme-api.herokuapp.com/gimme/nsfwcosplay')
			await client.sendFileFromUrl(from, c4.data.url, '', '', id)
			
			  await sleep(1000)
			 
			const c5 = await axios.get('https://meme-api.herokuapp.com/gimme/cosplaybabes')
			await client.sendFileFromUrl(from, c5.data.url, '', '', id)
			
			  await sleep(1000)
			 
			const c6 = await axios.get('https://meme-api.herokuapp.com/gimme/CosplayPornVideos')
			await client.sendFileFromUrl(from, c6.data.url, '', '', id)
			
			  await sleep(1000)
			 
			const c7 = await axios.get('https://meme-api.herokuapp.com/gimme/cosplaygirls')
			await client.sendFileFromUrl(from, c7.data.url, '', '', id)
			
			  await sleep(1000)
			 
			const c8 = await axios.get('https://meme-api.herokuapp.com/gimme/CosplayBoobs')
			await client.sendFileFromUrl(from, c8.data.url, '', '', id)
			
			  await sleep(1000)
			 
			const c9 = await axios.get('https://meme-api.herokuapp.com/gimme/cosplay')
			await client.sendFileFromUrl(from, c9.data.url, '', '', id)
			
			  await sleep(1000)
			 
			const c1011= await axios.get('https://meme-api.herokuapp.com/gimme/cosplaygirls')
			await client.sendFileFromUrl(from, c1011.data.url, '', '_Seu pack foi finalizado._\n*🌎Alliαηce Oтαkus🇯🇵⃟ ᴬᵗᵏ*', id)
			 await sleep(1000)
			break
			
  case 'packnudes':
                      if (isGroupMsg && !isNsfw) return await client.reply(from,'_Negado._', id)
			
			const n1 = await axios.get('https://meme-api.herokuapp.com/gimme/Girlplay')
			await client.sendFileFromUrl(from, n1.data.url, '', '', id)
			  await sleep(1000)
			 
			const n2 = await axios.get('https://meme-api.herokuapp.com/gimme/Sexygirls')
			await client.sendFileFromUrl(from, n2.data.url, '', '', id)
			
			  await sleep(1000)
			 
			const n3 = await axios.get('https://meme-api.herokuapp.com/gimme/traps')
			await client.sendFileFromUrl(from, n3.data.url, '', '', id)
			
			  await sleep(1000)
			 
			const n4 = await axios.get('https://meme-api.herokuapp.com/gimme/Plugged')
			await client.sendFileFromUrl(from, n4.data.url, '', '', id)
			
			  await sleep(1000)
			 
			const n5 = await axios.get('https://meme-api.herokuapp.com/gimme/Maturemilf')
			await client.sendFileFromUrl(from, n5.data.url, '', '', id)
			
			  await sleep(1000)
			 
			const n6 = await axios.get('https://meme-api.herokuapp.com/gimme/Cat_girls')
			await client.sendFileFromUrl(from, n6.data.url, '', '', id)
			
			  await sleep(1000)
			 
			const n7 = await axios.get('https://meme-api.herokuapp.com/gimme/SexyWallpapers')
			await client.sendFileFromUrl(from, n7.data.url, '', '', id)
			
			  await sleep(1000)
			 
			const n8 = await axios.get('https://meme-api.herokuapp.com/gimme/Hotgirls')
			await client.sendFileFromUrl(from, n8.data.url, '', '', id)
			
			  await sleep(1000)
			 
			const n9 = await axios.get('https://meme-api.herokuapp.com/gimme/Gothsluts')
			await client.sendFileFromUrl(from, n9.data.url, '', '', id)
			
			  await sleep(1000)
			 
			const n10= await axios.get('https://meme-api.herokuapp.com/gimme/Monokini')
			await client.sendFileFromUrl(from, n10.data.url, '', '', id)
			  await sleep(1000)
			  
			 const n11 = await axios.get('https://meme-api.herokuapp.com/gimme/ass')
			await client.sendFileFromUrl(from, n11.data.url, '', '', id)
			  await sleep(1000)
			  
			 const n11a1 = await axios.get('https://meme-api.herokuapp.com/gimme/bigasses')
			await client.sendFileFromUrl(from, n11a1.data.url, '', '', id)
			
			  await sleep(1000)
			 const n12 = await axios.get('https://meme-api.herokuapp.com/gimme/pussy')
			await client.sendFileFromUrl(from, n12.data.url, '', '', id)
			
			  await sleep(1000)
			  const n13 = await axios.get('https://meme-api.herokuapp.com/gimme/rearpussy')
			await client.sendFileFromUrl(from, n13.data.url, '', '', id)
			
			  await sleep(1000)
			  const n14 = await axios.get('https://meme-api.herokuapp.com/gimme/vulva')
			await client.sendFileFromUrl(from, n14.data.url, '', '', id)
			
			  await sleep(1000)
			  const n144 = await axios.get('https://meme-api.herokuapp.com/gimme/PreggoPorn')
			await client.sendFileFromUrl(from, n144.data.url, '', '', id)
			
			  await sleep(1000)
			 const n15 = await axios.get('https://meme-api.herokuapp.com/gimme/SexyFrex')
			await client.sendFileFromUrl(from, n15.data.url, '', '', id)
			
			  await sleep(1000)
			 
			 const n16 = await axios.get('https://meme-api.herokuapp.com/gimme/curvy')
			await client.sendFileFromUrl(from, n16.data.url, '', '', id)
			
			  await sleep(1000)
			   const n17 = await axios.get('https://meme-api.herokuapp.com/gimme/AsiansGoneWild')
			await client.sendFileFromUrl(from, n17.data.url, '', '', id)
			 await sleep(1000)
			   const n18 = await axios.get('https://meme-api.herokuapp.com/gimme/collegensfw')
			await client.sendFileFromUrl(from, n18.data.url, '', '', id)
			 await sleep(1000)
			   const n19 = await axios.get('https://meme-api.herokuapp.com/gimme/creamy')
			await client.sendFileFromUrl(from, n19.data.url, '', '', id)
		
			  await sleep(1000)
		
			   const n23 = await axios.get('https://meme-api.herokuapp.com/gimme/fegalvao')
			await client.sendFileFromUrl(from, n23.data.url, '', '', id)
			 await sleep(1000)
			 const n23pp = await axios.get('https://meme-api.herokuapp.com/gimme/onlyfans101')
			await client.sendFileFromUrl(from, n23pp.data.url, '', '', id)
			 await sleep(1000)
			    const n23a1 = await axios.get('https://meme-api.herokuapp.com/gimme/MouthFantasy')
			await client.sendFileFromUrl(from, n23a1.data.url, '', '', id)
			 await sleep(1000)
			 const n23a3 = await axios.get('https://meme-api.herokuapp.com/gimme/collegensfw')
			await client.sendFileFromUrl(from, n23a3.data.url, '', '', id)
			 await sleep(1000)
			 const n23a4 = await axios.get('https://meme-api.herokuapp.com/gimme/collegesluts')
			await client.sendFileFromUrl(from, n23a4.data.url, '', '', id)
			 await sleep(1000)
			  const n23a5 = await axios.get('https://meme-api.herokuapp.com/gimme/springbreakers')
			await client.sendFileFromUrl(from, n23a5.data.url, '', '', id)
			 await sleep(1000)
			  const n23a6 = await axios.get('https://meme-api.herokuapp.com/gimme/youngporn')
			await client.sendFileFromUrl(from, n23a6.data.url, '', '', id)
			 await sleep(1000)
			    const n23a2 = await axios.get('https://meme-api.herokuapp.com/gimme/LegalTeens')
			await client.sendFileFromUrl(from, n23a2.data.url, '', '', id)
				   const n20 = await axios.get('https://meme-api.herokuapp.com/gimme/OnlyFansAsstastic')
			await client.sendFileFromUrl(from, n20.data.url, '', '_💕Onlyfans++_', id)
		
			   await sleep(1000)
			   const n21 = await axios.get('https://meme-api.herokuapp.com/gimme/Onlyfans_Promo')
			await client.sendFileFromUrl(from, n21.data.url, '', '_💕Onlyfans++_', id)
			   await sleep(1000)
			   const n22 = await axios.get('https://meme-api.herokuapp.com/gimme/promoteonlyfans')
			await client.sendFileFromUrl(from, n22.data.url, '', '_💕Onlyfans++_', id)
			 await sleep(1000)
			   const n22a1 = await axios.get('https://meme-api.herokuapp.com/gimme/onlyfansgirls101')
			await client.sendFileFromUrl(from, n22a1.data.url, '', '_💕Onlyfans++_', id)
			  const n22a2 = await axios.get('https://meme-api.herokuapp.com/gimme/onlyfans101')
			await client.sendFileFromUrl(from, n22a2.data.url, '', '_💕Onlyfans++_', id)
			 			    await sleep(1000)
			   const n22a3 = await axios.get('https://meme-api.herokuapp.com/gimme/FreeOnlyFansPage')
			await client.sendFileFromUrl(from, n22a3.data.url, '', '_💕Onlyfans++_', id)
			 await sleep(1000)
			   const n22a4 = await axios.get('https://meme-api.herokuapp.com/gimme/OnlyfansXXX')
			await client.sendFileFromUrl(from, n22a4.data.url, '', '_💕Onlyfans++_', id)
			 			   await sleep(1000)
			   const n24 = await axios.get('https://meme-api.herokuapp.com/gimme/bois')
			await client.sendFileFromUrl(from, n24.data.url, '', ' ', id)
			    await sleep(1000)
			   const n25 = await axios.get('https://meme-api.herokuapp.com/gimme/PiercedNSFW')
			await client.sendFileFromUrl(from, n25.data.url, '', ' ', id)
			 await sleep(1000)
			
		
			  await sleep(1000)
			   const tr90055 = await axios.get('https://meme-api.herokuapp.com/gimme/ToplessInJeans')
			await client.sendFileFromUrl(from, tr90055.data.url, '', '')
			  await sleep(1000)
			     const tr90056 = await axios.get('https://meme-api.herokuapp.com/gimme/GirlsWearingVS')
			await client.sendFileFromUrl(from, tr90056.data.url, '', '')
			  await sleep(1000)
			   const tr90057 = await axios.get('https://meme-api.herokuapp.com/gimme/Pantyfetish')
			await client.sendFileFromUrl(from, tr90057.data.url, '', '')
			  await sleep(1000)
			    const tr90058 = await axios.get('https://meme-api.herokuapp.com/gimme/cottonpanties')
			await client.sendFileFromUrl(from, tr90058.data.url, '', '')
			  await sleep(1000)
			   const tr90059 = await axios.get('https://meme-api.herokuapp.com/gimme/assinthong')
			await client.sendFileFromUrl(from, tr90059.data.url, '', '')
			  await sleep(1000)
			  const tr90060 = await axios.get('https://meme-api.herokuapp.com/gimme/sexyuniforms')
			await client.sendFileFromUrl(from, tr90060.data.url, '', '')
			  await sleep(1000)
			  const tr90061 = await axios.get('https://meme-api.herokuapp.com/gimme/legs')
			await client.sendFileFromUrl(from, tr90061.data.url, '', '')
			  await sleep(1000)
			  const milf00 = await axios.get('https://meme-api.herokuapp.com/gimme/milf')
				client.sendFileFromUrl(from, milf00.data.url, '', '🌎Alliαηce Oтαkus🇯🇵⃟ ᴬᵗᵏ')
				const milf001 = await axios.get('https://meme-api.herokuapp.com/gimme/hotmoms')
				client.sendFileFromUrl(from, milf001.data.url, '', '🌎Alliαηce Oтαkus🇯🇵⃟ ᴬᵗᵏ')
			     const n26 = await axios.get('https://meme-api.herokuapp.com/gimme/Hotchickswithtattoos')
			await client.sendFileFromUrl(from, n26.data.url, '', '_Seu pack foi finalizado._\n*🌎Alliαηce Oтαkus🇯🇵⃟ ᴬᵗᵏ*' , id)
			
			
			break
					
			                             case 'packtrap':
			case 'packfuta':
			   if (isGroupMsg && !isNsfw) return await client.reply(from,'_Negado._', id)
			const tr1 = await axios.get('https://nekos.life/api/v2/img/trap')
			await client.sendFileFromUrl(from, tr1.data.url, '', '')
			  await sleep(1000)
			 
			const tr2 = await axios.get('https://nekos.life/api/v2/img/futanari')
			await client.sendFileFromUrl(from, tr2.data.url, '', '')
			
			  await sleep(1000)
			 
			const tr3 = await axios.get('https://meme-api.herokuapp.com/gimme/DeliciousTraps')
			await client.sendFileFromUrl(from, tr3.data.url, '', '')
			
			  await sleep(1000)
			 
			const tr4 = await axios.get('https://meme-api.herokuapp.com/gimme/futanari')
			await client.sendFileFromUrl(from, tr4.data.url, '', '')
			
			  await sleep(1000)
			 
			const tr5 = await axios.get('https://meme-api.herokuapp.com/gimme/traps')
			await client.sendFileFromUrl(from, tr5.data.url, '', '')
			
			  await sleep(1000)
			 
			const tr6 = await axios.get('https://meme-api.herokuapp.com/gimme/sissies')
			await client.sendFileFromUrl(from, tr6.data.url, '', '')
			
			  await sleep(1000)
			 
			const tr7 = await axios.get('https://meme-api.herokuapp.com/gimme/sissi')
			await client.sendFileFromUrl(from, tr7.data.url, '', '')
			
			  await sleep(1000)
			 
			const tr8 = await axios.get('https://meme-api.herokuapp.com/gimme/tgirls')
			await client.sendFileFromUrl(from, tr8.data.url, '', '')
			
			  await sleep(1000)
			 
			const tr9 = await axios.get('https://meme-api.herokuapp.com/gimme/traphentai')
			await client.sendFileFromUrl(from, tr9.data.url, '', '')
			
			  await sleep(1000)
			  const tr9a1 = await axios.get('https://meme-api.herokuapp.com/gimme/traps')
			await client.sendFileFromUrl(from, tr9a1.data.url, '', '')
			  await sleep(1000)
			   const tr9a2 = await axios.get('https://meme-api.herokuapp.com/gimme/DeliciousTraps')
			await client.sendFileFromUrl(from, tr9a2.data.url, '', '')
		
			  await sleep(1000)
			    const tr9a3 = await axios.get('https://meme-api.herokuapp.com/gimme/cutetraps')
			await client.sendFileFromUrl(from, tr9a3.data.url, '', '')
			  await sleep(1000)
			  
			    const tr9a4 = await axios.get('https://meme-api.herokuapp.com/gimme/FutanariPegging')
			await client.sendFileFromUrl(from, tr9a4.data.url, '', '')
			  await sleep(1000)
			     const tr9a5 = await axios.get('https://meme-api.herokuapp.com/gimme/HorsecockFuta')
			await client.sendFileFromUrl(from, tr9a5.data.url, '', '')
			  await sleep(1000)
			   const tr9a6= await axios.get('https://meme-api.herokuapp.com/gimme/futamilf')
			await client.sendFileFromUrl(from, tr9a6.data.url, '', '')
			  await sleep(1000)
			     const tr9a7= await axios.get('https://meme-api.herokuapp.com/gimme/cutefutanari')
			await client.sendFileFromUrl(from, tr9a7.data.url, '', '')
			  await sleep(1000)
			  const tr9a8= await axios.get('https://meme-api.herokuapp.com/gimme/futacum')
			await client.sendFileFromUrl(from, tr9a8.data.url, '', '')
			  await sleep(1000)
			  const tr9004 = await axios.get('https://meme-api.herokuapp.com/gimme/traps')
			await client.sendFileFromUrl(from, tr9004.data.url, '', '')
			  await sleep(1000)
			  const tr9005 = await axios.get('https://meme-api.herokuapp.com/gimme/Sissyperfection')
			await client.sendFileFromUrl(from, tr9005.data.url, '', '')
			  await sleep(1000)
			  const tr90051 = await axios.get('https://meme-api.herokuapp.com/gimme/futatrap')
			await client.sendFileFromUrl(from, tr90051.data.url, '', '')
			  await sleep(1000)
			    const tr90052 = await axios.get('https://meme-api.herokuapp.com/gimme/futa_trap')
			await client.sendFileFromUrl(from, tr90052.data.url, '', '')
			  await sleep(1000)
			      const tr90053 = await axios.get('https://meme-api.herokuapp.com/gimme/futaonfemale')
			await client.sendFileFromUrl(from, tr90053.data.url, '', '')
			  await sleep(1000)
			   const tr90054 = await axios.get('https://meme-api.herokuapp.com/gimme/monsterfuta')
			await client.sendFileFromUrl(from, tr90054.data.url, '', '')
			  await sleep(1000)
			   const tr90055b = await axios.get('https://meme-api.herokuapp.com/gimme/ShemalesParadise')
			await client.sendFileFromUrl(from, tr90055b.data.url, '', '')
			  await sleep(1000)
			    const tr90056b = await axios.get('https://meme-api.herokuapp.com/gimme/tscumsluts')
			await client.sendFileFromUrl(from, tr90056b.data.url, '', '')
			  await sleep(1000)
			    const tr90057b = await axios.get('https://meme-api.herokuapp.com/gimme/shemalery')
			await client.sendFileFromUrl(from, tr90057b.data.url, '', '')
			  await sleep(1000)
			    const tr90058b = await axios.get('https://meme-api.herokuapp.com/gimme/Shemales')
			await client.sendFileFromUrl(from, tr90058b.data.url, '', '')
			  await sleep(1000)
			    const tr90059b = await axios.get('https://meme-api.herokuapp.com/gimme/sexyShemales')
			await client.sendFileFromUrl(from, tr90059b.data.url, '', '')
			  await sleep(1000)
			const tr10= await axios.get('https://meme-api.herokuapp.com/gimme/traps')
			await client.sendFileFromUrl(from, tr10.data.url, '', '_Seu pack foi finalizado._\n*🌎Alliαηce Oтαkus🇯🇵⃟ ᴬᵗᵏ*')
			 await sleep(1000)
			break
					
                   		
                   case 'packporno':
                      if (isGroupMsg && !isNsfw) return await client.reply(from,'_Negado._', id)
			
			const por1 = await axios.get('https://meme-api.herokuapp.com/gimme/pornID')
			await client.sendFileFromUrl(from, por1.data.url, '', '', id)
			  await sleep(1000)
			 
			const por2 = await axios.get('https://meme-api.herokuapp.com/gimme/sissyhypno')
			await client.sendFileFromUrl(from, por2.data.url, '', '', id)
			
			  await sleep(1000)
			 
			const por3 = await axios.get('https://meme-api.herokuapp.com/gimme/PornStars')
			await client.sendFileFromUrl(from, por3.data.url, '', '', id)
			
			  await sleep(1000)
			 
			const por4 = await axios.get('https://meme-api.herokuapp.com/gimme/PornIsCheating')
			await client.sendFileFromUrl(from, por4.data.url, '', '', id)
			
			  await sleep(1000)
			 
			//const por5 = await axios.get('https://meme-api.herokuapp.com/gimme/HotStuffNSFW')
		//	await client.sendFileFromUrl(from, por5.data.url, '', '', id)
			
			  await sleep(1000)
			 
			const por6 = await axios.get('https://meme-api.herokuapp.com/gimme/nsfwhardcore')
			await client.sendFileFromUrl(from, por6.data.url, '', '', id)
			
			  await sleep(1000)
			 
			const por7 = await axios.get('https://meme-api.herokuapp.com/gimme/NSFW_GIF')
			await client.sendFileFromUrl(from, por7.data.url, '', '', id)
			
			  await sleep(1000)
			 
			const por8 = await axios.get('https://meme-api.herokuapp.com/gimme/nsfw')
			await client.sendFileFromUrl(from, por8.data.url, '', '', id)
			
			  await sleep(1000)
			 
			const por9 = await axios.get('https://meme-api.herokuapp.com/gimme/GOONED')
			await client.sendFileFromUrl(from, por9.data.url, '', '', id)
			
			  await sleep(1000)
			 
			const por10= await axios.get('https://meme-api.herokuapp.com/gimme/oculusnsfw')
			await client.sendFileFromUrl(from, por10.data.url, '', '', id)
			  await sleep(1000)
			  
			 const por11 = await axios.get('https://meme-api.herokuapp.com/gimme/Doggystyle_NSFW')
			await client.sendFileFromUrl(from, por11.data.url, '', '', id)
			
			  await sleep(1000)
			 const por12 = await axios.get('https://meme-api.herokuapp.com/gimme/NSFWFunny')
			await client.sendFileFromUrl(from, por12.data.url, '', '', id)
			
			  await sleep(1000)
			  const por13 = await axios.get('https://meme-api.herokuapp.com/gimme/nsfw_gifs')
			await client.sendFileFromUrl(from, por13.data.url, '', '', id)
			
			  await sleep(1000)
			  const por14 = await axios.get('https://meme-api.herokuapp.com/gimme/The_Best_NSFW_GIFS')
			await client.sendFileFromUrl(from, por14.data.url, '', '', id)
			
			  await sleep(1000)
			 const por15 = await axios.get('https://meme-api.herokuapp.com/gimme/porn_gifs')
			await client.sendFileFromUrl(from, por15.data.url, '', '', id)
			
			  await sleep(1000)
			 
			 const por16 = await axios.get('https://meme-api.herokuapp.com/gimme/PornStarletHQ')
			await client.sendFileFromUrl(from, por16.data.url, '', '', id)
			
			  await sleep(1000)
			   const por17 = await axios.get('https://meme-api.herokuapp.com/gimme/pornID')
			await client.sendFileFromUrl(from, por17.data.url, '', '', id)
			 await sleep(1000)
			   const por18 = await axios.get('https://meme-api.herokuapp.com/gimme/iwanttobeher')
			await client.sendFileFromUrl(from, por18.data.url, '', '', id)
			 await sleep(1000)
			   const por19 = await axios.get('https://meme-api.herokuapp.com/gimme/creampie')
			await client.sendFileFromUrl(from, por19.data.url, '', '', id)
			 await sleep(1000)
			   const por19l = await axios.get('https://meme-api.herokuapp.com/gimme/creampies')
			await client.sendFileFromUrl(from, por19l.data.url, '', '', id)
		
			  await sleep(1000)
			   const por20 = await axios.get('https://meme-api.herokuapp.com/gimme/HotStuffNSFW')
			await client.sendFileFromUrl(from, por20.data.url, '', '', id)
		  await sleep(1000)
			   const por2u0 = await axios.get('https://meme-api.herokuapp.com/gimme/cumsluts')
			await client.sendFileFromUrl(from, por2u0.data.url, '', '', id)
		 const por2u1 = await axios.get('https://meme-api.herokuapp.com/gimme/cumfetish')
			await client.sendFileFromUrl(from, por2u1.data.url, '', '', id)
			   await sleep(1000)
			   const por21 = await axios.get('https://meme-api.herokuapp.com/gimme/Cuckold')
			await client.sendFileFromUrl(from, por21.data.url, '', '', id)
			   await sleep(1000)
			   const por21k = await axios.get('https://meme-api.herokuapp.com/gimme/coveredincum')
			await client.sendFileFromUrl(from, por21k.data.url, '', '', id)
			   await sleep(1000)
			   const por22 = await axios.get('https://meme-api.herokuapp.com/gimme/MassiveTitsnAss')
			await client.sendFileFromUrl(from, por22.data.url, '', '', id)
			 			   await sleep(1000)
			   const por23 = await axios.get('https://meme-api.herokuapp.com/gimme/adorableporn')
			await client.sendFileFromUrl(from, por23.data.url, '', '', id)
			 await sleep(1000)
			   const por24 = await axios.get('https://meme-api.herokuapp.com/gimme/VerticalGifs')
			await client.sendFileFromUrl(from, por24.data.url, '', ' ', id)
			 const por25 = await axios.get('https://meme-api.herokuapp.com/gimme/PublicSexPorn')
			await client.sendFileFromUrl(from, por25.data.url, '', ' ', id)
			 const por26 = await axios.get('https://meme-api.herokuapp.com/gimme/GirlsOnTop')
			await client.sendFileFromUrl(from, por26.data.url, '', ' ', id)
			 const por27 = await axios.get('https://meme-api.herokuapp.com/gimme/ExhibitionistSex')
			await client.sendFileFromUrl(from, por27.data.url, '', ' ', id)
			 await sleep(1000)
			 const por28 = await axios.get('https://meme-api.herokuapp.com/gimme/NostalgiaFapping')
			await client.sendFileFromUrl(from, por28.data.url, '', 'NostalgiaFapping ', id)
			 const por29 = await axios.get('https://meme-api.herokuapp.com/gimme/CollegeInitiation')
			await client.sendFileFromUrl(from, por29.data.url, '', ' ', id)
			 const por30 = await axios.get('https://meme-api.herokuapp.com/gimme/Nsfw_Amateurs')
			await client.sendFileFromUrl(from, por30.data.url, '', ' ', id)
			 
			 await sleep(1000)
			  const por31 = await axios.get('https://meme-api.herokuapp.com/gimme/AmateurPorn')
			await client.sendFileFromUrl(from, por31.data.url, '', ' ', id)
			 
			 await sleep(1000)
			   const por32 = await axios.get('https://meme-api.herokuapp.com/gimme/BoredandIgnored')
			await client.sendFileFromUrl(from, por32.data.url, '', ' ', id)
			  await sleep(1000)
			   const por33 = await axios.get('https://meme-api.herokuapp.com/gimme/translucent_porn')
			await client.sendFileFromUrl(from, por33.data.url, '', '_Seu pack foi finalizado._\n*🌎Alliαηce Oтαkus🇯🇵⃟ ᴬᵗᵏ*', id)
			 await sleep(2000)
			 
			 
			break
			
			
			
                    //roubado
       
                    case 'edotensei':
        if (!isGroupMsg) return client.reply(from, '‎Este recurso só pode ser usado em grupos‎', id)
        if (!isGroupAdmins) return client.reply(from, '‎Falhado, este comando só pode ser usado por administradores de grupo‎!', id)
        if (!isBotGroupAdmins) return client.reply(from, '‎Ó administrador, faça-me um administrador em grupo primeiro‎ :)', id)
        if (mentionedJidList.length === 0) return client.reply(from, '‎Recurso para remover membros e, em seguida, adicionar membros de volta, enviar comandos‎ !edotensei @membro', id)
        for (let i = 0; i < mentionedJidList.length; i++) {
            await client.sendText(from, `☠${mentionedJidList.join('\n')} ☠`) 
            await client.removeParticipant(groupId, mentionedJidList[i])
             await sleep(10000)
       await     client.reply(from, '*EDOTENSEI*\nJutsu de Invocação: Reencarnação Impura', id)
            await client.sendGiphyAsSticker(from, 'https://media.giphy.com/media/31kTOD8AEPTVcfeT1v/source.gif')
     await     client.sendText(from, '\n\n𒀱        𒀱\n\n         𒀱')
            await client.addParticipant(from,`${mentionedJidList}`)
            await client.sendTextWithMentions(from, `‎Reviveu  ‎@${mentionedJidList}` , id)
        } 
        break
                    
                    
                    case 'pezinho':
			   if (isGroupMsg && !isNsfw) return await client.reply(from,'_Negado._', id)
			const pezin = await axios.get('https://nekos.life/api/v2/img/feet')
			await client.sendFileFromUrl(from, pezin.data.url, '', '🌎Alliαηce Oтαkus🇯🇵⃟ ᴬᵗᵏ', id)
			  await sleep(1000)
			 
			const pezin1 = await axios.get('https://nekos.life/api/v2/img/feet')
			await client.sendFileFromUrl(from, pezin1.data.url, '', '🌎Alliαηce Oтαkus🇯🇵⃟ ᴬᵗᵏ', id)
			break
			       case 'neko':
			
			const nek = await axios.get('https://nekos.life/api/v2/img/neko')
			await client.sendFileFromUrl(from, nek.data.url, '', 'Nyan, nyan...', id)
			  await sleep(1000)
			   client.sendFileFromUrl(from, akaneko.neko(), 'neko.jpg', 'Neko *Nyaa*\n🌎Alliαηce Oтαkus🇯🇵⃟ ᴬᵗᵏ', id)
			
			break
			
			      case 'kaguyasama':
			
			const kaguyasama = await axios.get('https://meme-api.herokuapp.com/gimme/Kaguya_sama')
			await client.sendFileFromUrl(from, kaguyasama.data.url, '', '', id)
			  
			break
			    case 'rezero':
			
			const rezero = await axios.get('https://meme-api.herokuapp.com/gimme/Re_Zero')
			await client.sendFileFromUrl(from, rezero.data.url, '', '', id)
			  
			break
			         case 'tsundere':
			
			const tsundere = await axios.get('https://meme-api.herokuapp.com/gimme/tsunderes')
			await client.sendFileFromUrl(from, tsundere.data.url, '', 'B-Baka!', id)
			  
			break
			         case 'pantsu':
			
			const pantsu = await axios.get('https://meme-api.herokuapp.com/gimme/pantsu')
			await client.sendFileFromUrl(from, pantsu.data.url, '', '👙️', id)
			  
                    break
                       case 'chainsawman':
			
			const ChainsawMan = await axios.get('https://meme-api.herokuapp.com/gimme/ChainsawMan')
			await client.sendFileFromUrl(from, ChainsawMan.data.url, '', '🌎Alliαηce Oтαkus🇯🇵⃟ ᴬᵗᵏ', id)
			  
                    break
                    
                    case 'smaid':
			
			const smaid = await axios.get('https://meme-api.herokuapp.com/gimme/animemaids')
			await client.sendFileFromUrl(from, smaid.data.url, '', '🌎Alliαηce Oтαkus🇯🇵⃟ ᴬᵗᵏ', id)
                        break
                        case 'lalatina':
			
                    if (isGroupMsg && !isNsfw) return await client.reply(from,'_Negado._', id) 
			const lala18 = await axios.get('https://meme-api.herokuapp.com/gimme/lalatina')
			await client.sendFileFromUrl(from, lala18.data.url, '', '')
			const lala181 = await axios.get('https://meme-api.herokuapp.com/gimme/DarknessKS')
			await client.sendFileFromUrl(from, lala181.data.url, '', '')
			break
			       case 'neko18':
			
                    if (isGroupMsg && !isNsfw) return await client.reply(from,'_Negado._', id) 
			const nek18 = await axios.get('https://meme-api.herokuapp.com/gimme/nekogirls')
			await client.sendFileFromUrl(from, nek18.data.url, '', '')
			
			const nek18_3 = await axios.get('https://meme-api.herokuapp.com/gimme/nekomimi')
			await client.sendFileFromUrl(from, nek18_3.data.url, '', '')
			const nek18_2 = await axios.get('https://meme-api.herokuapp.com/gimme/NekoIRL')
			await client.sendFileFromUrl(from, nek18_2.data.url, '', 'Nyan, nyan😌️...\n🌎Alliαηce Oтαkus🇯🇵⃟ ᴬᵗᵏ', id)
		break
		
		   case 'furry':
			
                    if (isGroupMsg && !isNsfw) return await client.reply(from,'_Negado._', id) 
			const furry = await axios.get('https://meme-api.herokuapp.com/gimme/yiff')
			await client.sendFileFromUrl(from, furry.data.url, '', '🐺️')
			break
	
			
                    	case 'ativos':
                    	case 'ranked':
                        case 'rank':
                         if (!isGroupMsg) return client.reply(from, 'Somente grupos.', id)
			msgcount.sort((a, b) => (a.msg < b.msg) ? 1 : -1)
            let active2 = '*◆━━━━━▣ TOP 1 ▣━━━━━◆*\n\n'
            try {
                for (let i = 0; i < 1; i++) {
					const aRandVar = await client.getContact(msgcount[i].id)
					var getPushname = aRandVar.pushname
					if (getPushname == null) getPushname = 'wa.me/' + msgcount[i].id.replace('@c.us', '')
					active2 += `👑 *${getPushname}* 👑\n\n`
				}
                await client.sendText(from, active2)
               
            } catch (error) { 
				await client.reply(from, 'Lista de mensagens muito baixo para criar TOP30', id)
				console.log(color('[ATIVOS]', 'crimson'), color(`→ Obtive erros no comando ${prefix}${command} → ${error.message} - Você pode ignorar.`, 'gold'))
			}
          
            
            if (!isGroupMsg) return client.reply(from, mess.sogrupo(), id)
			msgcount.sort((a, b) => (a.msg < b.msg) ? 1 : -1)
            let active1 = '     RANKING DOS TOP 30 ATIVOS\n\n'
            try {
                for (let i = 0; i < 30; i++) {
					const aRandVar = await client.getContact(msgcount[i].id)
					var getPushname = aRandVar.pushname
					if (getPushname == null) getPushname = 'wa.me/' + msgcount[i].id.replace('@c.us', '')
					active1 += `${i + 1} ✨️ ${getPushname}\n▻ Mensagens: ${msgcount[i].msg}\n\n`
				}
                await client.sendText(from, active1)
                  await client.sendText(from, 'Não está no TOP 30? Use o comando !perfil\n_Contagem feita nos grupos aonde você e a Lalatina estiver, contagem somente com BOT on. Mínimo é 50 mensagens por semana._')
            } catch (error) { 
				await client.reply(from, mess.tenpeo(), id)
				console.log(color('[ATIVOS]', 'crimson'), color(`→ Obtive erros no comando ${prefix}${command} → ${error.message} - Você pode ignorar.`, 'gold'))
			}
            break
            
         
            
                        case 'slogan':
            if (args.length == 0) return client.reply(from, 'Cade a frase?', id)
            const slog = await axios.get(`http://api.haipbis.xyz/randomcooltext?text=${body.slice(8)}`)
			await client.sendFileFromUrl(from, slog.data.image, slog.data.text, 'Elegante não é?\n🌎Alliαηce Oтαkus🇯🇵⃟ ᴬᵗᵏ', id)
            break
                     
        case 'tetas':
           
                    if (isGroupMsg && !isNsfw) return await client.reply(from,'_Negado._', id) 
           
           
			
				const tits1 = await axios.get('https://meme-api.herokuapp.com/gimme/tits')
				client.sendFileFromUrl(from, tits1.data.url, '', '🌎Alliαηce Oтαkus🇯🇵⃟ ᴬᵗᵏ', id)
			
				const tits2 = await axios.get('https://meme-api.herokuapp.com/gimme/BestTits')
				client.sendFileFromUrl(from, tits2.data.url, '', '🌎Alliαηce Oтαkus🇯🇵⃟ ᴬᵗᵏ', id)
			
				const tits22 = await axios.get('https://meme-api.herokuapp.com/gimme/boobs')
				client.sendFileFromUrl(from, tits22.data.url, '', '🌎Alliαηce Oтαkus🇯🇵⃟ ᴬᵗᵏ', id)
			
				const tits3 = await axios.get('https://meme-api.herokuapp.com/gimme/BiggerThanYouThought')
				client.sendFileFromUrl(from, tits3.data.url, '', '🌎Alliαηce Oтαkus🇯🇵⃟ ᴬᵗᵏ', id)
			
				const tits4 = await axios.get('https://meme-api.herokuapp.com/gimme/smallboobs')
				client.sendFileFromUrl(from, tits4.data.url, '', '🌎Alliαηce Oтαkus🇯🇵⃟ ᴬᵗᵏ', id)
			
				const tits5 = await axios.get('https://meme-api.herokuapp.com/gimme/TinyTits')
				client.sendFileFromUrl(from, tits5.data.url, '', '🌎Alliαηce Oтαkus🇯🇵⃟ ᴬᵗᵏ', id)
			
				const tits6 = await axios.get('https://meme-api.herokuapp.com/gimme/SmallTitsHugeLoad')
				client.sendFileFromUrl(from, tits6.data.url, '', '🌎Alliαηce Oтαkus🇯🇵⃟ ᴬᵗᵏ', id)
			
				const tits7 = await axios.get('https://meme-api.herokuapp.com/gimme/amazingtits')
				client.sendFileFromUrl(from, tits7.data.url, '', '🌎Alliαηce Oтαkus🇯🇵⃟ ᴬᵗᵏ', id)
		
				
			
            break

                    
                    
            
			
			      case 'ecchi':
		
             if (isGroupMsg && !isNsfw) return await client.reply(from,'_Negado._', id) 
                
				
					const ecchi = await axios.get('https://nekos.life/api/v2/img/erok')
					await client.sendFileFromUrl(from, ecchi.data.url, '🌎Alliαηce Oтαkus🇯🇵⃟ ᴬᵗᵏ','🌎Alliαηce Oтαkus🇯🇵⃟ ᴬᵗᵏ')
				
					const ecchi1 = await axios.get('https://nekos.life/api/v2/img/erokemo')
					await client.sendFileFromUrl(from, ecchi1.data.url, '🌎Alliαηce Oтαkus🇯🇵⃟ ᴬᵗᵏ', '🌎Alliαηce Oтαkus🇯🇵⃟ ᴬᵗᵏ') 
		                        const ecchi3 = await axios.get('https://nekos.life/api/v2/img/ero')
					await client.sendFileFromUrl(from, ecchi3.data.url, '🌎Alliαηce Oтαkus🇯🇵⃟ ᴬᵗᵏ', '🌎Alliαηce Oтαkus🇯🇵⃟ ᴬᵗᵏ')
			break
					
       
			
                    			
		case 'unban':		
		case 'unkick':
			
			if (isGroupMsg && isGroupAdmins) {
				if (!isBotGroupAdmins) return client.reply(from, mess.error.Ba, id)
				if (!quotedMsg) return client.reply(from, 'Marque a mensagem de quem foi banido.', id) 
				const unbanq = quotedMsgObj.sender.id
				await client.sendTextWithMentions(from, `✍Desfazendo ban do(a) @${unbanq} e permitindo entrada dele(a)..`)
				await client.addParticipant(groupId, unbanq)
			} else if (isGroupMsg && isOwner) {
				if (!isBotGroupAdmins) return client.reply(from, mess.error.Ba, id)
				if (!quotedMsg) return client.reply(from, 'Marque a mensagem de quem foi banido.', id) 
				const unbanq = quotedMsgObj.sender.id
				
				await client.addParticipant(groupId, unbanq)
				await client.sendTextWithMentions(from, `Desfazendo ban do(a) @${unbanq} e permitindo entrada dele(a)...`)
		
			} else if (isGroupMsg) {
				await client.reply(from, 'Desculpe, somente os administradores podem usar esse comando...', id)
			} else {
				await client.reply(from, 'Esse comando apenas pode ser usado em grupos!', id)
			}
			client.sendGiphyAsSticker(from, 'https://media.giphy.com/media/qBq1twSzo7nr3H8zx2/giphy.gif')
			// client.sendVideoAsGif(from,  './media/unban.mp4' , id )
            break

                        case 'add':
			
            if (!isGroupMsg) return client.reply(from, mess.error.Gp, id)
           if(!isGroupAdmins) return client.reply(from, 'Negado.', message.id)
	        if (args.length !== 1) return client.reply(from, 'Você precisa especificar o número de telefone.', id)
            try {
                await client.addParticipant(from,`${args[0]}@c.us`)
 
              await   client.sendVideoAsGif(from, './media/bem.mp4', 'bem.mp4' , '_Leia às regras na descrição, ou use comando !groupinfo. Lista de comandos use !menu_ ')
            } catch {
                client.reply(from, mess.error.Ad, id)
            }
            break
                    

                    
                    
              	
        case 'frase':
		
			const rcit = fs.readFileSync('./lib/frases.txt').toString().split('\n')
			const racon = rcit[Math.floor(Math.random() * rcit.length)]
			console.log(racon)
			await client.reply(from, racon, id)
			break
                    
                        case 'curiosidade':
			
			const rcurio = fs.readFileSync('./lib/curiosidades.txt').toString().split('\n')
			const rsidd = rcurio[Math.floor(Math.random() * rcurio.length)]
			console.log(rsidd)
			await client.reply(from, rsidd, id)
			break
			
				
				  case 'lala':
				  
		
			try {
				const iris = await axios.get(`http://simsumi.herokuapp.com/api?text=${body.slice(6)}&lang=pt`)
				if (iris.data.success == '') {
					console.log('Request falhou, usando respostas locais...')
					let rndrl = fs.readFileSync('./lib/reply.txt').toString().split('\n')
					let repl = rndrl[Math.floor(Math.random() * rndrl.length)]
					let resmf = repl.replace('%name$', `${name}`).replace('%battery%', `${lvpc}`)
					console.log(resmf)
					client.reply(from, resmf, id)
				} else {
					await client.reply(from, iris.data.success, id)
				}
			} catch (error) {
					console.log('Request falhou, usando respostas locais...')
					let rndrl = fs.readFileSync('./lib/reply.txt').toString().split('\n')
					let repl = rndrl[Math.floor(Math.random() * rndrl.length)]
					let resmf = repl.replace('%name$', `${name}`).replace('%battery%', `${lvpc}`)
					console.log(resmf)
					client.reply(from, resmf, id)
			}
			break
			
			case 'desligarbot':
			
			 await client.sendText(from, 'Desligando...')
			 
			     await client.sendText(from, '꧁§༺⚔ᴮ ᴼ ᵀ ➻❥ᴼ ᶠ ᶠ ঔৣ꧂')
			 await client.kill()
   
			
		
			break
			
			
			 case 'ping':
			
      client.sendText(from, `Aim!\n_Minha velocidade é de ${processTime(t, moment())} segundos._`)
            break

			
       case 'clima':
			
       		if (args.length == 0) return client.reply(from, 'Insira o nome da sua cidade.', id)
            try {
				const clima = await axios.get(`https://pt.wttr.in/${body.slice(7)}?format=Cidade%20=%20%l+\n\nEstado%20=%20%C+%c+\n\nTemperatura%20=%20%t+\n\nUmidade%20=%20%h\n\nVento%20=%20%w\n\nLua agora%20=%20%m\n\nNascer%20do%20Sol%20=%20%S\n\nPor%20do%20Sol%20=%20%s`)
				await client.sendFileFromUrl(from, `https://wttr.in/${body.slice(7)}.png`, '', `A foto acima contém uma previsão de 2 dias, a mensagem abaixo é o clima agora.\n\n${clima.data}\n🌎Alliαηce Oтαkus🇯🇵⃟ ᴬᵗᵏ`, id)
            } catch {
                client.reply(from, 'Estranho...\nCertifique-se de não estar usando acentos ok?', id)
            }
            break
				
				
		case 'akinator':
			
			const region = 'pt';
			if (args[0] == '-r') {
				let akinm = args[1].match(/^[0-9]+$/)
				if (!akinm) return client.reply(from, 'Responda apenas com 0 ou 1!\n0 = Sim\n1 = Não', id)
				const aki = new Aki(region);
				await aki.start();
				const myAnswer = `${args[1]}`
				await aki.step(myAnswer);
				await client.reply(from, `Questão: ${aki.question}\n\nProgresso: ${aki.progress}\n\nResponda com !akinator -r [0 ou 1], 0 = sim, 1 = não.`, id)
			} else {
				const aki = new Aki(region);
				await aki.start()
				await client.reply(from, `Questão: ${aki.question}\n\nResponda com !akinator -r [0 ou 1], 0 = sim, 1 = não.`, id)
			}
			break
			
			
                    
                    
                case 'gadometro':
		case 'gado':
			gaak = body.trim().split(' ')
			var chifre = ["ultra extreme gado", "Gado-Master", "Gado-Rei", "Gado", "Escravo-ceta", "Escravo-ceta Maximo", "Gacorno?", "Jogador De Forno Livre<3", "Mestre Do Frifai<3<3", "Gado-Manso", "Gado-Conformado", "Gado-Incubado", "Gado Deus", "Mestre dos Gados", "TPTDPBCT=Topa Tudo Por Buceta KKKJ", "Gado Comum", "Mini-Pedro", "Mini Gadinho", "Gado Iniciante", "Gado Basico", "Gado Intermediario", "Gado Avançado", "Gado Proffisional", "Gado Mestre", "Gado Chifrudo", "Corno Conformado", "Corno HiperChifrudo", "Chifrudo Deus", "Mestre dos Chifrudos"]
			var gado = chifre[Math.floor(Math.random() * chifre.length)]
			if (args.length == 1) {
				await client.sendTextWithMentions(from, gaak[1] + ' é ' + lvpc + '% ' + gado + 'KKKKJ.')
			} else {
				await client.reply(from, `Você é ` + lvpc + '% ' + gado + ' KKKKJ.', id)
			}
			break    
			
			
		case 'rolette':
            if (double == 1) {
            await client.reply(from, 'Bang, ela disparou e você morreu, é game over.', id)
            } else if (double == 2) {
            await client.reply(from, 'Você continua vivo, passe a vez.', id)
			}
			break
			           c
        case 'screenshot':
            const _query = body.slice(12)
            if (!_query.match(isUrl)) return client.reply(from, mess.error.Iv, id)
            if (args.length == 0) return client.reply(from, 'Sinto cheiro de ortografia incorreta [faltou https:// ?]!', id)
            await ss(_query)
            await sleep(4000)
			await client.sendFile(from, './lib/media/img/screenshot.jpeg', 'ss.jpeg', 'Se certifique de evitar usar isso com pornografia.', id)
            .catch(() => client.reply(from, `Erro na screenshot do site ${_query}`, id))
            break
                    
                    		
		case 'ship':
            lvak = body.trim().split(' ')
			if (args.length == 2) {
				await client.sendTextWithMentions(from, '❤️ ' + lvak[1] + ' tem um chance de ' + lvpc + '% de namorar ' + lvak[2] + '. 👩‍❤️‍👨')
            } else {
				await client.reply(from, 'Faltou marcar o casal de pombinhos!', id)
            }
			break	
			

        case 'gay':
            gaak = body.trim().split(' ')
    	    var lgbt = ["lésbica", "gay", "bissexual", "transgenero", "queer", "intersexual", "pedro-sexual", "negrosexual", "helicoptero sexual", "ageneros", "androgino", "assexual", "macaco-sexual", "dedo-sexual", "Sexo-Inexplicavel", "predio-sexual", "sexual-não-sexual", "pansexual", "kink", "incestuoso", "comedor-de-casadas", "unicornio-sexual", "maniaco-sexual"]
    	    var guei = lgbt[Math.floor(Math.random() * lgbt.length)]
			if (args.length == 1) {
				await client.sendTextWithMentions(from, gaak[1] + ' é ' + lvpc + '% ' + guei + '.')
            } else {
				await client.reply(from, `Você é ` + lvpc + '% ' + guei + '.', id)
            }
                    
                    break			
        case 'detector' :
            if (!isGroupMsg) return client.reply(from, 'Apenas grupos!', id)
			await client.reply(from, 'Calculando foto dos participantes do grupo...', id)
            await sleep(3000)
            const eu = await client.getGroupMembers(groupId)
            const gostosa = eu[Math.floor(Math.random() * eu.length)]
			console.log(gostosa.id)
            await client.sendTextWithMentions(from, `*ＤＥＴＥＣＴＯＲ   ＤＥ  ＧＯＳＴＯＳＡＳ👩‍⚕️*\n\n*pi pi pi pi*  \n*pipipipi🚨🚨🚨pipipipi🚨🚨🚨pipipipi🚨🚨🚨pipi*\n\n@${gostosa.id.replace(/@c.us/g, '')} *PARADA(O) AÍ🖐*\n\n*VOCÊ ACABA DE RECEBER DUAS MULTAS*\n\n*1 por não dar bom dia,boa tarde,boa noite e outra por ser muito*\n\n*gostosa(o)*\n\n*valor da multa:*\n*FOTO DA TETINHA NO PV kkkkk*`)
            await sleep(2000)
            break	
                    			
        case 'makesticker':
            if (args.length == 0) return client.reply(from, 'Faltou algo para usar de referência!', id)
            const stkm = await fetch(`http://api.fdci.se/rep.php?gambar=${body.slice(7)}`)
			const stimg = await stkm.json()
            let stkfm = stimg[Math.floor(Math.random() * stimg.length) + 1]
			console.log(stkfm)
            await client.sendStickerfromUrl(from, stkfm)
			.catch(() => {
                client.reply(from, 'Nenhuma imagem recebida ou servidor offline, tente mais tarde.', id)
            })
            break
                    		
		case 'gender':
		case 'genero':
            if (args.length == 0) return client.reply(from, 'Coloque um nome, apenas um, nada de sobrenome ou nomes inteiros, ainda mais por sua segurança!', id)
			const seanl = await axios.get(`https://api.genderize.io/?name=${args[0]}`)
			const gender = seanl.data.gender.replace('female', 'mulheres').replace('male', 'homens')
			await client.reply(from, `O nome "${seanl.data.name}" é mais usado por ${gender}.`, id)
			break
			
					
		case 'math':
            if (args.length == 0) return client.reply(from, 'Você não especificou uma conta matematica.', id)
            const mtk = body.slice(6)
            if (typeof math.evaluate(mtk) !== "number") {
           client.reply(from, `Você definiu mesmo uma conta? Isso não parece uma.`, id)
			} else {
				client.reply(from, `_A equação:_\n\n*${mtk}*\n\n_tem resultado de:_\n\n*${math.evaluate(mtk)}*`, id)
			}
			break
			
			
		case 'inverter':
            if (args.length == 0) return client.reply(from, 'Você não especificou uma frase para ser invertida.', id)
			const inver = body.slice(10).split('').reverse().join('')
			await client.reply(from, inver, id)
			break
			
			
		case 'contar':
            if (args.length == 0) return client.reply(from, 'Isso possui 0 letras, afinal, não há texto.', id)
			const count = body.slice(8).length
			await client.reply(from, `O texto possui ${count} letras.`, id)
			break
			
			        case 'image':
			        case 'imagem':
			         case 'foto':
            if (args.length == 0) return client.reply(from, 'Faltou um nome!', id)
            const linp = await fetch(`https://fdciabdul.tech/api/pinterest?keyword=${body.slice(7)}`)
			const pint = await linp.json()
            let erest = pint[Math.floor(Math.random() * pint.length) + 1]
			console.log(erest)
            await client.sendFileFromUrl(from, erest, '', '🌎Alliαηce Oтαkus🇯🇵⃟ ᴬᵗᵏ \n _Fonte: Pinterest_ ', id)
			.catch(() => {
                client.reply(from, 'Nenhuma imagem recebida ou servidor offline, tente mais tarde.', id)
            })
            break
			
		
		 case 'yuri':
		
               if (isGroupMsg && !isNsfw) return await client.reply(from,'_Negado._', id)
           
				
					const femdom = await axios.get('https://meme-api.herokuapp.com/gimme/yuri')
					await client.sendFileFromUrl(from, femdom.data.url, '', '🌎Alliαηce Oтαkus🇯🇵⃟ ᴬᵗᵏ', id)
				
					const femdom1 = await axios.get('https://nekos.life/api/v2/img/yuri')
					await client.sendFileFromUrl(from, femdom1.data.url, '', '🌎Alliαηce Oтαkus🇯🇵⃟ ᴬᵗᵏ', id)
				
					const femdom2 = await axios.get('https://nekos.life/api/v2/img/eroyuri')
					await client.sendFileFromUrl(from, femdom2.data.url, '', '🌎Alliαηce Oтαkus🇯🇵⃟ ᴬᵗᵏ', id)
				
			
			break
                                       case 'femdom':
		   if (isGroupMsg && !isNsfw) return await client.reply(from,'_Negado._', id)
		
           
                                       const femdom784 = await axios.get('https://meme-api.herokuapp.com/gimme/hentaifemdom')
					await client.sendFileFromUrl(from, femdom784.data.url, '', '🌎Alliαηce Oтαkus🇯🇵⃟ ᴬᵗᵏ', id)
				
					const femdom785 = await axios.get('https://nekos.life/api/v2/img/femdom')
					await client.sendFileFromUrl(from, femdom785.data.url, '', '🌎Alliαηce Oтαkus🇯🇵⃟ ᴬᵗᵏ', id)
				
			break


        case 'futanari':
			
             if (isGroupMsg && !isNsfw) return await client.reply(from,'_Negado._', id) 
              
				const futanari = await axios.get('https://nekos.life/api/v2/img/futanari')
				await client.sendFileFromUrl(from, futanari.data.url, '', '🌎Alliαηce Oтαkus🇯🇵⃟ ᴬᵗᵏ', id)
			
				const futanari11 = await axios.get('https://meme-api.herokuapp.com/gimme/futanari')
				await client.sendFileFromUrl(from, futanari11.data.url, '', '🌎Alliαηce Oтαkus🇯🇵⃟ ᴬᵗᵏ', id)
			
			break	
			
			
			
			
        case 'yaoi':
           if (isGroupMsg && !isNsfw) return await client.reply(from,'_Negado._', id)
           const yaoi0 = await axios.get('https://meme-api.herokuapp.com/gimme/yaoi')
					await client.sendFileFromUrl(from, yaoi0.data.url, '', '🌎Alliαηce Oтαkus🇯🇵⃟ ᴬᵗᵏ', id)
					   const yaoi1 = await axios.get('https://meme-api.herokuapp.com/gimme/YaoiNSFW')
					await client.sendFileFromUrl(from, yaoi1.data.url, '', '🌎Alliαηce Oтαkus🇯🇵⃟ ᴬᵗᵏ', id)
            break


      
		
			
		case 'cafune':
			if (double == 1) {
				const cfne = await axios.get('https://nekos.life/api/v2/img/pat')
				await client.sendFileFromUrl(from, cfne.data.url, '', '', id)
			} else if (double == 2) {
				const cfne = await axios.get('https://nekos.life/api/v2/img/cuddle')
				await client.sendFileFromUrl(from, cfne.data.url, '', '', id)
			}
			break	
			  case 'google':
            if (args.length == 0) return client.reply(from, `Digite algo para buscar.`, id)
		    const googleQuery = body.slice(8)
            google({ 'query': googleQuery }).then(results => {
            let vars = `_*Resultados da pesquisa Google de: ${googleQuery}*_\n`
            for (let i = 0; i < results.length; i++) {
                vars +=  `\n═════════════════\n*Titulo >* ${results[i].title}\n\n*Descrição >* ${results[i].snippet}\n\n*Link >* ${results[i].link}`
            }
               client.reply(from, vars, id)
            }).catch(e => {
                client.reply(from, 'Erro ao pesquisar na google.', id)
            })
            break

					

		
              case 'girl':
    	    var items = ["garota adolescente", "saycay", "alina nikitina", "belle delphine", "teen girl", "teen cute", "japanese girl", "garota bonita oriental", "oriental girl", "korean girl", "chinese girl", "e-girl", "teen egirl", "brazilian teen girl", "pretty teen girl", "korean teen girl", "garota adolescente bonita", "menina adolescente bonita", "egirl", "cute girl"];
    	    var cewe = items[Math.floor(Math.random() * items.length)];
			console.log(cewe)
			var girl = "https://fdciabdul.tech/api/pinterest?keyword=" + cewe;
			axios.get(girl)
            	.then((result) => {
				var b = JSON.parse(JSON.stringify(result.data));
				var cewek =  b[Math.floor(Math.random() * b.length)];
              	client.sendFileFromUrl(from, cewek, "result.jpg", "🌎Alliαηce Oтαkus🇯🇵⃟ ᴬᵗᵏ\n _Fonte: Pinterest._", id)
			})
			break
			
			
        case 'nh':
            if (isGroupMsg && !isNsfw)  {
              
				if (args.length == 1) {
					const nuklir = body.split(' ')[1]
					client.reply(from, mess.wait, id)
					const cek = await nhentai.exists(nuklir)
					if (cek == true)  {
						try {
							const api = new API()
							const pic = await api.getBook(nuklir).then(book => {
								return api.getImageURL(book.cover)
							})
							const dojin = await nhentai.getDoujin(nuklir)
							const { title, details, link } = dojin
							const { parodies, tags, artists, groups, languages, categories } = await details
							var teks = `*Titulo* : ${title}\n\n*Parodia de* : ${parodies}\n\n*Tags* : ${tags.join(', ')}\n\n*Artistas* : ${artists.join(', ')}\n\n*Grupos* : ${groups.join(', ')}\n\n*Linguagens* : ${languages.join(', ')}\n\n*Categoria* : ${categories}\n\n*Link* : ${link}`
							await client.sendFileFromUrl(from, pic, '', teks + '\n\n' + 'Aguarde, estou enviando o hentai, pode demorar varios minutos dependendo da quantidade de paginas.', id)
							await client.sendFileFromUrl(from, `https://nhder.herokuapp.com/download/nhentai/${nuklir}/zip`, 'hentai.zip', id)
						} catch (err) {
							client.reply(from, '[❗] Ops! Deu erro no envio!', id)
						}
					} else {
						client.reply(from, '[❗] Aqui diz que não achou resultados...')
					}
				} else {
					client.reply(from, 'Você usou errado, tente verificar se o comando está correto.')
				}
			} else {
				if (args.length == 1) {
					const nuklir = body.split(' ')[1]
					client.reply(from,  id)
					const cek = await nhentai.exists(nuklir)
					if (cek == true)  {
						try {
							const api = new API()
							const pic = await api.getBook(nuklir).then(book => {
								return api.getImageURL(book.cover)
							})
							const dojin = await nhentai.getDoujin(nuklir)
							const { title, details, link } = dojin
							const { parodies, tags, artists, groups, languages, categories } = await details
							var teks = `*Titulo* : ${title}\n\n*Parodia de* : ${parodies}\n\n*Tags* : ${tags.join(', ')}\n\n*Artistas* : ${artists.join(', ')}\n\n*Grupos* : ${groups.join(', ')}\n\n*Linguagens* : ${languages.join(', ')}\n\n*Categoria* : ${categories}\n\n*Link* : ${link}`
							await client.sendFileFromUrl(from, pic, '', teks + '\n\n' + 'Aguarde, estou enviando o hentai, pode demorar varios minutos dependendo da quantidade de paginas.', id)
							await client.sendFileFromUrl(from, `https://nhder.herokuapp.com/download/nhentai/${nuklir}/zip`, 'hentai.zip', id)
						} catch (err) {
                        client.reply(from, '[❗] Ops! Deu erros no envio!', id)
						}
					} else {
						client.reply(from, '[❗] Aqui diz que não achou resultados...')
					}
				} else {
					client.reply(from, 'Você usou errado, tente verificar se o comando está correto.')
				}
			}
			break
				
						
		case 'loli':
               if (isGroupMsg && !isNsfw) return await client.reply(from,'_Negado._', id) 
				const loliz = await axios.get('https://nekos.life/api/v2/img/keta')
				await client.sendFileFromUrl(from, loliz.data.url, '', '🌎Alliαηce Oтαkus🇯🇵⃟ ᴬᵗᵏ', id)
			
			break
			      case 'loli2':
			const onefive = Math.floor(Math.random() * 145) + 1
			client.sendFileFromUrl(from, `https://media.publit.io/file/Twintails/${onefive}.jpg`, 'loli.jpg', '🌎Alliαηce Oтαkus🇯🇵⃟ ᴬᵗᵏ', id)
            break

                     
                       
                        case 'nick':
teks = body.slice(5)
 const ger = await axios.get(`http://brizas-api.herokuapp.com/gerador/fancytext?apikey=brizaloka&text=${teks}`)
teks = ` 🧙🏻‍♂️NICKS GERADOS!🧙🏻‍♂️

🍙Primeiro ${ger.data.random_1} 
🍙Segundo ${ger.data.random_2} 
🍙Térceiro ${ger.data.random_3} 
🍙Quarto ${ger.data.random_4} 
🍙Quinto ${ger.data.random_5}
 
   👾EXTRAS👾
 👾${ger.data.squares}
 👾${ger.data.inverted_squares}
 👾${ger.data.italic}
 👾${ger.data.bold}
 👾${ger.data.future_alien}
 👾${ger.data.asian_1}
 👾${ger.data.asian_2}
 👾${ger.data.squiggle}
 👾${ger.data.squiggle_2}
 👾${ger.data.squiggle_3}
 👾${ger.data.squiggle_4}
 👾${ger.data.neon}
 
 
➣    ▉║█▐▉▉▐▐▍█║▍▉▏▍▍
➣    ▉║█▐▉▉▐▐▍█║▍▉▏▍▍
    
 _by hunterzin 🇯🇵⃟ ᴬᵗᵏ_
 `
await client.sendText(from, teks)
break
           
            case 'smetadinha':
			     const metadinha1 = await axios.get('https://random-couple.herokuapp.com/api/metadinha')
				client.sendImageAsSticker(from, metadinha1.data.result.menino, {  author: 'Lalatina BOT', pack: '🌎Alliαηce Oтαkus🇯🇵⃟ ᴬᵗᵏ\nby hunterzin 🇯🇵⃟ ᴬᵗᵏ'})
			
				client.sendImageAsSticker(from, metadinha1.data.result.menina, {  author: 'Lalatina BOT', pack: '🌎Alliαηce Oтαkus🇯🇵⃟ ᴬᵗᵏ\nby hunterzin 🇯🇵⃟ ᴬᵗᵏ'})
				break
				case 'metadinha':
			     const metadinha2 = await axios.get('https://random-couple.herokuapp.com/api/metadinha')
				client.sendFileFromUrl(from, metadinha2.data.result.menino, '', '')
			
				client.sendFileFromUrl(from, metadinha2.data.result.menina, '', '🌎Alliαηce Oтαkus🇯🇵⃟ ᴬᵗᵏ\n _by hunterzin 🇯🇵⃟ ᴬᵗᵏ_')
				break
             /*  case 'hentaitemp':
              
               const intervRemind = setInterval(async () => {
  if (!isGroupMsg) return client.reply(from, 'Negado', message.id)
            if (!isGroupAdmins) return client.reply(from, 'Negado', message.id)
    
        
         
		    const femdom788 = await axios.get('https://meme-api.herokuapp.com/gimme/Erza34')
					await client.sendFileFromUrl(from, femdom788.data.url, '', '*🌎Alliαηcє Oтαkus🇯🇵⃟ ᴬᵗᵏ*\n⤷http://bit.ly/AllianceOtakus\n*🌍Aηıмєs Sтıcкєrs🇯🇵⃟ ᴬᵗᵏ*\n*🌎Amızαdєs Sтıckєrs🇯🇵⃟ ᴬᵗᵏ*\n⤷http://bit.ly/FigurinhaStickers\n*🌎Alliαηce Tєlєgrɑm™🇯🇵⃟ ᴬᵗᵏ*\n⤷http://linktr.ee/allianceotakus\n*🌎Alliαηcє Avaliação🇯🇵⃟ ᴬᵗᵏ*\n⤷http://bit.ly/AtkAvaliacao\n*🌎FeedBack🇯🇵⃟ ᴬᵗᵏ*\n⤷bit.ly/AtkFeedBack\n\n_⚠️ Invasão de PV Insta Ban!⚠️_\n*📲 Siga ηo Iηsтagram:*\n⤷ http://bit.ly/AllianceInstagram\n\n      *Lalatina BOT* 😉️')  
				
                          await  clearInterval(intervRemind)
            
        }, 59000)       
   	
 
        break*/
			   case 'waifu34':
		   
            if (isGroupMsg && !isNsfw) return await client.reply(from,'_Negado._', id) 
              
				
					const waifu34 = await axios.get('https://meme-api.herokuapp.com/gimme/waifus34')
					await client.sendFileFromUrl(from, waifu34.data.url, '', '🌎Alliαηce Oтαkus🇯🇵⃟ ᴬᵗᵏ', id)
                                              
            break
            
			   case 'hentai':
		   
            if (isGroupMsg && !isNsfw) return await client.reply(from,'_Negado._', id) 
              
				
					const clas55 = await axios.get('https://nekos.life/api/v2/img/classic')
					await client.sendFileFromUrl(from, clas55.data.url, '', '🌎Alliαηce Oтαkus🇯🇵⃟ ᴬᵗᵏ', id)
				 await sleep(2000)
				
					const hentai4l = await axios.get('https://nekos.life/api/v2/img/pussy_jpg')
					await client.sendFileFromUrl(from, hentai4l.data.url, '', '🌎Alliαηce Oтαkus🇯🇵⃟ ᴬᵗᵏ', id)
				 await sleep(2000)
					const hentai5 = await axios.get('https://nekos.life/api/v2/img/hentai')
					await client.sendFileFromUrl(from, hentai5.data.url, '', '🌎Alliαηce Oтαkus🇯🇵⃟ ᴬᵗᵏ', id)
				 await sleep(2000)
					const hentai6 = await axios.get('https://nekos.life/api/v2/img/pussy')
					await client.sendFileFromUrl(from, hentai6.data.url, '', '🌎Alliαηce Oтαkus🇯🇵⃟ ᴬᵗᵏ', id)
				
					 await sleep(2000)
				
					const hentai2 = await axios.get('https://nekos.life/api/v2/img/pussy_jpg')
					await client.sendFileFromUrl(from, hentai2.data.url, '', '🌎Alliαηce Oтαkus🇯🇵⃟ ᴬᵗᵏ', id)
				 await sleep(2000)
					const clas1111 = await axios.get('https://nekos.life/api/v2/img/classic')
					await client.sendFileFromUrl(from, clas1111.data.url, '', '🌎Alliαηce Oтαkus🇯🇵⃟ ᴬᵗᵏ', id)
				 await sleep(2000)
					const hentai41 = await axios.get('https://nekos.life/api/v2/img/hentai')
					await client.sendFileFromUrl(from, hentai41.data.url, '', '🌎Alliαηce Oтαkus🇯🇵⃟ ᴬᵗᵏ', id)
				 await sleep(2000)
					const hentai51 = await axios.get('https://nekos.life/api/v2/img/pussy')
					await client.sendFileFromUrl(from, hentai51.data.url, '', '🌎Alliαηce Oтαkus🇯🇵⃟ ᴬᵗᵏ', id)
				
						 await sleep(1000)
					const hentai3st = await axios.get('https://nekos.life/api/v2/img/Random_hentai_gif')
					await client.sendStickerfromUrl(from, hentai3st.data.url)
				
			
			
            break
            			
			     case 'stickerhentai':
			      case 'hentaifigura':
			      case 'figurahentai':
			  case 'hsticker':
			
                               const lin = await axios.get('https://nekos.life/api/v2/img/Random_hentai_gif')
				await client.sendStickerfromUrl(from, lin.data.url, { method: 'get' }, {  author: 'Lalatina BOT', pack: '🌎Alliαηce Oтαkus🇯🇵⃟ ᴬᵗᵏ'})
				await sleep(1000)
				const lint = await axios.get('https://meme-api.herokuapp.com/gimme/hentai_gif')
				await client.sendStickerfromUrl(from, lint.data.url, { method: 'get' }, {  author: 'Lalatina BOT', pack: '🌎Alliαηce Oтαkus🇯🇵⃟ ᴬᵗᵏ'})
		const icon = await axios.get('https://nekos.life/api/v2/img/nsfw_avatar')
				await client.sendImageAsSticker(from, icon.data.url, { author: 'Lalatina BOT', pack: '🌎Alliαηce Oтαkus🇯🇵⃟ ᴬᵗᵏ', keepScale: true })
			break
			
				
			 case 'lamber':
		   if (isGroupMsg && !isNsfw) return await client.reply(from,'_Negado._', id)	
    	    const rlick = ["https://nekos.life/api/v2/img/kuni", "https://nekos.life/api/v2/img/les"];
    	    const rlickc = rlick[Math.floor(Math.random() * rlick.length)];
			const lick = await axios.get(rlickc)
			
				await client.sendStickerfromUrl(from, lick.data.url, { method: 'get' }, { author: 'Lalatina BOT', pack: '🌎Alliαηce Oтαkus🇯🇵⃟ ᴬᵗᵏ'})
			
			await client.reply(from,'Lala te deu uma lambida 😛️', id)
			break
			    case 'pink':
			       if (isGroupMsg && !isNsfw) return await client.reply(from,'_Negado._', id)	
            const pink = await axios.get('https://meme-api.herokuapp.com/gimme/GirlsinPinkUndies');
           
            await client.sendFileFromUrl(from, pink.data.url, '', `🌎Alliαηce Oтαkus🇯🇵⃟ ᴬᵗᵏ`)
            break
              case 'meido':
			       if (isGroupMsg && !isNsfw) return await client.reply(from,'_Negado._', id)	
            const meido = await axios.get('https://meme-api.herokuapp.com/gimme/meido');
           
            await client.sendFileFromUrl(from, meido.data.url, '', `🌎Alliαηce Oтαkus🇯🇵⃟ ᴬᵗᵏ`)
            break

                    case 'trap':
              if (isGroupMsg && !isNsfw) return await client.reply(from,'_Negado._', id)
               
            
				const tapr = await axios.get('https://nekos.life/api/v2/img/trap')
				await client.sendFileFromUrl(from, tapr.data.url, '', '🌎Alliαηce Oтαkus🇯🇵⃟ ᴬᵗᵏ', id)
            
				 await sleep(2000)
		
				const tapr1 = await axios.get('https://nekos.life/api/v2/img/trap')
				await client.sendFileFromUrl(from, tapr1.data.url, '', '🌎Alliαηce Oтαkus🇯🇵⃟ ᴬᵗᵏ', id)
            
            break


        case 'wallpaper1' :
            const walnime = await axios.get('https://nekos.life/api/v2/img/wallpaper')
            await client.sendFileFromUrl(from, walnime.data.url, '', '1\n🌎Alliαηce Oтαkus🇯🇵⃟ ᴬᵗᵏ', id)
            const walnime1 = await axios.get('https://meme-api.herokuapp.com/gimme/wallpaper')
            await client.sendFileFromUrl(from, walnime1.data.url, '', '2\n🌎Alliαηce Oтαkus🇯🇵⃟ ᴬᵗᵏ', id)
            const walnime2 = await axios.get('https://meme-api.herokuapp.com/gimme/animewallpaper')
            await client.sendFileFromUrl(from, walnime2.data.url, '', '3\n🌎Alliαηce Oтαkus🇯🇵⃟ ᴬᵗᵏ', id)
              const walnime3 = await axios.get('https://meme-api.herokuapp.com/gimme/mobilewallpaper')
            await client.sendFileFromUrl(from, walnime3.data.url, '', '4\n🌎Alliαηce Oтαkus🇯🇵⃟ ᴬᵗᵏ', id)
            break
			 case 'kemono' :
			const kemono = await axios.get('https://meme-api.herokuapp.com/gimme/kemonomimi')
			
                   await client.sendFileFromUrl(from, kemono.data.url, '', `${kemono.data.title}\n🌎Alliαηce Oтαkus🇯🇵⃟ ᴬᵗᵏ`)
			break		
		case 'tapa':
			const tapi = await axios.get('https://nekos.life/api/v2/img/slap')
			await client.sendFileFromUrl(from, tapi.data.url, '', '', id)
			break
			
			
		case 'chance':
			if (args.length == 0) return client.reply(from, 'Defina algo para analisar.', id)
			await client.reply(from, `_👩🏻‍🔬 De acordo com meus calculos super avançados a chance de..._ \n\n*"${body.slice(8)}"*\n\n_...ser realidade é de_ *${lvpc}%.*`, id)
			break
	

        case 'kiss':
            arqa = body.trim().split(' ')
			if (args.length == 1) {
				const persona = author.replace('@c.us', '')
				client.sendTextWithMentions(from, 'Minha nossa! @' + persona + ' deu um beijo em ' + arqa[1] + ' !')
				if (double == 1) {
				await client.sendGiphyAsSticker(from, 'https://media.giphy.com/media/uDedQauEdQ7Bnb7w8s/giphy.gif')
				} else {
				await client.sendGiphyAsSticker(from, 'https://media.giphy.com/media/UwsZyFwzyMfJMiEUK8/giphy.gif')
				}
			
            }
			break

                    			
        
                    
		case 'ttp':
			if (args.length == 0) return client.reply(from, 'Cadê a frase né?', id)
			axios.get(`https://st4rz.herokuapp.com/api/ttp?kata=${body.slice(5)}`)
			.then(res => {
				client.sendImageAsSticker(from, res.data.result)
			})
			break
				case 'morte':
		case 'death':
            if (args.length == 0) return client.reply(from, 'Coloque um nome, apenas um, nada de sobrenome ou nomes inteiros, ainda mais por sua segurança!', id)
			const predea = await axios.get(`https://api.agify.io/?name=${args[0]}`)
			await client.reply(from, `Pessoas com este nome "${predea.data.name}" tendem a morrer aos ${predea.data.age} anos de idade.`, id)
			break	
			
						
			
	    case 'oculto':
            if (!isGroupMsg) return client.reply(from, 'Apenas grupos!', id)
            const eur = await client.getGroupMembers(groupId)
            const surpresa = eur[Math.floor(Math.random() * eur.length)]
			console.log(surpresa.id)
    	    var xvid = ["Negoes branquelos e feministas", `${pushname} batendo punheta` , `${pushname} se depilando na banheira`, `${pushname} comendo meu cuzinho`, `${pushname} quer me comer o que fazer?`, "lolis nuas e safadas", "Ursinhos Mansos Peludos e excitados", "mae do adm cozida na pressao", "Buceta de 500 cm inflavel da boneca chinesa lolita company", "corno manso batendo uma pra mim com meu rosto na webcam", "tigresa vip da buceta de mel", "belle delphine dando o cuzinho no barzinho da esquina", "fazendo anal no negao", "africanos nus e chupando pau", "anal africano", "comendo a minha tia", "lgbts fazendo ahegao", "adm gostoso tirando a roupa", "gays puxando o intestino pra fora", "Gore de porno de cachorro", "anoes baixinhos do pau grandao", "Anões Gays Dotados Peludos", "anões gays dotados penetradores de botas", "Ursinhos Mansos Peludos", "Jailson Mendes", "Vendo meu Amigo Comer a Esposa", "Golden Shower"]
            const surpresa2 = xvid[Math.floor(Math.random() * xvid.length)]
            await client.sendTextWithMentions(from, `*EQUIPE ❌VIDEOS*\n\n_Caro usuário @${surpresa.id.replace(/@c.us/g, '')} ..._\n\n_Sou da administração do Xvideos e nós percebemos que você não entrou em sua conta por mais de 2 semanas e decidimos checar pra saber se está tudo OK com o(a) nosso(a) usuário(a) mais ativo(a)._ \n\n_Desde a última vez que você visitou nosso site, você procurou mais de centenas de vezes por_ *"${surpresa2}"* _(acreditamos ser sua favorita), viemos dizer que elas foram adicionadas e temos certeza que você irá gostar bastante._ \n_Esperamos você lá!_\n\n_Para o nosso usuário(a) favorito(a), com carinho, Equipe Xvideos._`)
            await sleep(2000)
            break
                    
                    	
                    	
    
                    	
                    	//temp LeandroCS
                    	
                    	     
  
      
              client.reply(from, '_Use somente !sticker nos gifs._', id)
      
        break
               case '1stickergif':
        case '1stikergif':
         case '1gifsticker':
        case '1sgif':
            if (isMedia) {
                if (mimetype === 'video/mp4' && message.duration < 13 || mimetype === 'image/gif' && message.duration < 13 || mimetype === 'image/jpg') {
                    const mediaData = await decryptMedia(message, uaOverride)
              client.reply(from, '⏳ _Aguarde  ± 1 minuto!_ ⏳ \n Figura não feita? Reduza o tamanho ou reenvie.', id)
                    const filename = `./media/aswu.${mimetype.split('/')[1]}`
                    await fs.writeFileSync(filename, mediaData)
                     await exec(`gify ${filename} ./media/output.gif --fps=15 --scale=205:205`, async function (error, stdout, stderr) {
                        const gif = await fs.readFileSync('./media/output.gif', { encoding: "base64" })
                        await client.sendImageAsSticker(from, `data:image/gif;base64,${gif.toString('base64')}`)
                    })
                } else (
                    client.reply(from, '[❗] Videos ou gifs com a legenda *!stickerGif* com menos de 12 segundos!', id)
                )
            }
           
            
            
            
                            	
       
            
                   
            
            // Comandos pessoais
                 case 'emgif':
                
        case 'togif':
         case 'viemgif':
        case 'videoemgif':
            if (isMedia) {
                if (mimetype === 'video/mp4' && message.duration < 1000|| mimetype === 'image/gif' && message.duration < 1000 || mimetype === 'image/jpeg' && message.duration < 2) {
                    const mediaData = await decryptMedia(message, uaOverride)
                    client.reply(from, '⏳ _Aguarde, processando..._ ⏳ ', id)
                    const filename = `./media/aswu1.${mimetype.split('/')[1]}`
                    await fs.writeFileSync(filename, mediaData)
                
                      
                      await  client.sendVideoAsGif(from,  './media/aswu1.mp4' , '' , 'GIF? kkk')
      
                } else (
                    client.reply(from, '[❗] Videos com a legenda *!emgif* com menos de 50 segundos!', id)
                )
            }
            break 
      
                  case 'wait':
            if (isMedia && type === 'image/jpg' || quotedMsg && quotedMsg.type === 'image') {
                if (isMedia) {
                    var mediaData = await decryptMedia(message, uaOverride)
                } else {
                    var mediaData = await decryptMedia(quotedMsg, uaOverride)
                }
                const fetch = require('node-fetch')
                const imgBS4 = `data:${mimetype};base64,${mediaData.toString('base64')}`
                client.reply(from, 'Buscando....', id)
             
                 fetch('https://trace.moe/api/search', {
                    method: 'POST',
                    body: JSON.stringify({ image: imgBS4 }),
                    headers: { "Content-Type": "application/json" }
                })
                .then(respon => respon.json())
                .then(resolt => {
                	if (resolt.docs && resolt.docs.length <= 0) {
                		client.reply(from, 'Maaf, saya tidak tau ini anime apa', id)
                	}
                    const { is_adult, title, title_chinese, title_romaji, title_english, episode, similarity, filename, at, tokenthumb, anilist_id } = resolt.docs[0]
                    teks = ''
                    if (similarity < 0.92) {
                    	teks = '*Eu tenho pouca fé que seje isso* :\n\n'
                    }
                    teks += `➸ *Nome Japanese* : ${title}\n➸ *Nome chinese* : ${title_chinese}\n➸ *Nome Romaji* : ${title_romaji}\n➸ *Nome English* : ${title_english}\n`
                    teks += `➸ *Ecchi* : ${is_adult}\n`
                    teks += `➸ *Eps* : ${episode.toString()}\n`
                    teks += `➸ *Kesamaan* : ${(similarity * 100).toFixed(1)}%\n`
                    var video = `https://media.trace.moe/video/${anilist_id}/${encodeURIComponent(filename)}?t=${at}&token=${tokenthumb}`;
                     client.sendFileFromUrl(from, video, 'nimek.mp4', teks, id).catch(() => {
                       
                        client.reply(from, teks, id)
                    })
                })
                .catch(() => {
                    client.reply(from, 'Error !', id)
                })
            } else {
                client.sendFile(from, './media/img/tutod.jpg', 'Tutor.jpg', 'Olha como funciona!', id)
            }
            break
                
                

           
        
           case 'perfil':
               case 'profile':
            var role = 'None'
            if (isGroupMsg) {
              if (!quotedMsg) {
              if (mentionedJidList.length !== 0) menUser = await client.getContact(mentionedJidList[0])
		var qmid = quotedMsg ? quotedMsgObj.sender.id : (mentionedJidList.length !== 0 ? menUser.id : user)
              var block = ban.includes(qmid) ? 'Sim' : 'Não'
              var pic = await client.getProfilePicFromServer(author)
              var namae = pushname
             var myMsg = getMsg(qmid, msgcount)
              var sts = await client.getStatus(author)
              var adm = groupAdmins.includes(qmid) ? 'Sim' : 'Não'
              const { status } = sts
               if (pic == undefined) {
               var pfp = errorurl 
               } else {
               var pfp = pic
               } 
             await client.sendFileFromUrl(from, pfp, 'pfp.jpg', `*Perfil* ✨️ \n\n 🔖️ *Nome da(o) safada(o): ${namae}*\n\n💬 *Número de mensagens: ${myMsg}* _mínimo é 50 mensagens por semana_  \n\n💌️ *Status: ${status}*\n\n*💔️ Bloqueado?: ${block}*\n\n 👑️ *ADM?: ${adm}*`)
             } else if (quotedMsg) {
             var qmid = quotedMsgObj.sender.id
             var block = ban.includes(qmid)? 'Sim' : 'Não'
             var pic = await client.getProfilePicFromServer(qmid)
             var namae = quotedMsgObj.sender.name
               var myMsg = getMsg(qmid, msgcount)
             var sts = await client.getStatus(qmid)
           var adm = groupAdmins.includes(qmid) ? 'Sim' : 'Não'
             const { status } = sts
              if (pic == undefined) {
              var pfp = errorurl 
              } else {
              var pfp = pic
              } 
             await client.sendFileFromUrl(from, pfp, 'pfp.jpg', `*Perfil* ✨️ \n\n 🔖️ *Nome da(o) safada(o): ${namae}*\n\n💬 *Número de mensagens: ${myMsg}*\n\n💌️ *Status: ${status}*\n\n*💔️ Bloqueado?: ${block}*\n\n👑️ *ADM?: ${adm}*`)
             }
            }
            break
        case 'snk':
            client.reply(from, snk, message.id)
        default:
            console.log(color('[UNLISTED]', 'red'), color(time, 'yellow'), 'Unregistered Command from', color(pushname))
            break
        
        
        
        

                      
        case 'bater':
            arg = body.trim().split(' ')
            const person = author.replace('@c.us', '')
            await client.sendGiphyAsSticker(from, 'https://media.giphy.com/media/S8507sBJm1598XnsgD/source.gif')
           await   client.sendTextWithMentions(from, '@' + person + ' *batendo em* ' + arg[1])
            break
            
            
            
            
            
                         	break
                    	
                     case 'emgif2':
    
                  if (isMedia) {
                if (mimetype === 'video/mp4' && message.duration < 30|| mimetype === 'image/gif' && message.duration < 30|| mimetype === 'image') {
                
                    const mediaData = await decryptMedia(message, uaOverride)
              client.reply(from, '⏳ _Aguarde processando!_ ⏳', id)
                    const filename = `./media/aswu3.${mimetype.split('/')[1]}`
                    await fs.writeFileSync(filename, mediaData)
                     await exec(`gify ${filename} ./media/output3.gif --fps=15 --scale=206:206`, async function (error, stdout, stderr) {
                     
  
        await    client.sendFile(from, './media/output3.gif', true , null , true, true, true, true, true)
                    })
                } else (
                    client.reply(from, '[❗] Videos ou gifs com a legenda *!stickerGif* com menos de 12 segundos!', id)
                )
            }
            break 
            
     
    
    case 'vozrobo':
			if (isMedia && isAudio || isQuotedAudio || isQuotedPtt) {
				try {
					await client.reply(from,'Aguarde...', id)
					const encryptMedia = isQuotedAudio || isQuotedPtt ? quotedMsg : message
					const mediaData = await decryptMedia(encryptMedia, uaOverride)
					await fs.writeFile(`./media/n${user.replace('@c.us', '')}${lvpc}.mp3`, mediaData, (err) => {
						if (err) return console.error(err)
						console.log(color('[FFMPEG]', 'crimson'), color(`- Conversão de audio para versão "nightcore" pedida por → ${pushname} - Você pode ignorar.`, 'gold'))
						ffmpeg(`./media/n${user.replace('@c.us', '')}${lvpc}.mp3`).audioFilter(`afftfilt=real='hypot(re,im)*sin(0)':imag='hypot(re,im)*cos(0)':win_size=512:overlap=0.75`).format('mp3').save(`./media/vo-${user.replace('@c.us', '')}${lvpc}.mp3`) // Você pode editar o valor acima (44100*1.25)
						.on('error', async function (error, stdout, stderr) {
							await client.reply(from, mess.fail(), id)
							console.log(color('[NIGHTCORE]', 'crimson'), color(`→ Obtive erros no comando ${prefix}${command} → ${error.message} - Você pode ignorar.`, 'gold'))
						})
						.on('end', async () => {
							console.log(color('[FFMPEG]', 'crimson'), color(`- Conversão de audio para versão "nightcore" finalizada, enviando para → ${pushname} - Você pode ignorar...`, 'gold'))
							await client.sendFile(from, `./media/vo-${user.replace('@c.us', '')}${lvpc}.mp3`, 'audio.mp3', '', id)
							await sleep(10000).then(async () => { await fs.unlinkSync(`./media/vo-${user.replace('@c.us', '')}${lvpc}.mp3`);await fs.unlinkSync(`./media/n${user.replace('@c.us', '')}${lvpc}.mp3`) })
						})
					})
				} catch (error) {
					await client.reply(from, mess.fail(), id)
					console.log(color('[NIGHTCORE]', 'crimson'), color(`→ Obtive erros no comando ${prefix}${command} → ${error.message} - Você pode ignorar.`, 'gold'))
				}
			} else return await client.reply(from, mess.onlyaudio(), id)
			break
			
              case 'vozinvertida':
			if (isMedia && isAudio || isQuotedAudio || isQuotedPtt) {
				try {
					await client.reply(from,'Aguarde...', id)
					const encryptMedia = isQuotedAudio || isQuotedPtt ? quotedMsg : message
					const mediaData = await decryptMedia(encryptMedia, uaOverride)
					await fs.writeFile(`./media/i${user.replace('@c.us', '')}${lvpc}.mp3`, mediaData, (err) => {
						if (err) return console.error(err)
						console.log(color('[FFMPEG]', 'crimson'), color(`- Conversão de audio para versão "nightcore" pedida por → ${pushname} - Você pode ignorar.`, 'gold'))
						ffmpeg(`./media/i${user.replace('@c.us', '')}${lvpc}.mp3`).audioFilter(`areverse`).format('mp3').save(`./media/in-${user.replace('@c.us', '')}${lvpc}.mp3`) // Você pode editar o valor acima (44100*1.25)
						.on('error', async function (error, stdout, stderr) {
							await client.reply(from, mess.fail(), id)
							console.log(color('[NIGHTCORE]', 'crimson'), color(`→ Obtive erros no comando ${prefix}${command} → ${error.message} - Você pode ignorar.`, 'gold'))
						})
						.on('end', async () => {
							console.log(color('[FFMPEG]', 'crimson'), color(`- Conversão de audio para versão "nightcore" finalizada, enviando para → ${pushname} - Você pode ignorar...`, 'gold'))
							await client.sendFile(from, `./media/in-${user.replace('@c.us', '')}${lvpc}.mp3`, 'audio.mp3', '', id)
							await sleep(10000).then(async () => { await fs.unlinkSync(`./media/in-${user.replace('@c.us', '')}${lvpc}.mp3`);await fs.unlinkSync(`./media/i${user.replace('@c.us', '')}${lvpc}.mp3`) })
						})
					})
				} catch (error) {
					await client.reply(from, mess.fail(), id)
					console.log(color('[NIGHTCORE]', 'crimson'), color(`→ Obtive erros no comando ${prefix}${command} → ${error.message} - Você pode ignorar.`, 'gold'))
				}
			} else return await client.reply(from, mess.onlyaudio(), id)
			break
              
             
               case 'vozalta':
			if (isMedia && isAudio || isQuotedAudio || isQuotedPtt) {
				try {
					await client.reply(from,'Aguarde...', id)
					const encryptMedia = isQuotedAudio || isQuotedPtt ? quotedMsg : message
					const mediaData = await decryptMedia(encryptMedia, uaOverride)
					await fs.writeFile(`./media/a${user.replace('@c.us', '')}${lvpc}.mp3`, mediaData, (err) => {
						if (err) return console.error(err)
						console.log(color('[FFMPEG]', 'crimson'), color(`- Conversão de audio pedida por → ${pushname} - Você pode ignorar.`, 'gold'))
						ffmpeg(`./media/a${user.replace('@c.us', '')}${lvpc}.mp3`).audioFilter('acrusher=level_in=2:level_out=6:bits=8:mode=log:aa=1,lowpass=f=3500').format('mp3').save(`./media/al-${user.replace('@c.us', '')}${lvpc}.mp3`)
						.on('error', async function (error, stdout, stderr) {
							await client.reply(from, mess.fail(), id)
							console.log(color('[NIGHTCORE]', 'crimson'), color(`→ Obtive erros no comando ${prefix}${command} → ${error.message} - Você pode ignorar.`, 'gold'))
						})
						.on('end', async () => {
							console.log(color('[FFMPEG]', 'crimson'), color(`- Conversão de audio para versão "nightcore" finalizada, enviando para → ${pushname} - Você pode ignorar...`, 'gold'))
							await client.sendFile(from, `./media/al-${user.replace('@c.us', '')}${lvpc}.mp3`, 'audio.mp3', '', id)
							await sleep(10000).then(async () => { await fs.unlinkSync(`./media/al-${user.replace('@c.us', '')}${lvpc}.mp3`);await fs.unlinkSync(`./media/a${user.replace('@c.us', '')}${lvpc}.mp3`) })
						})
					})
				} catch (error) {
					await client.reply(from, mess.fail(), id)
					console.log(color('[NIGHTCORE]', 'crimson'), color(`→ Obtive erros no comando ${prefix}${command} → ${error.message} - Você pode ignorar.`, 'gold'))
				}
			} else return await client.reply(from, mess.onlyaudio(), id)
			break
              
              
                             case 'vozlenta':
			if (isMedia && isAudio || isQuotedAudio || isQuotedPtt) {
				try {
					await client.reply(from,'Aguarde...', id)
					const encryptMedia = isQuotedAudio || isQuotedPtt ? quotedMsg : message
					const mediaData = await decryptMedia(encryptMedia, uaOverride)
					await fs.writeFile(`./media/l${user.replace('@c.us', '')}${lvpc}.mp3`, mediaData, (err) => {
						if (err) return console.error(err)
						console.log(color('[FFMPEG]', 'crimson'), color(`- Conversão de audio para versão "nightcore" pedida por → ${pushname} - Você pode ignorar.`, 'gold'))
						ffmpeg(`./media/l${user.replace('@c.us', '')}${lvpc}.mp3`).audioFilter('atempo=1.1,asetrate=44100*0.7,firequalizer=gain_entry=\'entry(0,3);entry(250,2);entry(1000,0);entry(4000,-2);entry(16000,-3)\'').format('mp3').save(`./media/le-${user.replace('@c.us', '')}${lvpc}.mp3`) // Você pode editar o valor acima (44100*1.25)
						.on('error', async function (error, stdout, stderr) {
							await client.reply(from, mess.fail(), id)
							console.log(color('[NIGHTCORE]', 'crimson'), color(`→ Obtive erros no comando ${prefix}${command} → ${error.message} - Você pode ignorar.`, 'gold'))
						})
						.on('end', async () => {
							console.log(color('[FFMPEG]', 'crimson'), color(`- Conversão de audio para versão "nightcore" finalizada, enviando para → ${pushname} - Você pode ignorar...`, 'gold'))
							await client.sendFile(from, `./media/le-${user.replace('@c.us', '')}${lvpc}.mp3`, 'audio.mp3', '', id)
							await sleep(10000).then(async () => { await fs.unlinkSync(`./media/le-${user.replace('@c.us', '')}${lvpc}.mp3`);await fs.unlinkSync(`./media/l${user.replace('@c.us', '')}${lvpc}.mp3`) })
						})
					})
				} catch (error) {
					await client.reply(from, mess.fail(), id)
					console.log(color('[NIGHTCORE]', 'crimson'), color(`→ Obtive erros no comando ${prefix}${command} → ${error.message} - Você pode ignorar.`, 'gold'))
				}
			} else return await client.reply(from, mess.onlyaudio(), id)
			break
                            
                             case 'vozvibra':
			if (isMedia && isAudio || isQuotedAudio || isQuotedPtt) {
				try {
					await client.reply(from,'Aguarde...', id)
					const encryptMedia = isQuotedAudio || isQuotedPtt ? quotedMsg : message
					const mediaData = await decryptMedia(encryptMedia, uaOverride)
					await fs.writeFile(`./media/v${user.replace('@c.us', '')}${lvpc}.mp3`, mediaData, (err) => {
						if (err) return console.error(err)
						console.log(color('[FFMPEG]', 'crimson'), color(`- Conversão de audio para versão "nightcore" pedida por → ${pushname} - Você pode ignorar.`, 'gold'))
						ffmpeg(`./media/v${user.replace('@c.us', '')}${lvpc}.mp3`).audioFilter(`vibrato=f=8`).format('mp3').save(`./media/vi-${user.replace('@c.us', '')}${lvpc}.mp3`) // Você pode editar o valor acima (44100*1.25)
						.on('error', async function (error, stdout, stderr) {
							await client.reply(from, mess.fail(), id)
							console.log(color('[NIGHTCORE]', 'crimson'), color(`→ Obtive erros no comando ${prefix}${command} → ${error.message} - Você pode ignorar.`, 'gold'))
						})
						.on('end', async () => {
							console.log(color('[FFMPEG]', 'crimson'), color(`- Conversão de audio para versão "nightcore" finalizada, enviando para → ${pushname} - Você pode ignorar...`, 'gold'))
							await client.sendFile(from, `./media/vi-${user.replace('@c.us', '')}${lvpc}.mp3`, 'audio.mp3', '', id)
							await sleep(10000).then(async () => { await fs.unlinkSync(`./media/vi-${user.replace('@c.us', '')}${lvpc}.mp3`);await fs.unlinkSync(`./media/v${user.replace('@c.us', '')}${lvpc}.mp3`) })
						})
					})
				} catch (error) {
					await client.reply(from, mess.fail(), id)
					console.log(color('[NIGHTCORE]', 'crimson'), color(`→ Obtive erros no comando ${prefix}${command} → ${error.message} - Você pode ignorar.`, 'gold'))
				}
			} else return await client.reply(from, mess.onlyaudio(), id)
			break
			 case 'vozsr':
			if (isMedia && isAudio || isQuotedAudio || isQuotedPtt) {
				try {
					await client.reply(from,'Aguarde...', id)
					const encryptMedia = isQuotedAudio || isQuotedPtt ? quotedMsg : message
					const mediaData = await decryptMedia(encryptMedia, uaOverride)
					await fs.writeFile(`./media/sr${user.replace('@c.us', '')}${lvpc}.mp3`, mediaData, (err) => {
						if (err) return console.error(err)
						console.log(color('[FFMPEG]', 'crimson'), color(`- Conversão de audio para versão "nightcore" pedida por → ${pushname} - Você pode ignorar.`, 'gold'))
						ffmpeg(`./media/sr${user.replace('@c.us', '')}${lvpc}.mp3`).audioFilter(`rubberband=pitch=1.5`).format('mp3').save(`./media/sr-${user.replace('@c.us', '')}${lvpc}.mp3`) // Você pode editar o valor acima (44100*1.25)
						.on('error', async function (error, stdout, stderr) {
							await client.reply(from, mess.fail(), id)
							console.log(color('[NIGHTCORE]', 'crimson'), color(`→ Obtive erros no comando ${prefix}${command} → ${error.message} - Você pode ignorar.`, 'gold'))
						})
						.on('end', async () => {
							console.log(color('[FFMPEG]', 'crimson'), color(`- Conversão de audio para versão "nightcore" finalizada, enviando para → ${pushname} - Você pode ignorar...`, 'gold'))
							await client.sendFile(from, `./media/sr-${user.replace('@c.us', '')}${lvpc}.mp3`, 'audio.mp3', '', id)
							await sleep(10000).then(async () => { await fs.unlinkSync(`./media/sr-${user.replace('@c.us', '')}${lvpc}.mp3`);await fs.unlinkSync(`./media/sr${user.replace('@c.us', '')}${lvpc}.mp3`) })
						})
					})
				} catch (error) {
					await client.reply(from, mess.fail(), id)
					console.log(color('[NIGHTCORE]', 'crimson'), color(`→ Obtive erros no comando ${prefix}${command} → ${error.message} - Você pode ignorar.`, 'gold'))
				}
			} else return await client.reply(from, mess.onlyaudio(), id)
			break
              //fim      	
                    	
                    	
		break
       case 'emimg':
      case 'img':
		
       	
       	
       	if (!isBotGroupAdmins) return client.reply(from, 'Somente ADMs', id)
		else if (quotedMsg && quotedMsg.type == 'video'){
		return client.reply(from, 'that\'s not a sticker, Baka', id)
		} if(quotedMsg) {
	const mediaData = await decryptMedia(quotedMsg)
	const imageBase64 = `data:${quotedMsg.mimetype};base64,${mediaData.toString('base64')}`
	await client.sendFile(from, imageBase64, 'img.jpg', 'Convertido.')
		}
		break
        
	case 'tts':
        if (args.length === 1) return client.reply(from, '  *Use !tts linguagem texto*\nLista de linguagens: af, sq, ar, hy, ca, zh, hr, cs, da, nl, en, eo, fi, fr, de, el, ht, hi, hu, is, id, it, ja, ko, la, lv, mk, no, pl, pt, ro, ru, sr, sk, es, sw, sv, ta, th, tr, vi, cy.*')
            const dataBhs = body.slice(5, 7)
            const dataText = body.slice(8)

        if (dataText === '') return client.reply(from, '....', id)
        if (dataText.length > 600) return client.reply(from, 'Passou do limite de texto, max. 600 letras.', id)
        
        try {
            const ttsget = require('node-gtts')(dataBhs.toLowerCase())
            ttsget.save('./media/tts/restts.mp3', dataText, () => 
                            client.sendPtt(from, './media/tts/restts.mp3', id))
        } catch (error) {
            return client.reply(from, 'Falha ao obter tts, o código de idioma fornecido é válido? Lista de códigos: af, sq, ar, hy, ca, zh, hr, cs, da, nl, en, eo, fi, fr, de, el, ht, hi, hu, is, id, it, ja, ko, la, lv, mk, no, pl, pt, ro, ru, sr, sk, es, sw, sv, ta, th, tr, vi, cy. ', id)
        }

        break
			    
        case 'quotemaker':
            arg = body.trim().split('|')
            if (arg.length >= 3) {
            client.reply(from, 'Processing...', message.id) 
            const quotes = arg[1]
            const author = arg[2]
            const theme = arg[3]
            try {
            const resolt = await quotemaker(quotes, author, theme)
            client.sendFile(from, resolt, 'quotesmaker.jpg','neh...')
            } catch {
            client.reply(from, 'I\'m afraid to tell you that the image failed to process', message.id)
            }
            } else {
            client.reply(from, 'Usage: \n!quotemaker |text|watermark|theme\n\nEx :\n!quotemaker |...|...|random', message.id)
            }
            break
			    
	case 'aiquote' :
            const aiquote = await axios.get("http://inspirobot.me/api?generate=true")
            await client.sendFileFromUrl(from, aiquote.data, 'quote.jpg', 'Powered By http://inspirobot.me/ With ❤️' , id )
            break
			    
        case 'groupinfo' :
            if (!isGroupMsg) return client.reply(from, '.', message.id) 
            var totalMem = chat.groupMetadata.participants.length
            var desc = chat.groupMetadata.desc
            var groupname = name
            var welgrp = wel.includes(chat.id)
            var ngrp = nsfwgrp.includes(chat.id)
            var grouppic = await client.getProfilePicFromServer(chat.id)
            if (grouppic == undefined) {
                 var pfp = errorurl
            } else {
                 var pfp = grouppic 
            }
            await client.sendFileFromUrl(from, pfp, 'group.png', `*${groupname}* 

🌐️ *Membros: ${totalMem}*


📃️ *Regras:* 

${desc}`)
        break
        case 'bc':
            if(!isowner) return client.reply(from, 'Only Bot admins!', message.id)
            let msg = body.slice(4)
            const chatz = await client.getAllChatIds()
            for (let ids of chatz) {
                var cvk = await client.getChatById(ids)
                if (!cvk.isReadOnly) client.sendText(ids, `[ EWH BOT Broadcast ]\n\n${msg}`)
            }
            client.reply(from, 'Broadcast Success!', message.id)
            break
        case 'ban.':
            if(!isowner) return client.reply(from, 'Only Bot admins can use this CMD!', message.id)
            for (let i = 0; i < mentionedJidList.length; i++) {
                ban.push(mentionedJidList[i])
                fs.writeFileSync('./lib/banned.json', JSON.stringify(ban))
                client.reply(from, 'Succes ban target!', message.id)
            }
            break  		   
        case 'covid':
            arg = body.trim().split(' ')
            console.log(...arg[1])
            var slicedArgs = Array.prototype.slice.call(arg, 1);
            console.log(slicedArgs)
            const country = await slicedArgs.join(' ')
            console.log(country)
            const response2 = await axios.get('https://coronavirus-19-api.herokuapp.com/countries/' + country + '/')
            const { cases, todayCases, deaths, todayDeaths, active } = response2.data
                await client.sendText(from, '🌎️Covid Info -' + country + ' 🌍️\n\n✨️Total Cases: ' + `${cases}` + '\n📆️Today\'s Cases: ' + `${todayCases}` + '\n☣️Total Deaths: ' + `${deaths}` + '\n☢️Today\'s Deaths: ' + `${todayDeaths}` + '\n⛩️Active Cases: ' + `${active}` + '.')
            break
			    
    			    
        case 'mentionall':
            if (!isGroupMsg) return client.reply(from, 'Somente em grupos.', message.id)
            if (!isGroupAdmins) return client.reply(from, 'Somente ADMs', message.id)
            const groupMem = await client.getGroupMembers(groupId)
            let hehe = `${body.slice(12)} - ${pushname} \n`
            for (let i = 0; i < groupMem.length; i++) {
                hehe += '*💨️*'
                hehe += ` @${groupMem[i].id.replace(/@c.us/g, '')}\n\n`
            }
            hehe += '*━━━━━━━༺ ✦ ༻━━━━━━━*'
            await client.sendTextWithMentions(from, hehe)
           

break 
     
			    
        case 'kickall':
            const isGroupOwner = sender.id === chat.groupMetadata.owner
            if(!isGroupOwner) return client.reply(from, 'Sorry, Only group owner can use this CMD', message.id)
            if (!isGroupMsg) return client.reply(from, 'This command can only be used in groups', message.id)
            if(!isBotGroupAdmins) return client.reply(from, 'You need to give me the power to do this before executing', message.id)
            const allMem = await client.getGroupMembers(groupId)
            console.log(isGroupAdmins)
            for (let i = 0; i < allMem.length; i++) {
                if (groupAdmins.includes(allMem[i].id)) return
                await client.removeParticipant(groupId, allMem[i].id)
            }
            client.reply(from, 'Done!', message.id)
            break
			    
        case 'clearall':
            if (!isowner) return client.reply(from, 'Owner only', message.id)
            const allChatz = await client.getAllChats()
            for (let dchat of allChatz) {
                await client.deleteChat(dchat.id)
            }
            client.reply(from, 'Done', message.id)
            break
			    
       
			    
       case 'cgc':
            arg = body.trim().split(' ')
            const gcname = arg[1]
            client.createGroup(gcname, mentionedJidList)
            client.sendText(from, 'Group Created ✨️')
            break
       
        case 'kick':
        
        case 'ban':
            if(!isGroupMsg) return client.reply(from, 'Burro!', message.id)
            if(!isGroupAdmins) return client.reply(from, 'You are not an admin, Sorry', message.id)
            if(!isBotGroupAdmins) return client.reply(from, 'You need to make me admin to use this CMD', message.id)
            if(mentionedJidList.length === 0) return client.reply(from, 'Wrong format', message.id)
            await client.sendText(from, `Banindo:\n☠${mentionedJidList.join('\n')} ☠`)
            for (let i = 0; i < mentionedJidList.length; i++) {
               // if (groupAdmins.includes(mentionedJidList[i])) return await client.reply(from, '....', message.id)
               // await   client.sendFile(from, './media/ban.jpg', 'ban.jpg' , '')
      
                await client.removeParticipant(groupId, mentionedJidList[i])
              
                
            }
            break
        case 'delete':
            if (!isGroupAdmins) return client.reply(from, 'Only admins can use this command', id)
            if (!quotedMsg) return client.reply(from, 'Wrong Format!', id)
            if (!quotedMsgObj.fromMe) return client.reply(from, 'Wrong Format!', id)
            client.deleteMessage(quotedMsgObj.chatId, quotedMsgObj.id, false)
            break
        case 'leave':
            if(!isGroupMsg) return client.reply(from, '...', message.id)
            if(!isGroupAdmins) return client.reply(from, 'You are not an admin', message.id)
            await client.sendText(from,'Sayonara').then(() => client.leaveGroup(groupId))
            break
        case 'promote':
            if(!isGroupMsg) return client.reply(from, '.', message.id)
            if(!isGroupAdmins) return client.reply(from, 'You are not an admin', message.id)
            if(!isBotGroupAdmins) return client.reply(from, 'You need to make me admin to use this CMD', message.id)
            if (mentionedJidList.length === 0) return await client.reply(from, 'Wrong format!', message.id)
            if (mentionedJidList.length >= 2) return await client.reply(from, 'One user at a time', message.id)
            if (groupAdmins.includes(mentionedJidList[0])) return await client.reply(from, 'This user is already admin', message.id)
            await client.promoteParticipant(groupId, mentionedJidList[0])
            await client.sendTextWithMentions(from, `@${mentionedJidList[0].replace('@c.us', '')} is now an admin`)
            break
        case 'demote':
            if(!isGroupAdmins) return client.reply(from, 'You are not an admin', message.id)
            if(!isBotGroupAdmins) return client.reply(from, 'You need to make me admin to use this CMD', message.id)
            if (mentionedJidList.length === 0) return client.reply(from, 'Wrong Format', message.id)
            if (mentionedJidList.length >= 2) return await client.reply(from, 'One user at a time', message.id)
            if (!groupAdmins.includes(mentionedJidList[0])) return await client.reply(from, 'The user isn\'t an admin', message.id)
            await client.demoteParticipant(groupId, mentionedJidList[0])
            await client.sendTextWithMentions(from, `Demoted @${mentionedJidList[0].replace('@c.us', '')}.`)
            break
        case 'join':
            if (args.length == 0) return client.reply(from, 'Wrong Format', message.id)
            const link = body.slice(6)
            const minMem = 30
            const isLink = link.match(/(https:\/\/chat.whatsapp.com)/gi)
            const check = await client.inviteInfo(link)
            if (!isLink) return client.reply(from, 'Where\'s the link?', message.id)
            if (check.size < minMem) return client.reply(from, 'The group does not have 30+ members', message.id)
            await client.joinGroupViaLink(link).then( async () => {
                await client.reply(from, '*Joined* ✨️', message.id)
            }).catch(error => {
                client.reply(from, 'An error occured 💔️', message.id)
            })
            break
        case 'sauce':
             if (isMedia) {
                 if (type == 'image') {
                 const buffer = await decryptMedia(message, uaOverride)
                 const filename = `./media/images/sauce.${mime.extension(message.mimetype)}`
                 await fs.writeFile(filename, buffer)
                 await source.sauce(filename, message)
                 } else { 
                 client.reply(from, 'Only Images are supported', id)
                 }
             } else if (quotedMsg && quotedMsg.type == 'image') {
                 const buffer = await decryptMedia(quotedMsg, uaOverride)
                 const filename = `./media/images/sauce.${mime.extension(quotedMsg.mimetype)}`
                 await fs.writeFile(filename, buffer)
                 await source.sauce(filename, quotedMsgObj)
             } else { 
                 client.reply(from, 'Only Images are supported', id)
             }
             break
			 
			  
			  
			  
			  
			  
			  
			  
			  
			  
			  
			    
        case 'lyrics':
          if (args.length == 0) return await client.reply(from, mess.noargs() + 'Use comando achar letra completa.', id)
				try {
					const liric = await axios.get(`https://some-random-api.ml/lyrics?title=${encodeURIComponent(body.slice(7))}`)
					await client.sendFileFromUrl(from, liric.data.thumbnail.genius, '', `\n${liric.data.title}\n\n\n${liric.data.lyrics}\n*━━━━━━━༺ ✦ ༻━━━━━━━*`, id)
				} catch (error) {
					await client.reply(from, 'Nada encontrado.', id)
					
				}
				break
        case 'anime':
            const keyword = message.body.replace('#anime', '')
            try {
            const data = await fetch(
           `https://api.jikan.moe/v3/search/anime?q=${keyword}`
            )
            const parsed = await data.json()
            if (!parsed) {
              await client.sendFileFromUrl(from, errorurl2, 'error.png', '💔️ Sorry, Couldn\'t find the requested anime', id)
              console.log("Sent!")
              return null
              }
            const { title, synopsis, episodes, url, rated, score, image_url } = parsed.results[0]
            const content = `*Anime Found!*
✨️ *Title:* ${title}

🎆️ *Episodes:* ${episodes}

💌️ *Rating:* ${rated}

❤️ *Score:* ${score}

💚️ *Synopsis:* ${synopsis}

🌐️ *URL*: ${url}`

            const image = await bent("buffer")(image_url)
            const base64 = `data:image/jpg;base64,${image.toString("base64")}`
            client.sendImage(from, base64, title, content)
           } catch (err) {
             console.error(err.message)
             await client.sendFileFromUrl(from, errorurl2, 'error.png', '💔️ Sorry, Couldn\'t find the requested anime')
           }
          break
	case 'manga':
	const keywrd = (args)
            try {
            const data = await fetch(
           `https://api.jikan.moe/v3/search/manga?q=${keywrd}`
            )
            const parsed = await data.json()
            if (!parsed) {
              await client.sendFileFromUrl(from, errorurl2, 'error.png', 'Sorry, Couldn\'t find the requested manga', id)
              console.log("Sent!")
              return null
              }
            const { title, synopsis, chapters, url, volumes, score, image_url } = parsed.results[0]
            const content = `*Manga found*

*Title:* ${title}

*Chapters:* ${chapters}

*Volumes:* ${volumes}

*Score:* ${score}

*Synopsis:* ${synopsis}

*Link*: ${url}`

            const image = await bent("buffer")(image_url)
            const base64 = `data:image/jpg;base64,${image.toString("base64")}`
            client.sendImage(from, base64, title, content)
           } catch (err) {
             console.error(err.message)
             await client.sendFileFromUrl(from, errorurl2, 'error.png', 'Sorry, Couldn\'t find the requested manga')
           }
          break
		  
	case 'chara':
 	    const keywr = (args)
            try {
            const data = await fetch(
           `https://api.jikan.moe/v3/search/character?q=${keywr}`
            )
            const parsed = await data.json()
            if (!parsed) {
              await client.sendFileFromUrl(from, errorurl2, 'error.png', 'Sorry, Couldn\'t find the requested character', id)
              console.log("Sent!")
              return null
              }
            const { name, alternative_names, url, image_url } = parsed.results[0]
            const content = `*Character found!*

*Name:* ${name}

*Nickname:* ${alternative_names}

*Link*: ${url}`

            const image = await bent("buffer")(image_url)
            const base64 = `data:image/jpg;base64,${image.toString("base64")}`
            client.sendImage(from, base64, name, content)
           } catch (err) {
             console.error(err.message)
             await client.sendFileFromUrl(from, errorurl2, 'error.png', 'Sorry, Couldn\'t find the requested character')
           }
          break
        case 'wallpaper':
       		
     
			await client.reply(from, 'Aguarde...', id)
			
				const wallp1 = await axios.get(`https://wallhaven.cc/api/v1/search?apikey=qwux811zrWTzK6iIjfcFUi80ykjMluhF&q=${encodeURIComponent(body.slice(11))}`)
				var wallp2 = ''
				for (let i = 0; i < 10; i++) { wallp2 += `${wallp1.data.data[i].path}\n` }
				const heavenwpp = wallp2.toString().split('\n')
				const rmvempty = heavenwpp.splice(heavenwpp.indexOf(''), 1)
				const wall = heavenwpp[Math.floor(Math.random() * heavenwpp.length)]
				await client.sendFileFromUrl(from, wall, 'wallpb.jpg', '🌎Alliαηce Oтαkus🇯🇵⃟ ᴬᵗᵏ', id)
		
            break
        case 'waifu': 
        	const waifu = await waifuclient.getRandom()
        	await sclient.sendFileFromUrl(message.from, waifu.data.display_picture, 'haugusha.jpg', `❤️ *Name : ${waifu.data.name}*\n\n💎️ Description : ${waifu.data.description}\n\n💚️ Source : ${waifu.data.series.name}\n\n✨️ URL: ${waifu.data.url}`, message.id)
            break
      
          
            break
        case 'doggo':
            const list = ["https://cdn.shibe.online/shibes/247d0ac978c9de9d9b66d72dbdc65f2dac64781d.jpg","https://cdn.shibe.online/shibes/1cf322acb7d74308995b04ea5eae7b520e0eae76.jpg","https://cdn.shibe.online/shibes/1ce955c3e49ae437dab68c09cf45297d68773adf.jpg","https://cdn.shibe.online/shibes/ec02bee661a797518d37098ab9ad0c02da0b05c3.jpg","https://cdn.shibe.online/shibes/1e6102253b51fbc116b887e3d3cde7b5c5083542.jpg","https://cdn.shibe.online/shibes/f0c07a7205d95577861eee382b4c8899ac620351.jpg","https://cdn.shibe.online/shibes/3eaf3b7427e2d375f09fc883f94fa8a6d4178a0a.jpg","https://cdn.shibe.online/shibes/c8b9fcfde23aee8d179c4c6f34d34fa41dfaffbf.jpg","https://cdn.shibe.online/shibes/55f298bc16017ed0aeae952031f0972b31c959cb.jpg","https://cdn.shibe.online/shibes/2d5dfe2b0170d5de6c8bc8a24b8ad72449fbf6f6.jpg","https://cdn.shibe.online/shibes/e9437de45e7cddd7d6c13299255e06f0f1d40918.jpg","https://cdn.shibe.online/shibes/6c32141a0d5d089971d99e51fd74207ff10751e7.jpg","https://cdn.shibe.online/shibes/028056c9f23ff40bc749a95cc7da7a4bb734e908.jpg","https://cdn.shibe.online/shibes/4fb0c8b74dbc7653e75ec1da597f0e7ac95fe788.jpg","https://cdn.shibe.online/shibes/125563d2ab4e520aaf27214483e765db9147dcb3.jpg","https://cdn.shibe.online/shibes/ea5258fad62cebe1fedcd8ec95776d6a9447698c.jpg","https://cdn.shibe.online/shibes/5ef2c83c2917e2f944910cb4a9a9b441d135f875.jpg","https://cdn.shibe.online/shibes/6d124364f02944300ae4f927b181733390edf64e.jpg","https://cdn.shibe.online/shibes/92213f0c406787acd4be252edb5e27c7e4f7a430.jpg","https://cdn.shibe.online/shibes/40fda0fd3d329be0d92dd7e436faa80db13c5017.jpg","https://cdn.shibe.online/shibes/e5c085fc427528fee7d4c3935ff4cd79af834a82.jpg","https://cdn.shibe.online/shibes/f83fa32c0da893163321b5cccab024172ddbade1.jpg","https://cdn.shibe.online/shibes/4aa2459b7f411919bf8df1991fa114e47b802957.jpg","https://cdn.shibe.online/shibes/2ef54e174f13e6aa21bb8be3c7aec2fdac6a442f.jpg","https://cdn.shibe.online/shibes/fa97547e670f23440608f333f8ec382a75ba5d94.jpg","https://cdn.shibe.online/shibes/fb1b7150ed8eb4ffa3b0e61ba47546dd6ee7d0dc.jpg","https://cdn.shibe.online/shibes/abf9fb41d914140a75d8bf8e05e4049e0a966c68.jpg","https://cdn.shibe.online/shibes/f63e3abe54c71cc0d0c567ebe8bce198589ae145.jpg","https://cdn.shibe.online/shibes/4c27b7b2395a5d051b00691cc4195ef286abf9e1.jpg","https://cdn.shibe.online/shibes/00df02e302eac0676bb03f41f4adf2b32418bac8.jpg","https://cdn.shibe.online/shibes/4deaac9baec39e8a93889a84257338ebb89eca50.jpg","https://cdn.shibe.online/shibes/199f8513d34901b0b20a33758e6ee2d768634ebb.jpg","https://cdn.shibe.online/shibes/f3efbf7a77e5797a72997869e8e2eaa9efcdceb5.jpg","https://cdn.shibe.online/shibes/39a20ccc9cdc17ea27f08643b019734453016e68.jpg","https://cdn.shibe.online/shibes/e67dea458b62cf3daa4b1e2b53a25405760af478.jpg","https://cdn.shibe.online/shibes/0a892f6554c18c8bcdab4ef7adec1387c76c6812.jpg","https://cdn.shibe.online/shibes/1b479987674c9b503f32e96e3a6aeca350a07ade.jpg","https://cdn.shibe.online/shibes/0c80fc00d82e09d593669d7cce9e273024ba7db9.jpg","https://cdn.shibe.online/shibes/bbc066183e87457b3143f71121fc9eebc40bf054.jpg","https://cdn.shibe.online/shibes/0932bf77f115057c7308ef70c3de1de7f8e7c646.jpg","https://cdn.shibe.online/shibes/9c87e6bb0f3dc938ce4c453eee176f24636440e0.jpg","https://cdn.shibe.online/shibes/0af1bcb0b13edf5e9b773e34e54dfceec8fa5849.jpg","https://cdn.shibe.online/shibes/32cf3f6eac4673d2e00f7360753c3f48ed53c650.jpg","https://cdn.shibe.online/shibes/af94d8eeb0f06a0fa06f090f404e3bbe86967949.jpg","https://cdn.shibe.online/shibes/4b55e826553b173c04c6f17aca8b0d2042d309fb.jpg","https://cdn.shibe.online/shibes/a0e53593393b6c724956f9abe0abb112f7506b7b.jpg","https://cdn.shibe.online/shibes/7eba25846f69b01ec04de1cae9fed4b45c203e87.jpg","https://cdn.shibe.online/shibes/fec6620d74bcb17b210e2cedca72547a332030d0.jpg","https://cdn.shibe.online/shibes/26cf6be03456a2609963d8fcf52cc3746fcb222c.jpg","https://cdn.shibe.online/shibes/c41b5da03ad74b08b7919afc6caf2dd345b3e591.jpg","https://cdn.shibe.online/shibes/7a9997f817ccdabac11d1f51fac563242658d654.jpg","https://cdn.shibe.online/shibes/7221241bad7da783c3c4d84cfedbeb21b9e4deea.jpg","https://cdn.shibe.online/shibes/283829584e6425421059c57d001c91b9dc86f33b.jpg","https://cdn.shibe.online/shibes/5145c9d3c3603c9e626585cce8cffdfcac081b31.jpg","https://cdn.shibe.online/shibes/b359c891e39994af83cf45738b28e499cb8ffe74.jpg","https://cdn.shibe.online/shibes/0b77f74a5d9afaa4b5094b28a6f3ee60efcb3874.jpg","https://cdn.shibe.online/shibes/adccfdf7d4d3332186c62ed8eb254a49b889c6f9.jpg","https://cdn.shibe.online/shibes/3aac69180f777512d5dabd33b09f531b7a845331.jpg","https://cdn.shibe.online/shibes/1d25e4f592db83039585fa480676687861498db8.jpg","https://cdn.shibe.online/shibes/d8349a2436420cf5a89a0010e91bf8dfbdd9d1cc.jpg","https://cdn.shibe.online/shibes/eb465ef1906dccd215e7a243b146c19e1af66c67.jpg","https://cdn.shibe.online/shibes/3d14e3c32863195869e7a8ba22229f457780008b.jpg","https://cdn.shibe.online/shibes/79cedc1a08302056f9819f39dcdf8eb4209551a3.jpg","https://cdn.shibe.online/shibes/4440aa827f88c04baa9c946f72fc688a34173581.jpg","https://cdn.shibe.online/shibes/94ea4a2d4b9cb852e9c1ff599f6a4acfa41a0c55.jpg","https://cdn.shibe.online/shibes/f4478196e441aef0ada61bbebe96ac9a573b2e5d.jpg","https://cdn.shibe.online/shibes/96d4db7c073526a35c626fc7518800586fd4ce67.jpg","https://cdn.shibe.online/shibes/196f3ed10ee98557328c7b5db98ac4a539224927.jpg","https://cdn.shibe.online/shibes/d12b07349029ca015d555849bcbd564d8b69fdbf.jpg","https://cdn.shibe.online/shibes/80fba84353000476400a9849da045611a590c79f.jpg","https://cdn.shibe.online/shibes/94cb90933e179375608c5c58b3d8658ef136ad3c.jpg","https://cdn.shibe.online/shibes/8447e67b5d622ef0593485316b0c87940a0ef435.jpg","https://cdn.shibe.online/shibes/c39a1d83ad44d2427fc8090298c1062d1d849f7e.jpg","https://cdn.shibe.online/shibes/6f38b9b5b8dbf187f6e3313d6e7583ec3b942472.jpg","https://cdn.shibe.online/shibes/81a2cbb9a91c6b1d55dcc702cd3f9cfd9a111cae.jpg","https://cdn.shibe.online/shibes/f1f6ed56c814bd939645138b8e195ff392dfd799.jpg","https://cdn.shibe.online/shibes/204a4c43cfad1cdc1b76cccb4b9a6dcb4a5246d8.jpg","https://cdn.shibe.online/shibes/9f34919b6154a88afc7d001c9d5f79b2e465806f.jpg","https://cdn.shibe.online/shibes/6f556a64a4885186331747c432c4ef4820620d14.jpg","https://cdn.shibe.online/shibes/bbd18ae7aaf976f745bc3dff46b49641313c26a9.jpg","https://cdn.shibe.online/shibes/6a2b286a28183267fca2200d7c677eba73b1217d.jpg","https://cdn.shibe.online/shibes/06767701966ed64fa7eff2d8d9e018e9f10487ee.jpg","https://cdn.shibe.online/shibes/7aafa4880b15b8f75d916b31485458b4a8d96815.jpg","https://cdn.shibe.online/shibes/b501169755bcf5c1eca874ab116a2802b6e51a2e.jpg","https://cdn.shibe.online/shibes/a8989bad101f35cf94213f17968c33c3031c16fc.jpg","https://cdn.shibe.online/shibes/f5d78feb3baa0835056f15ff9ced8e3c32bb07e8.jpg","https://cdn.shibe.online/shibes/75db0c76e86fbcf81d3946104c619a7950e62783.jpg","https://cdn.shibe.online/shibes/8ac387d1b252595bbd0723a1995f17405386b794.jpg","https://cdn.shibe.online/shibes/4379491ef4662faa178f791cc592b52653fb24b3.jpg","https://cdn.shibe.online/shibes/4caeee5f80add8c3db9990663a356e4eec12fc0a.jpg","https://cdn.shibe.online/shibes/99ef30ea8bb6064129da36e5673649e957cc76c0.jpg","https://cdn.shibe.online/shibes/aeac6a5b0a07a00fba0ba953af27734d2361fc10.jpg","https://cdn.shibe.online/shibes/9a217cfa377cc50dd8465d251731be05559b2142.jpg","https://cdn.shibe.online/shibes/65f6047d8e1d247af353532db018b08a928fd62a.jpg","https://cdn.shibe.online/shibes/fcead395cbf330b02978f9463ac125074ac87ab4.jpg","https://cdn.shibe.online/shibes/79451dc808a3a73f99c339f485c2bde833380af0.jpg","https://cdn.shibe.online/shibes/bedf90869797983017f764165a5d97a630b7054b.jpg","https://cdn.shibe.online/shibes/dd20e5801badd797513729a3645c502ae4629247.jpg","https://cdn.shibe.online/shibes/88361ee50b544cb1623cb259bcf07b9850183e65.jpg","https://cdn.shibe.online/shibes/0ebcfd98e8aa61c048968cb37f66a2b5d9d54d4b.jpg"]
            let kya = list[Math.floor(Math.random() * list.length)]
            client.sendFileFromUrl(from, kya, 'Dog.jpeg', 'Doggo ✨️', id)
            break
        case 'gato':          
            q2 = Math.floor(Math.random() * 900) + 300;
            q3 = Math.floor(Math.random() * 900) + 300;
            client.sendFileFromUrl(from, 'http://placekitten.com/'+q3+'/'+q2, 'neko.png','Neko 🌠️', id)
            break
        case 'roll':
            const dice = Math.floor(Math.random() * 6) + 1
            await client.sendStickerfromUrl(from, 'https://www.random.org/dice/dice' + dice + '.png')
            break
        case 'flip':
            const side = Math.floor(Math.random() * 2) + 1
            if (side == 1) {
               client.sendStickerfromUrl(from, 'https://i.ibb.co/LJjkVK5/heads.png')
            } else {
               client.sendStickerfromUrl(from, 'https://i.ibb.co/wNnZ4QD/tails.png')
            }
            break
 
        case 'pokemon':
            arg = body.trim().split(' ')
            if (arg.length < 2) {
            client.reply(from, 'Give me a pokemon name, Baka!', id)
	    } else {
		if (pkarrs.includes(body.slice(9).toLowerCase())) {
            const pokedta = await pokefunc.pkmzdata(body.slice(9).toLowerCase())
	    await client.sendFileFromUrl(from, pokedta.url, 'pkmn.png',pokedta.data, id)
                } else {
		client.reply(from, `No such pokemon (${body.slice(9).toLowerCase()})`, id)
		}
	    }
	    break
 
        case 'meme':
            const response = await axios.get('https://meme-api.herokuapp.com/gimme/memesbrasil');
            const { postlink, title, subreddit, url, nsfw, spoiler } = response.data
            await client.sendFileFromUrl(from, `${url}`, '', `${title}\n\n🌎Alliαηce Oтαkus🇯🇵⃟ ᴬᵗᵏ`)
            
            break
        case 'help':
         case 'menu':
          case 'comandos':
           
        await client.reply(from, help2(prefix, pushname), message.id)
      
            break
       
        
     

        }
    } catch (err) {
        console.log(color('[ERROR]', 'red'), err)
    }
}
